<?php
    if(session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    if (isset($_POST['supplier_create'])) {
        createSupplier($_POST['supplier_name'], $_POST['supplier_address'], $_POST['supplier_contactno']);
    } elseif(isset($_POST['customer_edit'])) {
        // updateAccount($_POST['user_id'], $_POST['user_fname'], $_POST['user_lname'], $_POST['user_position'], 
        // $_POST['user_acctname'], $_POST['user_contactno'], $_POST['user_level'], $_POST['user_status']);
    } 
    
    function loadSuppliers($conn) {
        $sql = "SELECT * FROM supplier";

        if($result = mysqli_query($conn, $sql)) {
            if(mysqli_num_rows($result) > 0) {
                // load data
                while($row = mysqli_fetch_array($result)) {
                    echo "<tr>";
                        echo "<td>" . $row['company_name'] . "</td>";
                        echo "<td>" . $row['address'] . "</td>";
                        echo "<td>" . $row['contactno'] . "</td>";                      
                        echo "<td>
                            <a href='supplier-edit.php?id=".$row['supplier_id']."' data-toggle='tooltip' title='Edit'>
                                <button type='button' class='btn btn-primary btn-sm btn-rounded' data-toggle='modal' data-target='#edit-Users'><i class='ti-pencil-alt btn-icon-prepend'></i></button>
                            </a>
                            <a href='supplier_items.php?id=".$row['supplier_id']."' data-toggle='tooltip' title='Supplied Items'>
                                <button type='button' class='btn btn-success btn-sm btn-rounded'><i class='ti-files btn-icon-prepend'></i></button>
                            </a>"; ?>
                            <a href="supplier.php?del=<?php echo htmlentities($row['supplier_id']);?>" onclick="return confirm('Are you sure you want to delete?');" data-toggle="tooltip" title="Delete">
                              <button type="button" class="btn btn-danger btn-sm btn-rounded" data-toggle="modal" data-target="#delete-Category"><i class="ti-trash btn-icon-prepend"></i></button>
                            </a>
                    <?php echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr> No record/s found.</tr>";
            }
        }
    }

    // function loadSupplierDetails($conn, $id) {
    //     $sql = "SELECT * FROM users where User_id = " .$id;

    //     if($result = mysqli_query($conn, $sql)) {
    //         if(mysqli_num_rows($result) > 0) {
    //             // load data
    //             while($row = mysqli_fetch_array($result)) {
    //                 echo '<input type="text" id="User ID" name="user_id" value="'.$id.'" hidden>
    //                         <div class="form-group col-md-12">
    //                             <label for="First Name">First Name</label>
    //                             <input type="text" class="form-control" id="First Name" name="user_fname" value="'.$row['FirstName'].'" placeholder="First Name">
    //                         </div>
    //                         <div class="form-group col-md-12">
    //                             <label for="Last Name">Last Name</label>
    //                             <input type="text" class="form-control" id="Last Name" name="user_lname"  value="'.$row['LastName'].'" placeholder="Username">
    //                         </div>
    //                         <div class="form-group col-md-12">
    //                             <label for="Contact Number">Contact Number</label>
    //                             <input type="text" class="form-control" id="Contact Number" name="user_contactno"  value="'.$row['contactno'].'" placeholder="Contact Number">
    //                         </div>';
    //             }
    //         }
    //     }
        
    // }

    function createSupplier($supplier, $address, $contactno) {
        include_once '../database/connection.php'; 

        // Sanitize and Set parameters
        $supplier = htmlspecialchars($supplier);
        $address = htmlspecialchars($address);
        $contactno = htmlspecialchars($contactno);

        $sql = "INSERT INTO supplier(company_name, address, contactno)
                VALUES(?, ?, ?)";

        if($stmt = mysqli_prepare($dbConn, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sss", $supplier, $address, $contactno);
        
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // PREPARES CONFIRMATION MESSAGE
                $error = "<span class='text-success'>Created Successfully</span>";
                $_SESSION['errormsg'] = $error;

                header('location: ../pages/supplier/supplier.php');
                exit;
            } else {
                // echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
                // PREPARES ERROR MESSAGE
                $error = "<span class='text-danger'>Unable to process request</span>";
                $_SESSION['errormsg'] = $error;

                header('location: ../pages/supplier/supplier.php');
                exit;
            }
        }
    }

    // function updateCustomer($id, $fname, $lname, $contactno) {
    //     include_once '../database/connection.php'; 

    //     // Sanitize and Set parameters
    //     $fname = htmlspecialchars($fname);
    //     $lname = htmlspecialchars($lname);
    //     $contactno = htmlspecialchars($contactno);
    //     $id = htmlspecialchars($id); 

    //     $sql = "UPDATE customer SET 
    //             lastname = ?, firstname = ?, contactno = ? WHERE customer_id = ?";

    //     if($stmt = mysqli_prepare($dbConn, $sql)){
    //         // Bind variables to the prepared statement as parameters
    //         mysqli_stmt_bind_param($stmt, "sssi", $lname, $fname, $contactno, $id);
        
    //         // Attempt to execute the prepared statement
    //         if(mysqli_stmt_execute($stmt)){
    //             header('location: ../pages/customer/customer.php');
    //             exit;
    //         } else {
    //             echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
    //         }
    //     }
    // }
?>