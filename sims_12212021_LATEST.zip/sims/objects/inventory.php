<?php
    function loadInventorySummary($conn) {
        // $sql = "SELECT a.id, a.prod_name, b.color, c.size,
        //        ((COALESCE(
        //             (SELECT SUM(inv_itemqty) FROM inventoryitems d WHERE d.prod_id = a.id AND
        //             d.inv_action = 'addstock' GROUP BY a.id),0) - 
        //         COALESCE(
        //             (SELECT SUM(inv_itemqty) FROM inventoryitems d WHERE d.prod_id = a.id AND
        //                 d.inv_action = 'checkout' GROUP BY a.id),0)) - 
        //         (COALESCE(
        //             (SELECT SUM(quantity) FROM transactiondetails d WHERE d.prod_id = a.id 
        //                 GROUP BY a.id),0) + 
        //         COALESCE(
        //             (SELECT SUM(quantity) FROM for_purchase e WHERE e.prod_id = a.id 
        //             GROUP BY a.id),0) + 
        //         COALESCE(
        //             (SELECT SUM(quantity) FROM orderDetails f WHERE f.prod_id = a.id AND
        //             (SELECT order_status FROM orderhistory WHERE order_id = f.order_id) = 'FOR PAYMENT' 
        //             GROUP BY a.id),0)
        //             )) AS OnHand 
        //         FROM products a INNER JOIN color b ON a.prod_color = b.color_id 
        //         INNER JOIN size c ON a.prod_size = c.size_id";

        $sql = "SELECT a.id, a.prod_name, b.color, c.size,
        ((COALESCE(
             (SELECT SUM(inv_itemqty) FROM inventoryitems d WHERE d.prod_id = a.id AND
             d.inv_action = 'addstock' GROUP BY a.id),0) + 
        COALESCE(
            (SELECT SUM(quantity) FROM returns_table d WHERE d.prod_id = a.id 
                GROUP BY a.id),0) - 
         COALESCE(
             (SELECT SUM(inv_itemqty) FROM inventoryitems d WHERE d.prod_id = a.id AND
                 d.inv_action = 'checkout' GROUP BY a.id),0)) - 
         (COALESCE(
             (SELECT SUM(quantity) FROM transactiondetails d WHERE d.prod_id = a.id 
                 GROUP BY a.id),0) + 
         COALESCE(
             (SELECT SUM(quantity) FROM for_purchase e WHERE e.prod_id = a.id 
             GROUP BY a.id),0) + 
         COALESCE(
             (SELECT SUM(quantity) FROM orderDetails f WHERE f.prod_id = a.id AND
             (SELECT order_status FROM orderhistory WHERE order_id = f.order_id) = 'FOR PAYMENT' 
             GROUP BY a.id),0)
             )) AS OnHand 
         FROM products a INNER JOIN color b ON a.prod_color = b.color_id 
         INNER JOIN size c ON a.prod_size = c.size_id";
        
        $result = "";
        if($result = mysqli_query($conn, $sql)) {
            return $result;
        } else {
            echo "ERROR: Could not execute query: $sql. " . mysqli_error($conn);
        }
    }

?>