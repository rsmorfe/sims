<?php
    function loadItems($conn,$table) {
        $sql = "";

        if ($table == 'category') {
            $sql = "SELECT * FROM category WHERE cat_status = 1";
        } else if($table == 'size') {
            $sql = "SELECT * FROM size";
        } else if($table == 'color') {
            $sql = "SELECT * FROM color";
        } else if($table == 'fabric') {
            $sql = "SELECT * FROM fabric";
        } else if($table == 'products') {
            $sql = "SELECT a.id, a.itemcode, a.prod_name, b.cat_name, c.size, d.color, 
                    e.fabric, a.prod_price, a.prod_sellingprice 
                    FROM products a INNER JOIN category b ON a.prod_cat = b.cat_id 
                    LEFT JOIN size c ON a.prod_size = c.size_id 
                    LEFT JOIN color d ON a.prod_color = d.color_id 
                    LEFT JOIN fabric e ON a.prod_fabric = e.fabric_id";
        }
        
 
        $result = "";
        if($result = mysqli_query($conn, $sql)) {
            return $result;
        } else {
            echo "ERROR: Could not execute query: $sql. " . mysqli_error($conn);
        }
    }

    function loadProductInfo($conn,$prod_id) {
        $sql = "";

        $sql = "SELECT * FROM products WHERE id = " .$prod_id;

        $result = "";
        if($result = mysqli_query($conn, $sql)) {
            return $result;
        } else {
            echo "ERROR: Could not execute query: $sql. " . mysqli_error($conn);
        }
    }

    function uploadImage($image) {
        $target_directory = "../../images/products/";
        $target_file = $target_directory . $image;
        $file_type = pathinfo($target_file, PATHINFO_EXTENSION);

        if(move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)){
            // it means photo was uploaded
        } else {
            echo "<script>console.log('Could not save image');</script>";
        }
    }
?>