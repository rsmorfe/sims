<?php
if ((function_exists('session_status') 
&& session_status() !== PHP_SESSION_ACTIVE) || !session_id()) {
session_start();
}

ob_start();

$GLOBALS['dbCOnnection'] = "";

    /* --------------- POS FUNCTIONS  ----------------*/
    function setGlobalDB($conn) {
        $GLOBALS['dbCOnnection'] = $conn;
    }

    function getDBConnection() {
        return $GLOBALS['dbCOnnection'];
    }

    function pageRedirect($location) {

        if($location == '../pages/pos/generate_receipt.php') {
            echo "<script>window.open('{$location}','_blank')</script>";
            echo "<script>window.location.replace = 'http://localhost:8080/sims/pages/pos/pos_order.php';</script>";
        } else {
            exit(header('location: ' .$location));
        }   
    }

    // GET CURRENT STOCK
    function getStock($conn, $prod_id) {
        $qty = 0;
        $sql = "SELECT ((COALESCE(
            (SELECT SUM(inv_itemqty) FROM inventoryitems d WHERE d.prod_id = a.id AND
            d.inv_action = 'addstock' GROUP BY a.id),0) + 
        COALESCE(
           (SELECT SUM(quantity) FROM returns_table d WHERE d.prod_id = a.id 
               GROUP BY a.id),0) - 
        COALESCE(
            (SELECT SUM(inv_itemqty) FROM inventoryitems d WHERE d.prod_id = a.id AND
                d.inv_action = 'checkout' GROUP BY a.id),0)) - 
        (COALESCE(
            (SELECT SUM(quantity) FROM transactiondetails d WHERE d.prod_id = a.id 
                GROUP BY a.id),0) + 
        COALESCE(
            (SELECT SUM(quantity) FROM for_purchase e WHERE e.prod_id = a.id 
            GROUP BY a.id),0) + 
        COALESCE(
            (SELECT SUM(quantity) FROM orderDetails f WHERE f.prod_id = a.id AND
            (SELECT order_status FROM orderhistory WHERE order_id = f.order_id) = 'FOR PAYMENT' 
            GROUP BY a.id),0)
            )) AS quantity 
        FROM products a WHERE a.id = {$prod_id}";

        if($result = mysqli_query($conn, $sql)) {
            if(mysqli_num_rows($result) > 0) {
                // load data
                $row = mysqli_fetch_array($result);
                $qty = $row['quantity'];
            }
        }

        return $qty;
    }

    // GET for_purchase quantity
    function getForPurchaseQty($conn, $prod_id) {
        $qty = 0;
        $sql = "SELECT prod_id, quantity FROM for_purchase WHERE prod_id = $prod_id";

        if($result = mysqli_query($conn, $sql)) {
            if(mysqli_num_rows($result) > 0) {
                // load data
                $row = mysqli_fetch_array($result);
                $qty = $row['quantity'];
            }
        }

        return $qty;
    }

    // LOAD CUSTOMERS
    function loadCustomers($conn) {
        $sql = "SELECT customer_id, CONCAT(firstname,' ',lastname) as fullname FROM customer";

        if($result = mysqli_query($conn, $sql)) {
            if(mysqli_num_rows($result) > 0) {
                // load data
                while($row = mysqli_fetch_array($result)) { 
                    echo "<option value='{$row['customer_id']}'>{$row['fullname']}</option> ";
                }
            }
        }
    }

    // LOADING PRODUCTS
    function loadProducts($conn,$category) {
        $sql = "SELECT id, prod_name, prod_sellingprice, prod_image,
        ((COALESCE(
            (SELECT SUM(inv_itemqty) FROM inventoryitems d WHERE d.prod_id = a.id AND
            d.inv_action = 'addstock' GROUP BY a.id),0) - 
        COALESCE(
            (SELECT SUM(inv_itemqty) FROM inventoryitems d WHERE d.prod_id = a.id AND
                d.inv_action = 'checkout' GROUP BY a.id),0)) - 
        (COALESCE(
            (SELECT SUM(quantity) FROM transactiondetails d WHERE d.prod_id = a.id 
                GROUP BY a.id),0) + 
        COALESCE(
            (SELECT SUM(quantity) FROM for_purchase e WHERE e.prod_id = a.id 
            GROUP BY a.id),0) + 
        COALESCE(
            (SELECT SUM(quantity) FROM orderDetails f WHERE f.prod_id = a.id AND
            (SELECT order_status FROM orderhistory WHERE order_id = f.order_id) = 'FOR PAYMENT' 
            GROUP BY a.id),0)
            )) AS OnHand 
        FROM products a WHERE a.prod_cat = 
        (SELECT cat_id from category WHERE cat_name = '".$category."')";

        if($result = mysqli_query($conn, $sql)) {
            if(mysqli_num_rows($result) > 0) {
                // load data
                while($row = mysqli_fetch_array($result)) { 
                    if ($row['OnHand'] > 0) {

                    //echo $row['prod_name'] . " "; ?>
                    <div class="col-sm-3 stretch-card text-sm-center mb-3">
                        <div class="card">
                            <div class="card-body m-0 ml-2 mr-2 p-0 pt-2">
                                <form action="../../objects/pos.php" method="POST">
                                    <img class="card-img"  height="300" width="200" src="<?php echo '../../images/products/'. $row['prod_image']; ?>" alt="image">
                                    <p class="card-title mt-2 mb-2"><?php echo $row['prod_name']; ?></p>
                                    <p class="card-description mb-2"><?php echo $row['prod_sellingprice']; ?></p> 
                                    <p class="card-description mb-2">Available : <?php echo getStock($conn, $row['id']); ?></p> 
                                    <input type="hidden" name="prod_id" value="<?php echo $row['id']; ?>">
                                    <input type="hidden" name="productName" value="<?php echo $row['prod_name']; ?>">
                                    <input type="hidden" name="qty" value="1">
                                    <input type="hidden" name="productPrice" value="<?php echo $row['prod_sellingprice']; ?>">
                                    <button type="submit" name="add-item" class="btn btn-primary btn-icon-text btn-flat btn-sm mt-0 mb-2">
                                        Add
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php }}
            } 
        }
    }

    // POPULATING ORDER LIST
        // ADDING / SUBTRACT QUANTITY TO EXISTING PRODUCT
        if (isset($_GET['process'])) {
            include_once '../database/connection.php';  

            if($_GET['process'] == 'add') {
                $prod_id = $_GET['prod_id'];

                $sql = "SELECT prod_id, quantity FROM for_purchase WHERE prod_id = " .$prod_id;
    
                if($result = mysqli_query($dbConn, $sql)) {
                    if(mysqli_num_rows($result) > 0) {
                        $row = mysqli_fetch_array($result);
                        $qty = $row['quantity'] + 1;
    
                        // UPDATE quantity of current order
                        $sql = "UPDATE for_purchase SET quantity = ? WHERE prod_id = ?";
    
                        if($stmt = mysqli_prepare($dbConn, $sql)){
                            // Bind variables to the prepared statement as parameters
                            mysqli_stmt_bind_param($stmt, "ii", $qty, $prod_id);
                        
                            // Attempt to execute the prepared statement
                            if(mysqli_stmt_execute($stmt)){ 
                                pageRedirect("../pages/pos/pos_order.php");
                            } else {
                                echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
                            }
                        }
                    } 
                }
            } 
            
            if($_GET['process'] == 'subtract') {
                $prod_id = $_GET['prod_id'];

                $actual_qty = getForPurchaseQty($dbConn,$prod_id);
                echo "<script>console.log('{$actual_qty}');</script>";
                if($actual_qty > 1) {
                    $actual_qty -= 1;
                    echo "<script>console.log('{$actual_qty}');</script>";
                    // UPDATE quantity of current order
                    $sql = "UPDATE for_purchase SET quantity = ? WHERE prod_id = ?";

                    if($stmt = mysqli_prepare($dbConn, $sql)){
                        // Bind variables to the prepared statement as parameters
                        mysqli_stmt_bind_param($stmt, "ii", $actual_qty, $prod_id);
                    
                        // Attempt to execute the prepared statement
                        if(mysqli_stmt_execute($stmt)){ 
                            pageRedirect("../pages/pos/pos_order.php");
                        } else {
                            echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
                        }
                    }
                } 
            }
            
        }

        // ADDING ORDER / ADDING QUANTITY - VIA PRODUCT SELECT
        if (isset($_POST['add-item'])) {
            include_once '../database/connection.php';  

            $prod_id = htmlspecialchars($_POST['prod_id']);
            $name = htmlspecialchars($_POST['productName']);
            $qty = htmlspecialchars($_POST['qty']);
            $price = htmlspecialchars($_POST['productPrice']);

            $sql = "SELECT quantity FROM for_purchase WHERE prod_id = {$prod_id}";

            if($result = mysqli_query($dbConn, $sql)) {
                if(mysqli_num_rows($result) > 0) {
                    $row = mysqli_fetch_array($result);
                    $qty += $row['quantity'];

                    // UPDATE quantity of current order
                    $sql = "UPDATE for_purchase SET quantity = ? WHERE prod_id = ?";

                        if($stmt = mysqli_prepare($dbConn, $sql)){
                        // Bind variables to the prepared statement as parameters
                        mysqli_stmt_bind_param($stmt, "ii", $qty, $prod_id);
                    
                        // Attempt to execute the prepared statement
                        if(mysqli_stmt_execute($stmt)){ 
                            pageRedirect("../pages/pos/pos_order.php");
                        } else {
                            echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
                        }
                    }
                } else {
                    // ADD
                    addOrder($prod_id, $name, $qty, $price, $dbConn);
                }  
            }
        }

        // ADD PRODUCT TO ORDER LIST
        function addOrder($prod_id, $product, $qty, $price, $conn) {           
            // Sanitize and Set parameters
            $prod_id = htmlspecialchars($prod_id);
            $product = htmlspecialchars($product);
            $qty = htmlspecialchars($qty);
            $price = htmlspecialchars($price);

            $sql = "INSERT INTO for_purchase(prod_id, prod_name, quantity, prod_price)
                    VALUES(?, ?, ?, ?)";

            if($stmt = mysqli_prepare($conn, $sql)){
                // Bind variables to the prepared statement as parameters
                mysqli_stmt_bind_param($stmt, "isis", $prod_id, $product, $qty, $price);
            
                // Attempt to execute the prepared statement
                if(mysqli_stmt_execute($stmt)){
                    pageRedirect('../pages/pos/pos_order.php');
                } else {
                    echo "ERROR: Could not execute query: $sql. " . mysqli_error($conn);
                }
            }
        }

    //LOADING ORDER
    function loadOrders($conn) {
        $sql = "SELECT * FROM for_purchase";

        if($result = mysqli_query($conn, $sql)) {
            if(mysqli_num_rows($result) > 0) {
                // populate data to table

                while($row = mysqli_fetch_array($result)) {
                    $item_subTotal = number_format($row['quantity']  * str_replace('P','',$row['prod_price']),2);
                    //$item_row_id = $row['id'];
                    $prod_id = $row['prod_id'];
                    $current_stock = getStock($conn,$prod_id);
                    echo "<tr>";

                        echo "<td hidden>" . $row['id'] . "</td>";
                        echo "<td>" . $row['prod_name'] . "</td>";
                        echo "<td>" . $row['quantity'] . "</td>";
                        echo "<td>" . $row['prod_price'] . "</td>";
                        echo "<td>" .  $item_subTotal . "</td>";
                        echo "<td>";
                        if($current_stock != 0) {
                            //echo " <input type='text' name='additem_id' value='{$prod_id}' hidden/>
                            echo " <a href='../../objects/pos.php?prod_id={$prod_id}&process=add' data-toggle='tooltip' title='Add'>
                                <button name='add_qty' type='submit' class='btn btn-primary btn-sm'><i class='ti-plus btn-icon-prepend'></i></button>                     
                            </a>"; 
                        } else {
                            echo " <a data-toggle='tooltip' title='Add'>
                                <button name='add_qty' type='submit' class='btn btn-primary btn-sm' disabled><i class='ti-plus btn-icon-prepend'></i></button>                     
                            </a>"; 
                        }
                        
                        if($row['quantity'] > 1) {
                            //echo " <input type='text' name='subtractitem_id' value='{$prod_id}' hidden/>
                            echo "<a href='../../objects/pos.php?prod_id={$prod_id}&process=subtract' data-toggle='tooltip' title='Subtract'>
                            <button name='subtract_qty' type='submit' class='btn btn-danger btn-sm'><i class='ti-minus btn-icon-prepend'></i></button>
                        </a>";  
                        } else {
                            echo " <a data-toggle='tooltip' title='Subtract'>
                            <button name='subtract_qty' type='submit' class='btn btn-danger btn-sm' disabled><i class='ti-minus btn-icon-prepend'></i></button>
                        </a>";  
                        }               
                    echo "  </td>";
                    echo "</tr>";

                }

            } else {
                // echo "<tr> No record/s found.</tr>";
            }
        }
    }

    // LOAD CURRENT GRAND TOTAl
    function loadTotal($conn) {

            $subTotal = 0;

            $sql = "SELECT quantity, prod_price FROM for_purchase";
    
            if($result = mysqli_query($conn, $sql)) {
                if(mysqli_num_rows($result) > 0) {
                    // load data
                    while($row = mysqli_fetch_array($result)) {
                        $price = $row['quantity'] * number_format(str_replace('P','',$row['prod_price']),2);
                        $subTotal += $price;
                    }
                }
            }
            $vatable = $subTotal / 1.12;
            $vat = $vatable * 0.12;
            $grandTotal = $vatable + $vat;
    
            $vatable = number_format($vatable, 2);
            $vat = number_format($vat, 2);
    
    
            echo '<table class="table table-borderless">';
            echo '<tbody>';
            echo '<tr>
                    <td>Vatable</td>
                    <td class=" col-sm-7 border text-right">'.$vatable.'</td>
                 </tr>';
            echo '<tr>
                    <td>Vat</td>
                    <td class="col-sm-7 border text-right">'.$vat.'</td>
                 </tr>';
            echo '<tr>
                    <td>Total</td>
                    <td class="col-sm-7 border text-right">'.number_format($grandTotal,2).'</td>
                 </tr>';
            echo    '</tbody>';
            echo '</table>';

            echo '';
            if($grandTotal == 0) {
                echo '<div class="text-md-right mt-2 d-flex ">
                <a>
                    <button type="submit" name="cancel" class="btn btn-warning btn-icon-text btn-flat btn-block btn-md mt-0 mr-4 pr-8" disabled>
                    CANCEL
                    </button>
                </a>
                <button type="submit" name="process_order" class="btn btn-primary btn-icon-text btn-flat btn-block btn-md mt-0 ml-1" disabled>
                    PROCESS ORDER
                </button>
                </div>';
            } else {
                echo '<div class="text-md-right mt-2 d-flex">
                <a>
                    <button type="submit" name="cancel" class="btn btn-warning btn-icon-text btn-flat btn-block btn-md mt-0 mr-4 pr-8">
                        CANCEL
                    </button>
                </a>
                <button type="submit" name="process_order" class="btn btn-primary btn-icon-text btn-flat btn-block btn-md mt-0 ml-1">
                    PROCESS ORDER
                </button>
                </div>';
            }
           echo '</form>';
    }


    // CHECKOUT
    if(isset($_POST['process_order'])) {       
        include_once '../database/connection.php';
        processCheckout($dbConn);    
    } else if(isset($_POST['cancel'])) { 
        include_once '../database/connection.php';
        clearPurchaseTable($dbConn); 
    }


    
    function processCheckout($conn) {        
        
            // Prepare Checkout Summary
            $sql = "SELECT * FROM for_purchase";
        
            /* Items and Subtotals */
            $totalItems = 0;
            $subTotal = 0;
            $user = htmlspecialchars($_SESSION['logged_user']); // retrieve logged user
            $customer_id = htmlspecialchars($_POST['customer_list']);
            $order_status = "FOR PAYMENT";
    
            if($result = mysqli_query($conn, $sql)) {
                if(mysqli_num_rows($result) > 0) {
                    // load data
                    while($row = mysqli_fetch_array($result)) {
                        $price = $row['quantity'] * number_format(str_replace('P','',$row['prod_price']),2);
                        $totalItems += $row['quantity'];
                        $subTotal += $price;
                    }
                }
            }
            // CREATE OrderHistory Record
            $sql = "INSERT INTO orderhistory(customer_id, totalOrders, totalPrice, order_status, createdby)
            VALUES(?, ?, ?, ?, ?)";
    
            if($stmt = mysqli_prepare($conn, $sql)){
                // Bind variables to the prepared statement as parameters
                mysqli_stmt_bind_param($stmt, "iisss", $customer_id, $totalItems, $subTotal, $order_status, $user);
    
                // Attempt to execute the prepared statement
                if(mysqli_stmt_execute($stmt)){
                    // Continue
                } else {
                    echo "ERROR: Could not execute query: $sql. " . mysqli_error($conn);
                }
            }
    
            // RETRIEVE Order Number
            $order_no = '';
            $order_date = '';
            $sql = "SELECT order_id, orderDate FROM orderhistory ORDER BY order_id DESC LIMIT 1";
    
            if($result = mysqli_query($conn, $sql)) {
                if(mysqli_num_rows($result) > 0) {
                    $row = mysqli_fetch_array($result);
                        $order_no = $row['order_id']; // set transaction number
                        $order_date = $row['orderDate']; // set transaction date
                }
            }
    
            // CREATE OrderDetails Record
            $sql = "INSERT INTO orderDetails(order_id, orderDate, prod_id, item, quantity, price, totalprice)
            SELECT ?, ?, a.prod_id, a.prod_name, a.quantity, a.prod_price, (a.quantity * a.prod_price)
            FROM for_purchase a";
    
            if($stmt = mysqli_prepare($conn, $sql)){
                // Bind variables to the prepared statement as parameters
                mysqli_stmt_bind_param($stmt, "is", $order_no, $order_date);
    
                // Attempt to execute the prepared statement
                if(mysqli_stmt_execute($stmt)){
                    // SET AUDIT LOGS
                    $sql = "INSERT INTO auditlogs(user_id, user_action, actiondescription)
                    VALUES(?, ?, ?)";

                    if($stmt = mysqli_prepare($conn, $sql)){
                        // Set parameters
                        $log_userid = $_SESSION['logged_user_id'];
                        $log_action = "CHECKOUT";
                        $log_desc = "Processed Order. Order number: " .$order_no;

                        // Bind variables to the prepared statement as parameters
                        mysqli_stmt_bind_param($stmt, "iss", $log_userid, $log_action, $log_desc);
                        
                        // Attempt to execute the prepared statement
                        if(mysqli_stmt_execute($stmt)){
                            // PREPARES CONFIRMATION MESSAGE
                            $error = "<span class='text-success'>Order Created Successfully</span>";
                            $_SESSION['errormsg'] = $error;

                            // CLEAR TABLE
                            clearPurchaseTable($conn); 
                        } else {
                            //echo "ERROR: Could not execute query: $sql. " . mysqli_error($conn);
                            // PREPARES ERROR MESSAGE
                            $error = "<span class='text-danger'>Unable to process request</span>";
                            $_SESSION['errormsg'] = $error;

                            header('location : ../pages/pos/pos_order.php');
                            exit;
                        }
                    } else{
                        echo "ERROR: Could not prepare query: $sql. " . mysqli_error($conn);
                    }
                } else {
                    echo "ERROR: Could not execute query: $sql. " . mysqli_error($conn);
                }
            }
    }

    // CLEAR PURCHASE TABLE
    function clearPurchaseTable($conn) {
        $sql = "DELETE FROM for_purchase";

        if($stmt = mysqli_prepare($conn, $sql)){
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                pageRedirect('../pages/pos/pos_order.php');
            } else {
                echo "ERROR: Could not execute query: $sql. " . mysqli_error($conn);
            }
        }
    }

    ob_end_flush();
?>