<?php
    function loadTransactionHistory($conn) {
        $sql = "SELECT a.transactionNo, a.transactionDate,
        (SELECT CONCAT(firstname,' ', lastname) FROM customer WHERE customer_id = a.customer_id) as fullname,
        a.itemsSold, a.totalPrice, a.createdby 
        FROM transactionhistory a";

        if($result = mysqli_query($conn, $sql)) {
            if(mysqli_num_rows($result) > 0) {
                // populate data to table

                while($row = mysqli_fetch_array($result)) {
                    echo '<tr>';
                        echo '<td>'.$row['transactionNo'].'</td>';
                        echo '<td>'.$row['transactionDate'].'</td>';
                        echo '<td>'.$row['fullname'].'</td>';
                        echo '<td>'.$row['itemsSold'].'</td>';
                        echo '<td>'.$row['totalPrice'].'</td>';
                        echo '<td>'.$row['createdby'].'</td>';
                        echo '<td>
                            <a href="sales-details.php?t_no='.$row['transactionNo'].'" data-toggle="tooltip" title="Edit">
                                <button type="button" class="btn btn-primary btn-sm btn-rounded" data-toggle="modal" data-target="#edit-Sales"><i class="ti-pencil-alt btn-icon-prepend"></i></button>
                            </a>
                      </td>';
                    echo '</tr>';
                }
            } 
        }
    }

    function loadTransactionDetailsHeader($conn,$transNO) {
        $sql = "SELECT transactionNo, Date(transactionDate) as transactionDate FROM transactionHistory WHERE transactionNo = " .$transNO;
        if($result = mysqli_query($conn, $sql)) {
            if(mysqli_num_rows($result) > 0) {
                // populate data to table

                while($row = mysqli_fetch_array($result)) {
                    echo '<div class="ml-2">';
                        echo '<table>
                                <tr>
                                    <td class="pr-4 pb-2">Transaction Number:</td>
                                    <td>'.$row['transactionNo'].'</td>
                                </tr>
                                <tr>
                                    <td class="pr-4 pb-2">Transaction Date:</td>
                                    <td>'.$row['transactionDate'].'</td>
                                </tr>
                            </table>';
                    echo '</div>';
                }
            } 
        }
    }

    function loadTransactionDetails($conn,$transNO) {
        $sql = "SELECT * FROM transactionDetails WHERE transactionNo = " .$transNO;
        if($result = mysqli_query($conn, $sql)) {
            if(mysqli_num_rows($result) > 0) {
                // populate data to table

                while($row = mysqli_fetch_array($result)) {
                    echo '<tr>';
                        echo '<td>'.$row['item'].'</td>';
                        echo '<td>'.$row['quantity'].'</td>';
                        echo '<td>'.$row['price'].'</td>';
                        echo '<td>'.$row['totalPrice'].'</td>';
                    echo '</tr>';
                }
            } 
        }
    }
?>
