<?php
    if(session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    if (isset($_POST['emp_create'])) {
        createEmployee($_POST['emp_fname'], $_POST['emp_lname'], $_POST['emp_gender'], $_POST['emp_contactno']);
    } elseif(isset($_POST['customer_edit'])) {
        // updateAccount($_POST['user_id'], $_POST['user_fname'], $_POST['user_lname'], $_POST['user_position'], 
        // $_POST['user_acctname'], $_POST['user_contactno'], $_POST['user_level'], $_POST['user_status']);
    } 
    
    function loadEmployees($conn) {
        $sql = "SELECT * FROM employee";

        if($result = mysqli_query($conn, $sql)) {
            if(mysqli_num_rows($result) > 0) {
                // load data
                while($row = mysqli_fetch_array($result)) {
                    echo "<tr>";
                        echo "<td>" . $row['firstname'] . "</td>";
                        echo "<td>" . $row['lastname'] . "</td>";
                        echo "<td>" . $row['gender'] . "</td>";
                        echo "<td>" . $row['contactno'] . "</td>";                      
                        echo "<td>
                            <a href='employee-edit.php?id=".$row['emp_id']."' data-toggle='tooltip' title='Edit'>
                            <button type='button' class='btn btn-primary btn-sm btn-rounded' data-toggle='modal' data-target='#edit-Users'><i class='ti-pencil-alt btn-icon-prepend'></i></button>
                            </a>"; ?>
                            <a href="employee.php?del=<?php echo htmlentities($row['emp_id']);?>" onclick="return confirm('Are you sure you want to delete?');" data-toggle="tooltip" title="Delete">
                              <button type="button" class="btn btn-danger btn-sm btn-rounded" data-toggle="modal" data-target="#delete-Category"><i class="ti-trash btn-icon-prepend"></i></button>
                            </a>
                    <?php echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr> No record/s found.</tr>";
            }
        }
    }

    function loadEmployeeDetails($conn, $id) {
        $sql = "SELECT * FROM users where User_id = " .$id;

        if($result = mysqli_query($conn, $sql)) {
            if(mysqli_num_rows($result) > 0) {
                // load data
                while($row = mysqli_fetch_array($result)) {
                    echo '<input type="text" id="User ID" name="user_id" value="'.$id.'" hidden>
                            <div class="form-group col-md-12">
                                <label for="First Name">First Name</label>
                                <input type="text" class="form-control" id="First Name" name="user_fname" value="'.$row['FirstName'].'" placeholder="First Name">
                            </div>
                            <div class="form-group col-md-12">
                                <label for="Last Name">Last Name</label>
                                <input type="text" class="form-control" id="Last Name" name="user_lname"  value="'.$row['LastName'].'" placeholder="Username">
                            </div>
                            <div class="form-group col-md-12">
                                <label for="Contact Number">Contact Number</label>
                                <input type="text" class="form-control" id="Contact Number" name="user_contactno"  value="'.$row['contactno'].'" placeholder="Contact Number">
                            </div>';
                }
            }
        }
        
    }

    function createEmployee($fname, $lname, $gender, $contactno) {
        include_once '../database/connection.php'; 

        // Sanitize and Set parameters
        $fname = htmlspecialchars($fname);
        $lname = htmlspecialchars($lname);
        $gender = htmlspecialchars($gender);
        $contactno = htmlspecialchars($contactno);

        $sql = "INSERT INTO employee(firstname, lastname, gender, contactno)
                VALUES(?, ?, ?, ?)";

        if($stmt = mysqli_prepare($dbConn, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssss", $fname, $lname, $gender, $contactno);
        
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // PREPARES CONFIRMATION MESSAGE
                $error = "<span class='text-success'>Created Successfully</span>";
                $_SESSION['errormsg'] = $error;

                header('location: ../pages/employee/employee.php');
                exit;
            } else {
                // echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
                // PREPARES ERROR MESSAGE
                $error = "<span class='text-danger'>Unable to process request</span>";
                $_SESSION['errormsg'] = $error;

                header('location: ../pages/employee/employee.php');
                exit;
            }
        }
    }

    function updateEmployee($conn, $id, $fname, $lname, $gender, $contactno) {
        //include_once '../database/connection.php'; 

        //Set parameters 
        $sql = "UPDATE employee SET 
                firstname = ?, lastname = ?, gender = ?, contactno = ? WHERE emp_id = ?";

        if($stmt = mysqli_prepare($conn, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssssi", $fname, $lname, $gender, $contactno, $id);
        
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
            // PREPARES CONFIRMATION MESSAGE
            $error = "<span class='text-success'>Updated Successfully</span>";
            $_SESSION['errormsg'] = $error;

                header('location: employee.php');
                exit;
            } else {
                // echo "ERROR: Could not execute query: $sql. " . mysqli_error($conn);
                // PREPARES ERROR MESSAGE
                $error = "<span class='text-danger'>Unable to process request</span>";
                $_SESSION['errormsg'] = $error;

                header('location: employee.php');
                exit;
            }
        }
    }
?>