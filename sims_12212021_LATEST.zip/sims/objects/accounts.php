<?php
    

    if (isset($_POST['user_create'])) {
        createAccount($_POST['user_fname'], $_POST['user_lname'], $_POST['user_position'], 
        $_POST['user_acctname'], $_POST['user_contactno'], $_POST['user_level']);
    
    } elseif(isset($_POST['user_edit'])) {
        updateAccount($_POST['user_id'], $_POST['user_fname'], $_POST['user_lname'], $_POST['user_position'], 
        $_POST['user_acctname'], $_POST['user_contactno'], $_POST['user_level'], $_POST['user_status']);
    } 
    
    function loadAccounts($conn) {
        $sql = "SELECT * FROM users";

        if($result = mysqli_query($conn, $sql)) {
            if(mysqli_num_rows($result) > 0) {
                // load data
                while($row = mysqli_fetch_array($result)) {
                    echo "<tr>";
                        echo "<td>" . $row['FirstName'] . "</td>";
                        echo "<td>" . $row['LastName'] . "</td>";
                        echo "<td>" . $row['position'] . "</td>";
                        echo "<td>" . $row['User_Level'] . "</td>";
                        echo "<td>" . $row['User_Name'] . "</td>";
                        echo "<td>" . $row['contactno'] . "</td>";

                        if ($row['User_Status'] == 1) {
                            echo "<td>ACTIVE</td>";
                        } else {
                            echo "<td>DEACTIVATED</td>";
                        }
                        
                       
                        echo "<td>
                            <a href='../users/users-edit.php?id=".$row['User_id']."' data-toggle='tooltip' title='Edit'>
                            <button type='button' class='btn btn-primary btn-sm btn-rounded' data-toggle='modal' data-target='#edit-Users'><i class='ti-pencil-alt btn-icon-prepend'></i></button>
                            </a>
                        </td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr> No record/s found.</tr>";
            }
        }
    }

    function loadAccount($conn, $id) {
        $sql = "SELECT * FROM users where User_id = " .$id;

        if($result = mysqli_query($conn, $sql)) {
            if(mysqli_num_rows($result) > 0) {
                // load data
                while($row = mysqli_fetch_array($result)) {
                    echo '<input type="text" id="User ID" name="user_id" value="'.$id.'" hidden>
                            <div class="form-group col-md-12">
                                <label for="First Name">First Name</label>
                                <input type="text" class="form-control" id="First Name" name="user_fname" value="'.$row['FirstName'].'" placeholder="First Name">
                            </div>
                            <div class="form-group col-md-12">
                                <label for="Last Name">Last Name</label>
                                <input type="text" class="form-control" id="Last Name" name="user_lname"  value="'.$row['LastName'].'" placeholder="Last Name">
                            </div>
                            <div class="form-group col-md-12">
                                <label for="Position">Position</label>
                                <select class="form-control" name="user_position">';
                                if ($row['position'] == "Administrator") {
                                    echo '<option selected value="Administrator">Administrator</option>
                                            <option value="Manager">Manager</option>    
                                            <option value="Supervisor">Supervisor</option>    
                                            <option value="Staff">Staff</option>';
                                } 
                                
                                if ($row['position'] == "Manager") {
                                    echo '<option value="Administrator">Administrator</option> 
                                            <option selected value="Manager">Manager</option>
                                            <option value="Supervisor">Supervisor</option>  
                                            <option value="Staff">Staff</option>';
                                } 
                                
                                if ($row['position'] == "Supervisor") {
                                    echo '<option value="Administrator">Administrator</option> 
                                            <option value="Manager">Manager</option>    
                                            <option selected value="Supervisor">Supervisor</option>
                                            <option value="Staff">Staff</option> ';
                                } 
                                
                                if ($row['position'] == "Staff") {
                                    echo '<option value="Administrator">Administrator</option> 
                                            <option value="Manager">Manager</option>    
                                            <option value="Supervisor">Supervisor</option>  
                                            <option selected value="Staff">Staff</option>';
                                }
                     echo '</select>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="User Level">User Level</label>
                                <select class="form-control" name="user_level">';
                                if ($row['User_Level'] == "1") {
                                    echo '<option value="1">1</option>    
                                    <option value="2">2</option>    
                                    <option value="3">3</option> ';
                                }
                                if ($row['User_Level'] == "2") {
                                    echo '<option selected value="1">1</option>    
                                    <option selected value="2">2</option>    
                                    <option value="3">3</option> ';
                                }
                                if ($row['User_Level'] == "3") {
                                    echo '<option value="1">1</option>    
                                    <option value="2">2</option>    
                                    <option selected value="3">3</option> ';
                                }
                               
                    echo       '</select>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="Status">Status</label>
                                <select class="form-control" name="user_status">;';
                                if ($row['User_Status'] == 1) {
                                    echo '<option selected value="1">ACTIVE</option>    
                                    <option value="0">DEACTIVATED</option> ';
                                }
                                if ($row['User_Status'] == 0) {
                                    echo '<option value="1">ACTIVE</option>    
                                    <option selected value="0">DEACTIVATED</option> ';
                                }
                    echo        '</select>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="User Name">User Name</label>
                                <input type="text" class="form-control" id="User Name" name="user_acctname"  value="'.$row['User_Name'].'" placeholder="User Name">
                            </div>
                            <div class="form-group col-md-12">
                                <label for="Contact Number">Contact Number</label>
                                <input type="text" class="form-control" id="Contact Number" name="user_contactno"  value="'.$row['contactno'].'" placeholder="Contact Number">
                            </div>';
                }
            }
        }
        
    }

    function createAccount($fname, $lname, $position, $username, $contactno, $userlevel) {
        include_once '../database/connection.php'; 

        // Sanitize and Set parameters
        $fname = htmlspecialchars($fname);
        $lname = htmlspecialchars($lname);
        $position = htmlspecialchars($position);
        $contactno = htmlspecialchars($contactno);
        $username = htmlspecialchars($username);
        $pword = htmlspecialchars(1234); // DEFAULT PASSWORD
        $userlevel = htmlspecialchars($userlevel);
        $status = htmlspecialchars(1); // DEFAULT STATUS

        $sql = "INSERT INTO users(LastName, FirstName, contactno, position, User_Name, User_Pass, User_Level, User_Status)
                VALUES(?, ?, ?, ?, ?, ?, ?, ?)";

        if($stmt = mysqli_prepare($dbConn, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssisssii", $lname, $fname, $contactno, $position, $username, $pword, $userlevel, $status);
        
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // PREPARES CONFIRMATION MESSAGE
                $error = "<span class='text-success'>Created Successfully</span>";
                $_SESSION['errormsg'] = $error;

                header('location: ../pages/users/users.php');
                exit;
            } else {
                // echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
                // PREPARES ERROR MESSAGE
                $error = "<span class='text-danger'>Unable to process request</span>";
                $_SESSION['errormsg'] = $error;

                header('location: ../pages/users/users.php');
                exit;
            }
        }
    }

    function updateAccount($id, $fname, $lname, $position, $username, $contactno, $userlevel, $status) {
        include_once '../database/connection.php'; 

        // Sanitize and Set parameters
        $fname = htmlspecialchars($fname);
        $lname = htmlspecialchars($lname);
        $position = htmlspecialchars($position);
        $contactno = htmlspecialchars($contactno);
        $username = htmlspecialchars($username);
        $userlevel = htmlspecialchars($userlevel);
        $status = htmlspecialchars($status); 
        $id = htmlspecialchars($id); 

        $sql = "UPDATE users SET 
                LastName = ?, FirstName = ?, contactno = ?, position = ?, User_Name = ?,
                 User_Level = ?, User_Status = ?
                WHERE User_id = ?";

        if($stmt = mysqli_prepare($dbConn, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sssssiii", $lname, $fname, $contactno, $position, $username, $userlevel, $status, $id);
        
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // PREPARES CONFIRMATION MESSAGE
                $error = "<span class='text-success'>Updated Successfully</span>";
                $_SESSION['errormsg'] = $error;

                header('location: ../pages/users/users.php');
                exit;
            } else {
                // echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
                // PREPARES ERROR MESSAGE
                $error = "<span class='text-danger'>Unable to process request</span>";
                $_SESSION['errormsg'] = $error;

                header('location: ../pages/users/users.php');
                exit;
            }
        }
    }
?>