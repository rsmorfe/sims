<?php  
    function load_Products($conn) {

        $sql = "SELECT id, prod_name FROM products";
    
        if($result = mysqli_query($conn, $sql)) {
            if(mysqli_num_rows($result) > 0) {
                while( $row = mysqli_fetch_array($result)) {
                    echo '<option value="'.$row['id'].'">'.$row['prod_name'].'</option>';
                }
            } else {
                echo "<tr> No record/s found.</tr>";
            }
        }
      }
?>