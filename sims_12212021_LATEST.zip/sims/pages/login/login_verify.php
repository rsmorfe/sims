<?php
session_start();
include '../../database/connection.php';
$user = "";
$pass = "";
$error = "";

if (isset($_POST['submit'])) {
    $user = htmlspecialchars($_POST['acct_user']);
    $pass = htmlspecialchars($_POST['acct_pass']);

    $sql = "SELECT User_id, FirstName, LastName, User_Name, User_Pass, User_Level, User_Status 
            FROM users WHERE User_Name ='" . $user . "'";

    if ($result = mysqli_query($dbConn, $sql)) {
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_array($result);

            // VALIDATE FIRST IF ACCOUNT IS ACTIVE
            if ($row['User_Status'] == 0) {
                // PREPARES ERROR MESSAGE
                $error = "<span style='color:red'>Account Deactivated. Ask the System Administrator for assistance.</span>";
                $_SESSION['errormsg'] = $error;

                // REDIRECT TO LOGIN PAGE
                header("Location: login.php");
                exit;
            } else {
                if ($user == $row['User_Name'] && $pass == $row['User_Pass']) {
                    // SET SESSION VALUES
                    $_SESSION['fullname'] = $row['FirstName'] . " " . $row['LastName'];
                    $_SESSION['logged_user_id'] = $row['User_id'];
                    $_SESSION['logged_user'] = $user;
                    $_SESSION['access_level'] = $row['User_Level'];

                    // SET USER LOGS
                    $sql = "INSERT INTO userlogs(user_id, actionType, actionDescription)
                            VALUES(?, ?, ?)";

                    if($stmt = mysqli_prepare($dbConn, $sql)){
                        // Set parameters
                        $log_userid = $row['User_id'];
                        $log_action = "SYSTEM ACCESS";
                        $log_desc = "Logged in to the system";

                        // Bind variables to the prepared statement as parameters
                        mysqli_stmt_bind_param($stmt, "iss", $log_userid, $log_action, $log_desc);
                        
                        // Attempt to execute the prepared statement
                        if(mysqli_stmt_execute($stmt)){
                            // CONTINUE

                            // REDIRECT TO HOME PAGE
                            header("Location: ../dashboard/dashboard.php");
                            exit;
                        } else {
                            echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
                        }
                    } else{
                        echo "ERROR: Could not prepare query: $sql. " . mysqli_error($dbConn);
                    }

                    
                } else {
                    // PREPARES ERROR MESSAGE
                    $error = "<span style='color:red'> Incorrect username or password</span>";
                    $_SESSION['errormsg'] = $error;

                // REDIRECT TO LOGIN PAGE
                header("Location: login.php");
                exit;
                }
            }
        } else {
            // PREPARES ERROR MESSAGE
            $error = "<span style='color:red'> Account doesn't exist.</span>";
            $_SESSION['errormsg'] = $error;

            // REDIRECT TO LOGIN PAGE
            header("Location: login.php");
            exit;
        }
    } else {
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($dbConn);
    }
}
