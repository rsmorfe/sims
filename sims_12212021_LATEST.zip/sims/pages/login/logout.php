<?php
    session_start();
    include '../../database/connection.php';
    
    // SET USER LOGS
    $sql = "INSERT INTO userlogs(user_id, actionType, actionDescription) VALUES(?, ?, ?)";

    if($stmt = mysqli_prepare($dbConn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "iss", $log_userid, $log_action, $log_desc);

        // Set parameters
        $log_userid = $_SESSION['logged_user_id'];
        $log_action = "SYSTEM ACCESS";
        $log_desc = "Logged out from the system";

        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            // CONTINUE
        } else {
            echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
        }
    }
    
    $_SESSION = array(); // unset all stored session values
    session_destroy(); 
    header('location: login.php');
    exit;
?>