 <!DOCTYPE html>
<html lang="en">

<?php 
  session_start();
  if (isset($_SESSION['logged_user_id'])) {
    header('location: ../dashboard/dashboard.php');
    exit;
  }
  include '../head.php'; 
?>

<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper" >
      <div class="content-wrapper d-flex align-items-stretch auth auth-img-bg">
        <div class="row flex-grow">
          <div class="col-lg-6 d-flex align-items-center justify-content-center" >
            <div class="auth-form-transparent text-left p-3">
              <div class="brand-logo">
                <center><h2 style="color:#a47000;">DJ Clothing</h2></center>
              </div>
            <?php
                if (isset($_SESSION['errormsg'])) {
                  echo $_SESSION['errormsg'];
                  unset($_SESSION['errormsg']);
                } else {
                  echo "<h6 class='font-weight-light'>Sign in to continue.</h6>";
                }
              ?>
              
              <form class="pt-3" method="POST" action="login_verify.php">
                <div class="form-group">
                  <label for="exampleInputEmail">Username</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="ti-user text-primary"></i>
                      </span>
                    </div>
                    <input type="text" class="form-control form-control-lg border-left-0" id="acct_username" name="acct_user" placeholder="Username" required>
                  </div>
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword">Password</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="ti-lock text-primary"></i>
                      </span>
                    </div>
                    <input type="password" class="form-control form-control-lg border-left-0" id="acct_password" name="acct_pass" placeholder="Password" required>                        
                  </div>
                </div>
                
                <div class="my-3">
                  <button class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn" name="submit">LOGIN</button>
                </div>
                <div class="mb-2 d-flex">
                  
                </div>
                
              </form>
            </div>
          </div>
          <div class="col-lg-6 login-half-bg d-flex flex-row">
            <p class="text-white font-weight-medium flex-grow align-self-end">Copyright &copy; 2021  All rights reserved.</p>
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="../../vendors/base/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="../../js/off-canvas.js"></script>
  <script src="../../js/hoverable-collapse.js"></script>
  <script src="../../js/template.js"></script>
  <script src="../../js/todolist.js"></script>
  <!-- endinject -->
</body>

</html>
