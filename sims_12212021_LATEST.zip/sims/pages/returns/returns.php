
<!DOCTYPE html>
<html lang="en">

<?php 
  session_start();
  if (!isset($_SESSION['logged_user_id'])) {
    header('location: ../login/login.php');
    exit;
  }
  include_once '../../database/connection.php'; 
  include_once 'returns_query.php';
  include '../head.php'; 

  if(isset($_GET['del'])) {
    // // DELETE CUSTOMER
    // $sql = "DELETE FROM customer WHERE customer_id = ?";

    // if($stmt = mysqli_prepare($dbConn, $sql)){
    //     // Bind variables to the prepared statement as parameters
    //     mysqli_stmt_bind_param($stmt, "i", $id);
        
    //     // Set parameters
    //     $id = htmlentities($_GET['del']);
    //     // Attempt to execute the prepared statement
    //     if(mysqli_stmt_execute($stmt)){
    //         header('location: customer.php');
    //         exit;
    //     } else {
    //         echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
    //     }
    // } else {
    //     echo "ERROR: Could not prepare query: $sql. " . mysqli_error($dbConn);
    // }        
  }

?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php include '../navbar.php'; ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <?php include '../sidebar.php'; ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper" style="background-color:#E6D5B8;">
          <div class="row">
            <div class="col-md-12 grid-margin">
              <div class="d-flex justify-content-between align-items-center">
                <div>
                  <button id="addReturns" type="button" class="btn btn-primary btn-icon-text btn-rounded btn-sm" data-toggle="modal" data-target="#add-Returns">
                      <i class="ti-plus btn-icon-prepend"></i>Return Items
                  </button> 
                </div>
                <div>
                  <?php
                    if (isset($_SESSION['errormsg'])) {
                      echo $_SESSION['errormsg'];
                      unset($_SESSION['errormsg']);
                    } 
                  ?>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <p class="card-title text-md-center text-xl-left">Returned Items</p>
                  <div class=" flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                      <table id="example3" class="table table-hover" >
                          <thead style="font-size:10px">
                              <tr>
                                  <th>Transaction No</th>
                                  <th>Date Returned</th>
                                  <th>Item</th>
                                  <th>Quantity</th>
                                  <th>Remarks</th>
                                  <th></th>
                              </tr>
                          </thead>
                          <tbody>
                                  <?php
                                      loadReturns($dbConn);
                                  ?>
                          </tbody>
                      </table>
                  </div>  
                </div>
              </div>
            </div>
          </div>
        </div>
          <?php include '../modals.php'; ?>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
          <?php include '../footer.php'; ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

<?php include '../scripts.php'; ?>
<script>
  // CLEAR MODAL - ADD RETURNS
  $('#add-Returns').on('hidden.bs.modal', function () {
        $('#add-Returns form')[0].reset();
    });
</script>
</body>

</html>

