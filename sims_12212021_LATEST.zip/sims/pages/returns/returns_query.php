<?php
if(session_status() === PHP_SESSION_NONE) {
    session_start();
}

if(isset($_POST['returns_create'])) {
    // Sanitize and Set parameters
    $trans_id = htmlspecialchars($_POST['transactionNo']);
    $prod_id = htmlspecialchars($_POST['prod_id']);
    $qty = htmlspecialchars($_POST['quantity']);
    $remarks = htmlspecialchars($_POST['remarks']);
    $user = htmlspecialchars($_SESSION['logged_user']);

    createReturnsRecord($trans_id, $prod_id, $qty, $remarks, $user);
}

function createReturnsRecord ($trans_id, $prod_id, $qty, $remarks, $user) {
    include_once '../../database/connection.php'; 

    $sql = "INSERT INTO returns_table(transactionNo, prod_id, quantity, remarks, created_by)
            VALUES(?, ?, ?, ?, ?)";

    if($stmt = mysqli_prepare($dbConn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "iiiss", $trans_id, $prod_id, $qty, $remarks, $user);
    
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            // PREPARES CONFIRMATION MESSAGE
            $error = "<span class='text-success'>Created Successfully</span>";
            $_SESSION['errormsg'] = $error;

            header('location: returns.php');
            exit;
        } else {
            // echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
            // PREPARES ERROR MESSAGE
            $error = "<span class='text-danger'>Unable to process request</span>";
            $_SESSION['errormsg'] = $error;

            header('location: returns.php');
            exit;
        }
    }
}

function loadReturns($conn) {
    $sql = "SELECT a.transactionNo, Date(a.return_date) as dateReturned,
            (SELECT prod_name FROM products WHERE id = a.prod_id) as item,
            a.quantity, a.remarks
            FROM returns_table a";

        if($result = mysqli_query($conn, $sql)) {
            if(mysqli_num_rows($result) > 0) {
                // load data
                while($row = mysqli_fetch_array($result)) {
                    echo "<tr>";
                        echo "<td>" . $row['transactionNo'] . "</td>";
                        echo "<td>" . $row['dateReturned'] . "</td>";
                        echo "<td>" . $row['item'] . "</td>";
                        echo "<td>" . $row['quantity'] . "</td>";
                        echo "<td>" . $row['remarks'] . "</td>";
                        // echo "<td>
                        //     <a href='../customer/edit-customer.php?id=".$row['customer_id']."' data-toggle='tooltip' title='Edit'>
                        //     <button type='button' class='btn btn-primary btn-sm btn-rounded' data-toggle='modal' data-target='#edit-Users'><i class='ti-pencil-alt btn-icon-prepend'></i></button>
                        //     </a>"; ?>
                        <!-- <a href="customer.php?del=<?php echo htmlentities($row['customer_id']);?>" onclick="return confirm('Are you sure you want to delete?');" data-toggle="tooltip" title="Delete">
                          <button type="button" class="btn btn-danger btn-sm btn-rounded" data-toggle="modal" data-target="#delete-Category"><i class="ti-trash btn-icon-prepend"></i></button>
                        </a> -->
                    <?php // echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr>
                        <td>No record/s found.</td>
                    </tr>";
            }
        }
}

function returns_loadTransactions($conn) {
    $sql = "SELECT transactionNo FROM transactionhistory";

    $result = "";
    if($result = mysqli_query($conn, $sql)) {
        // load data
        while($row = mysqli_fetch_array($result)) {
            echo '<option value="'.$row['transactionNo'].'">'.$row['transactionNo'].'</option>';
        }
    } else {
        echo "ERROR: Could not execute query: $sql. " . mysqli_error($conn);
    }
}

function returns_loadProducts($conn) {
    $sql = "SELECT id, prod_name FROM products";

    $result = "";
    if($result = mysqli_query($conn, $sql)) {
        // load data
        while($row = mysqli_fetch_array($result)) {
            echo '<option value="'.$row['id'].'">'.$row['prod_name'].'</option>';
        }
    } else {
        echo "ERROR: Could not execute query: $sql. " . mysqli_error($conn);
    }
}
?>