  <!-- partial:../../partials/_navbar.html -->
    <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row" >
    <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center" style="background-color:#4A3933;">
        <a class="navbar-brand brand-logo" href="../dashboard/dashboard.php">  <span class="brand-text logo-lg" style="color:#F0A500;"><b>Dj Clothing</b></span> </a>
      </div>
    <?php
    if(isset($isPOS)) { ?>
      <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end" style="background-color:#4A3933;">

        </button>
    <?php } else { ?>
      <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end" style="background-color:#4A3933;">
        <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
          <span class="ti-view-list"></span>
        </button>
    <?php } ?>
      

        <ul class="navbar-nav navbar-nav-right" >
          
          <li class="nav-item nav-profile dropdown">
            <a class="navbar-brand brand-logo text-center d-flex align-items-center justify-content-center" href="../pos/pos_order.php">  
              <span class="brand-text logo-lg d-flex align-items-center" style="color:#F0A500;">
                <b class="mr-4">POS</b>
              </span> 
            </a>

            <h1 class="mr-5">|</h1>
            
            <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="profileDropdown">
              <img src="../../images/faces/image-icon-face.png" alt="profile"/>
            </a>
          
            
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
              <a class="dropdown-item" href="../users/profile.php">
                <i class="ti-user text-primary"></i>
                Profile
              </a>

              <a class="dropdown-item" href="../users/change-password.php">
                <i class="ti-settings text-primary"></i>
                Change Password
              </a>
              <a class="dropdown-item" href="../login/logout.php">
                <i class="ti-power-off text-primary"></i>
                Logout
              </a>
            </div>
          </li>
          
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="ti-view-list"></span>
        </button>
        
      </div>
    </nav>
    <!-- partial -->