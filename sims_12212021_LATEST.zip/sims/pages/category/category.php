
<!DOCTYPE html>
<html lang="en">

<?php 
  session_start();
  if (!isset($_SESSION['logged_user_id'])) {
    header('location: ../login/login.php');
    exit;
  } 

  include_once '../../database/connection.php'; 
  include '../head.php'; 

  if(isset($_GET['del'])) {
    // DELETE CATEGORY
    $sql = "DELETE FROM category WHERE cat_id = ?";

    if($stmt = mysqli_prepare($dbConn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "i", $id);
        
        // Set parameters
        $id = htmlentities($_GET['del']);
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
          // PREPARES CONFIRMATION MESSAGE
          $error = "<span class='text-success'>Deleted Successfully</span>";
          $_SESSION['errormsg'] = $error;

            header('location: category.php');
            exit;
        } else {
            // echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
            // PREPARES ERROR MESSAGE
            $error = "<span class='text-danger'>Unable to process request</span>";
            $_SESSION['errormsg'] = $error;

            header('location: category.php');
            exit;
        }
    } else {
        echo "ERROR: Could not prepare query: $sql. " . mysqli_error($dbConn);
    }        
  }

  if (isset($_POST['create_category'])) {
    $cat_name = htmlspecialchars($_POST['cat_name']);
    $cat_status = htmlspecialchars($_POST['cat_status']);
    $encodedby = htmlspecialchars($_SESSION['logged_user_id']);

    $sql = "INSERT INTO category(cat_name, cat_status, encodedby)
    VALUES(?, ?, ?)";

    if($stmt = mysqli_prepare($dbConn, $sql)){
      // Bind variables to the prepared statement as parameters
      mysqli_stmt_bind_param($stmt, "sii", $cat_name, $cat_status, $encodedby);

      // Attempt to execute the prepared statement
      if(mysqli_stmt_execute($stmt)){
          // PREPARES CONFIRMATION MESSAGE
          $error = "<span class='text-success'>Created Successfully</span>";
          $_SESSION['errormsg'] = $error;

          header('location: category.php');
          exit;
      } else {
          // echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
          // PREPARES ERROR MESSAGE
          $error = "<span class='text-danger'>Unable to process request</span>";
          $_SESSION['errormsg'] = $error;

          header('location: category.php');
          exit;
      }
    }
  }
?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php include '../navbar.php'; ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <?php include '../sidebar.php'; ?>
      <!-- partial -->
      <div class="main-panel" >
        <div class="content-wrapper" style="background-color:#E6D5B8;">
          <div class="row">
            <div class="col-md-12 grid-margin">
              <div class="d-flex justify-content-center align-items-center">
                <div>
                    <button type="button" class="btn btn-primary btn-icon-text btn-rounded btn-sm" data-toggle="modal" data-target="#add-Category">
                        <i class="ti-plus btn-icon-prepend"></i>Add Category
                    </button> 
                    <p class="mt-4 mb-0 pb-0">
                    <?php
                      if (isset($_SESSION['errormsg'])) {
                        echo $_SESSION['errormsg'];
                        unset($_SESSION['errormsg']);
                      } 
                    ?>
                    </p>
                </div>
              </div>
            </div>
          </div>
          <div class="row justify-content-md-center">
            <div class="col-md-8 grid-margin stretch-card justify-content-md-center" >
              <div class="card">
                <div class="card-body">
                  <p class="card-title text-md-center text-xl-center">Category</p>
                  <div class=" flex-wrap justify-content-center justify-content-md-center justify-content-xl-center ">
                      <table id="example1" class="table table-hover" >
                          <thead style="font-size:10px">
                              <tr>
                                  <th>Name</th>
                                  <th hidden>Status</th>
                                  <th hidden>Date Encoded</th>
                                  <th><center>Action</center></th>
                              </tr>
                          </thead>
                          <tbody>
                          
                          <?php
                                  $sql = "SELECT * FROM category";

                                  if($result = mysqli_query($dbConn, $sql)) {
                                    if(mysqli_num_rows($result) > 0) {
                                      // load data
                                      while($row = mysqli_fetch_array($result)) {
                                        echo "<tr>";
                                          echo "<td>" . $row['cat_name'] . "</td>";
                                          if ($row['cat_status'] == 1 ) {
                                            echo "<td hidden>ACTIVE</td>";
                                          } else {
                                            echo "<td hidden>INACTIVE</td>";
                                          }
                                          echo "<td hidden>" . $row['dateencoded'] . "</td>";
                                          echo '<td class="text-center">
                                            <a class="category_edit" data-id="'.$row['cat_id'].'" href="edit-category.php?id='.$row['cat_id'].'" data-toggle="tooltip" title="Edit">
                                              <button type="button"  class="btn btn-primary btn-sm btn-rounded" data-toggle="modal" data-target="#edit-Category"><i class="ti-pencil-alt btn-icon-prepend"></i></button>
                                            </a>'; ?>
                                            <a href="category.php?del=<?php echo htmlentities($row['cat_id']);?>" onclick="return confirm('Are you sure you want to delete?');" data-toggle="tooltip" title="Delete">
                                              <button type="button" class="btn btn-danger btn-sm btn-rounded" data-toggle="modal" data-target="#delete-Category"><i class="ti-trash btn-icon-prepend"></i></button>
                                            </a>
                                        <?php echo '</td>';
                                        echo "</tr>";
                                      }
                                    } else {
                                      echo "<tr>";
                                        echo "No Record/s found.";
                                      echo "</tr>";
                                    }
                                  }
                                ?>
                            </div>
                          </tbody>
                      </table>
                  </div>  
                </div>
              </div>
            </div>
          </div>
        </div>
          <?php include '../modals.php'; ?>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
          <?php include '../footer.php'; ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

<?php include '../scripts.php'; ?>
<script>
  $(function(){
    // $('.category_edit').click(function(e){
    //   e.preventDefault();
    //   $('#edit-Category').modal('show');
    //   var id = $(this).data('id');
    //   getRow(id);
      
    // });
  });

  // CLEAR MODAL - ADD CATEGORY 
  $('#add-Category').on('hidden.bs.modal', function () {
      $('#add-Category form')[0].reset();
  });

  function getRow(id){
    // $.ajax({
    //   type: 'POST',
    //   url: 'load-category.php',
    //   data: {id:id},
    //   dataType: 'json',
    //   success: function(data){
    //     $('.modal-body #cat_id').val(data.cat_id);
    //     $('.modal-body #cat_name').val(data.cat_name);
    //     $('.modal-body #cat_status select').val(data.cat_status).change();
    //   },   
    //   error: function(xhr, status, error){
    //   console.error(xhr);
    //   } 
    // });

    // $.post( "load-category.php", { id: id })
    // .done(function( data ) {
    //   console.log(data);
    //   $('.modal-body #cat_id').val(data.cat_id);
    //   $('.modal-body #cat_name').val(data.cat_name);
    //   $('.modal-body #cat_status select').val(data.cat_status).change();
    // }).fail(function() {
    //   console.log("error");
    // });
  }
</script>
</body>

</html>

