<?php 
  session_start();
  include_once '../../database/connection.php'; 
  include '../head.php'; 

$id = htmlspecialchars($_POST['id']);
  $sql = "SELECT cat_id, cat_name, cat_status FROM category WHERE cat_id = ".$id;

  $result = $dbConn->query($sql);
  $row = $result->fetch_assoc();
   //$result = mysqli_query($dbConn, $sql);
  //$row = mysqli_fetch_assoc($result);

  echo $row;
  ?>