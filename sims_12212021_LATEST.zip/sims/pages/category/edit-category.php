
<!DOCTYPE html>
<html lang="en">

<?php 
  session_start();
  if (!isset($_SESSION['logged_user_id'])) {
    header('location: ../login/login.php');
    exit;
  } 

  include_once '../../database/connection.php'; 
  include '../head.php'; 


  if (isset($_POST['edit'])) {
    $cat_id = htmlspecialchars($_POST['cat_id']);
    $cat_name = htmlspecialchars($_POST['cat_name']);
    $cat_status = htmlspecialchars($_POST['cat_status']);

    $sql = "UPDATE category SET cat_name = ?, cat_status = ? WHERE cat_id = ?";

    if($stmt = mysqli_prepare($dbConn, $sql)){
      // Bind variables to the prepared statement as parameters
      mysqli_stmt_bind_param($stmt, "sii", $cat_name, $cat_status, $cat_id);

      // Attempt to execute the prepared statement
      if(mysqli_stmt_execute($stmt)){
          // PREPARES CONFIRMATION MESSAGE
          $error = "<span class='text-success'>Updated Successfully</span>";
          $_SESSION['errormsg'] = $error;


          header('location: category.php');
          exit;
      } else {
          // echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
          // PREPARES ERROR MESSAGE
          $error = "<span class='text-danger'>Unable to process request</span>";
          $_SESSION['errormsg'] = $error;

          header('location: category.php');
          exit;
      }
    }
    
  }
?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php include '../navbar.php'; ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <?php include '../sidebar.php'; ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper" style="background-color:#E6D5B8;">
          <div class="row">

          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <p class="card-title text-md-center text-xl-left">Edit Category</p>
                  <div class=" flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                        <form role="form" class="mt-4" method="POST" action="edit-category.php">  
                        <div class="row">
                            <?php
                                $sql = "SELECT * FROM category WHERE cat_id = ".htmlspecialchars($_GET['id']);

                                if($result = mysqli_query($dbConn, $sql)) {
                                    if(mysqli_num_rows($result) > 0) {
                                      // load data
                                      while($row = mysqli_fetch_array($result)) {
                            ?>
                                        <div class="form-group col-md-12">
                                            <label for="Name">Name</label>
                                            <input type="text" class="form-control" id="Cat_id" name="cat_id" value="<?php echo $row['cat_id'];?>" hidden>
                                            <input type="text" class="form-control" id="Name" name="cat_name" value="<?php echo $row['cat_name'];?>" placeholder="Name">
                                        </div>
                                        <div class="form-group col-md-12">
                                        <label for="CategoryStatus">Status</label>
                                        <select class="form-control" id="CategoryStatus" name="cat_status">
                                            <option disabled value="">~~SELECT~~</option>
                                            <?php
                                                if ($row['cat_status'] == 1) {
                                                    echo '<option selected value="1">ACTIVE</option>
                                                    <option value="0">INACTIVE</option>';
                                                } else {
                                                    echo '<option  value="1">ACTIVE</option>
                                                    <option selected value="0">INACTIVE</option>';
                                                }
                                            ?>
                                        </select>
                            <?php
                                      }
                                    }
                                }
                            ?>
                            </div>
                        </div>
                            <button type="submit" class="btn btn-primary btn-rounded" name="edit">Save</button>
                            <a href="category.php">
                                <button   button type="button" class="btn btn-default btn-rounded">Cancel</button>
                            </a>
                            
                        </form>
                  </div>  
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
          <?php include '../footer.php'; ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

<?php include '../scripts.php'; ?>
</body>

</html>

