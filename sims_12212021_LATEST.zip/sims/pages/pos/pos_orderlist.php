<?php
    // GET CUSTOMER
    function getCustomer($conn, $order, $request_type) {
        $customer_name = "";
        $sql = "SELECT a.customer_id, 
        CONCAT(a.firstname,' ', a.lastname) as fullname
        from CUSTOMER a INNER JOIN orderHistory b 
        ON b.customer_id = a.customer_id 
        WHERE b.order_id = {$order}";

        if($result = mysqli_query($conn, $sql)) {
            if(mysqli_num_rows($result) > 0) {
                // populate data to table
                $row = mysqli_fetch_array($result);
                if($request_type == 'id') {
                    return $row['customer_id'];
                } 

                if($request_type == 'name') {
                    return $row['fullname'];
                }
            } else {
                // echo "<tr> No record/s found.</tr>";
            }
        }
    }

    //LOADING ORDER
    function loadOrders($conn) {
        $sql = "SELECT a.order_id, Date(a.orderDate) as orderDate, 
        (SELECT CONCAT(firstname,' ', lastname) from CUSTOMER WHERE customer_id = a.customer_id) as customer,
        a.totalOrders, a.totalPrice 
        FROM orderHistory a WHERE a.order_status = 'FOR PAYMENT'";

        if($result = mysqli_query($conn, $sql)) {
            if(mysqli_num_rows($result) > 0) {
                // populate data to table

                while($row = mysqli_fetch_array($result)) {
                    echo "<tr>";
                        echo "<td>" . $row['order_id'] . "</td>";
                        echo "<td>" . $row['orderDate'] . "</td>";
                        echo "<td>" . $row['customer'] . "</td>";
                        echo "<td>" . $row['totalOrders'] . "</td>";
                        echo "<td>" . $row['totalPrice'] . "</td>";
                        echo "<td>";
                        echo "<a href='pos_payment.php?order_id={$row['order_id']}' data-toggle='tooltip' title='View Order'>
                                    <button name='view_order' type='submit' class='btn btn-primary btn-sm'><i class='ti-receipt btn-icon-prepend'></i></button>                     
                                </a>";           
                    echo "  </td>";
                    echo "</tr>";

                }

            } else {
                // echo "<tr> No record/s found.</tr>";
            }
        }
    }

    // VIEW ORDER SUMMARY
    function viewOrderSummary($conn, $order_id) {
        //echo "<script>alert('prod_id: {$order_id}')</script>";

        $sql = "SELECT * FROM orderDetails WHERE order_id = {$order_id}";

        if($result = mysqli_query($conn, $sql)) {
            if(mysqli_num_rows($result) > 0) {
                // populate data to table

                while($row = mysqli_fetch_array($result)) {
                    echo "<tr>";
                        echo "<td hidden>" . $row['prod_id'] . "</td>";
                        echo "<td>" . $row['item'] . "</td>";
                        echo "<td>" . $row['quantity'] . "</td>";
                        echo "<td>" . $row['price'] . "</td>";
                        echo "<td>" . $row['totalPrice'] . "</td>";
                    echo "</tr>";
                }

            } else {
                // echo "<tr> No record/s found.</tr>";
            }
        }
    }

    // LOAD CURRENT GRAND TOTAl
    function loadTotal($conn,$order_id) {

        $subTotal = 0;

        $sql = "SELECT quantity, price FROM orderDetails WHERE order_id = {$order_id}";

        if($result = mysqli_query($conn, $sql)) {
            if(mysqli_num_rows($result) > 0) {
                // load data
                while($row = mysqli_fetch_array($result)) {
                    $price = $row['quantity'] * number_format(str_replace('P','',$row['price']),2);
                    $subTotal += $price;
                }
            }
        }
        $vatable = $subTotal / 1.12;
        $vat = $vatable * 0.12;
        $grandTotal = $vatable + $vat;

        $vatable = number_format($vatable, 2);
        $vat = number_format($vat, 2);


        echo '<table class="table table-borderless">';
        echo '<tbody>';
        echo '<tr>
                <td>Vatable</td>
                <td class=" col-sm-7 border text-right">'.$vatable.'</td>
             </tr>';
        echo '<tr>
                <td>Vat</td>
                <td class="col-sm-7 border text-right">'.$vat.'</td>
             </tr>';
        echo '<tr>
                <td>Total</td>
                <td class="col-sm-7 border text-right">'.number_format($grandTotal,2).'</td>
             </tr>';
        echo    '</tbody>';
        echo '</table>';

        echo '';

        $onclick_msg = "'Cancel this order?'";      
        if($grandTotal == 0) {
            
            echo '<div class="text-md-right mt-2 d-flex ">
            <a href="pos_payment.php?order_id='.$order_id.'" onclick="return confirm('.$onclick_msg.');">
                    <button type="submit" name="cancel" class="btn btn-warning btn-icon-text btn-flat btn-block btn-md mt-0 mr-4 pr-8" disabled>
                    CANCEL
                    </button>
                </a>
                <button type="submit" name="checkout" class="btn btn-primary btn-icon-text btn-flat btn-block btn-md mt-0 ml-1" disabled>
                    <span class="text-center">CHECKOUT</span>
                </button>
            </div>';
        } else {
            echo '<div class="text-md-right mt-2 d-flex">
                <a href="pos_payment.php?order_id='.$order_id.'" onclick="return confirm('.$onclick_msg.');">
                    <button type="submit" name="cancel" class="btn btn-warning btn-icon-text btn-flat btn-block btn-md mt-0 mr-4 pr-8">
                    CANCEL
                    </button>
                </a>
                <button type="submit" name="checkout" class="btn btn-primary btn-icon-text btn-flat btn-block btn-md mt-0 ml-1">
                CHECKOUT
                </button>
            </div>';
        }
       echo '</form>';
}

function processCheckout($conn, $order_id) {             
    // echo "<script>alert('WORKING')</script>";
    // Prepare Checkout Summary
    $sql = "SELECT * FROM orderDetails WHERE order_id = {$order_id}";

    /* Items and Subtotals */
    $totalItems = 0;
    $subTotal = 0;
    $user = htmlspecialchars($_SESSION['logged_user']); // retrieve logged user
    $customer_id = htmlspecialchars($_POST['customer_id']);
    $payment_type = htmlspecialchars($_POST['payment_type']);

    if($result = mysqli_query($conn, $sql)) {
        if(mysqli_num_rows($result) > 0) {
            // load data
            while($row = mysqli_fetch_array($result)) {
                $price = $row['quantity'] * number_format(str_replace('P','',$row['price']),2);
                $totalItems += $row['quantity'];
                $subTotal += $price;
            }
        }
    }
    // CREATE TrasactionHistory Record
    $sql = "INSERT INTO transactionhistory(customer_id, order_id, itemssold, payment_type, totalprice, createdby)
    VALUES(?, ?, ?, ?, ?, ?)";

    if($stmt = mysqli_prepare($conn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "iiisss", $customer_id, $order_id, $totalItems, $payment_type, $subTotal, $user);

        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            // Continue
        } else {
            echo "ERROR: Could not execute query: $sql. " . mysqli_error($conn);
        }
    }

    // UPDATE Order History
    updateOrderStatus($conn,$order_id);

    // RETRIEVE TransactionHistory Number
    $transaction_no = '';
    $transaction_date = '';
    $sql = "SELECT transactionNo, transactionDate FROM transactionhistory ORDER BY transactionNo DESC LIMIT 1";

    if($result = mysqli_query($conn, $sql)) {
        if(mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_array($result);
                $transaction_no = $row['transactionNo']; // set transaction number
                $transaction_date = $row['transactionDate']; // set transaction date
        }
    }

    // CREATE TransactionDetails Record
    $sql = "INSERT INTO transactiondetails(transactionNo, transactionDate, prod_id, item, quantity, price, totalprice)
    SELECT ?, ?, a.prod_id, a.item, a.quantity, a.price, (a.quantity * a.price)
    FROM orderDetails a WHERE a.order_id = {$order_id}";

    if($stmt = mysqli_prepare($conn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "is", $transaction_no, $transaction_date);

        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            // SET AUDIT LOGS
            $sql = "INSERT INTO auditlogs(user_id, user_action, actiondescription)
            VALUES(?, ?, ?)";

            if($stmt = mysqli_prepare($conn, $sql)){
                // Set parameters
                $log_userid = $_SESSION['logged_user_id'];
                $log_action = "CHECKOUT";
                $log_desc = "Performed checkout. Transaction number: " .$transaction_no;

                // Bind variables to the prepared statement as parameters
                mysqli_stmt_bind_param($stmt, "iss", $log_userid, $log_action, $log_desc);
                
                // Attempt to execute the prepared statement
                if(mysqli_stmt_execute($stmt)){
                    // PREPARES CONFIRMATION MESSAGE
                    // $error = "<span class='text-success'>Created Successfully</span>";
                    // $_SESSION['errormsg'] = $error;


                    // PREPARE RECEIPT
                    $_SESSION['receipt_TN'] = $transaction_no;
                    try {                
                        pageRedirect('../pos/generate_receipt.php');                     
                          
                    } catch (Exception $ex) {
                    echo die($ex->getMessage());
                    }
                    

                          
                } else {
                    echo "ERROR: Could not execute query: $sql. " . mysqli_error($conn);
                }
            } else{
                echo "ERROR: Could not prepare query: $sql. " . mysqli_error($conn);
            }
        } else {
            echo "ERROR: Could not execute query: $sql. " . mysqli_error($conn);
        }
    }
}

function updateOrderStatus($conn, $order_id) {
    $status = "PAID";
    $sql = "UPDATE orderHistory SET order_status = ? WHERE order_id = ?";
    
    if($stmt = mysqli_prepare($conn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "si", $status, $order_id);
    
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){ 
            // NOTHING
        } else {
            echo "ERROR: Could not execute query: $sql. " . mysqli_error($conn);
        }
    }
}

function cancelOrder($conn, $order_id) {
    $sql = "DELETE FROM orderHistory WHERE order_id = ?";
    
    // ORDER HISTORY
    if($stmt = mysqli_prepare($conn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "i", $order_id);
    
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){ 
            // ORDER DETAILS
            $sql = "DELETE FROM orderDetails WHERE order_id = ?";
    
            if($stmt = mysqli_prepare($conn, $sql)){
                // Bind variables to the prepared statement as parameters
                mysqli_stmt_bind_param($stmt, "i", $order_id);
            
                // Attempt to execute the prepared statement
                if(mysqli_stmt_execute($stmt)){ 
                     
                } else {
                    echo "ERROR: Could not execute query: $sql. " . mysqli_error($conn);
                }
            }
        } else {
            echo "ERROR: Could not execute query: $sql. " . mysqli_error($conn);
        }
    }
}

function pageRedirect($location) {

    if($location == '../pos/generate_receipt.php') {
        echo "<script>window.open('{$location}','_blank')</script>";

        //exit(header('location: pos_payment.php'));
    }  
}

?>