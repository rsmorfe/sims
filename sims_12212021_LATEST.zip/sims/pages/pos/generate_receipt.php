<?php
include_once '../../database/connection.php'; 
ob_start();
session_start();
require('../../fpdf/fpdf.php');


/*
[During Instantiation of FPDF]
A4 width : 219mm
default margin : 10mm each side
writable horizontal line : 219 - (10*2) = 189mm

[Using the Cell() function]
Cell(width, height, text, border, end line, [align])
border = (0:no border,1:bordered)
end line = (0:continue,1:new line),
align = (L:left align(default),C:Center,R;Right)

*/

$pdf = new FPDF('p','mm','A4'); // instantiate FPDF

//define new alias for total page numbers
$pdf->AliasNbPages('{pages}');

$pdf->AddPage(); // create page


$pdf->SetFont('Arial','B',14); // Header - School Name


//$pdf->Image('../assets/img/logo2.jpg',10,10,30); // School Logo
$pdf->Ln();
$pdf->Cell(32);
$pdf->Cell(32);$pdf->Cell(32,5,'           ');
$pdf->Ln(); 
$pdf->Cell(32);
$pdf->Cell(130,5,'DJ Clothing',0,0,'C');
$pdf->Ln();

$pdf->SetFont('Arial','',11); // Header - School Address
$pdf->Cell(32);
$pdf->Cell(130,5,'#080 Zone 2 Sitio Pagkakaisa Sucat Muntinlupa City',0,0,'C');
$pdf->Ln();

$pdf->SetFont('Arial','',11); // Header - Contact No
$pdf->Cell(32);
$pdf->Cell(130,5,'Contact No: 0915-216-6780',0,0,'C');
$pdf->Ln();

// Add New Line
$pdf->Ln();
$pdf->Ln();
$pdf->Ln();

// Title
$pdf->SetFont('Arial','B',12); // Header - Contact No
$pdf->Cell(189,5,'SALES INVOICE',0,0,'C'); // max width
$pdf->Ln();
$pdf->Ln();

// Customer Details
$pdf->SetFont('Arial','B',10);
$pdf->Cell(35,7,'Transaction No:',0,0,'R'); 

// Query 1 -- Transaction Number and Customer Name
$transactionNo = $_SESSION['receipt_TN'];
$sql = "SELECT a.transactionNo,
        (SELECT CONCAT(firstname,' ', lastname) FROM customer WHERE customer_id = a.customer_id) as fullname,
        (SELECT address FROM customer WHERE customer_id = a.customer_id) as `address`,
        (SELECT contactno FROM customer WHERE customer_id = a.customer_id) as contactno    
        FROM transactionhistory  a
        WHERE a. transactionNo = {$transactionNo}";

if($result = mysqli_query($dbConn, $sql)) {
    if(mysqli_num_rows($result) > 0) {
      // load data
      while($row = mysqli_fetch_array($result)) {
        $pdf->SetTextColor(255,0,0);
        $pdf->Cell(35,7,$row['transactionNo'],0,0,'L');
        $pdf->SetTextColor(0,0,0);
        $pdf->Cell(90,7,'Date:',0,0,'R'); 
        $pdf->Cell(90,7,date("m/d/Y"),0,0,'');
        $pdf->Ln();
        $pdf->SetTextColor(0,0,0);
        $pdf->Cell(35,7,'Customer Name:',0,0,'R'); 
        $pdf->Cell(35,7,$row['fullname'],0,0,'L');        
        $pdf->Ln();
        $pdf->Cell(35,7,'Mailing Address:',0,0,'R'); 
        $pdf->Cell(40,7,$row['address'],0,0,'L'); 
        $pdf->Ln();
        $pdf->Cell(35,7,'Contact No:',0,0,'R'); 
        $pdf->Cell(40,7,$row['contactno'],0,0,'L'); 
      }
    } 
  }

//$_SESSION['receipt_TN'] = ""; // CLEAR VALUE

// Content
// Content-header
$pdf->Ln();
$pdf->SetFont('Arial','B',10);
$pdf->Cell(100,5,'Product',1,0,''); 
$pdf->Cell(30,5,'Item Price',1,0,'C'); 
$pdf->Cell(25,5,'Quantity',1,0,'C'); 
$pdf->Cell(25,5,'Total Price',1,0,'R'); 
// Content-data
$pdf->SetFont('Arial','',9);
$pdf->Ln();
// Query 2 - Purchased Items
$sql = "SELECT a.prod_name, b.quantity, b.price, b.totalPrice
          FROM transactiondetails b INNER JOIN products a ON a.id = b.prod_id
          WHERE b.transactionNo = {$transactionNo}";

$totalitems = 0;
$subtotal = 0;

if($result = mysqli_query($dbConn, $sql)) {
    if(mysqli_num_rows($result) > 0) {
      // load data
      while($row = mysqli_fetch_array($result)) {
        $pdf->Cell(100,7,$row['prod_name'],0,0,''); 
        $pdf->Cell(30,7,$row['price'],0,0,'R');
        $pdf->Cell(25,7,$row['quantity'],0,0,'C');
        $pdf->Cell(25,7,$row['totalPrice'],0,0,'R');
        $pdf->Ln();

        $totalitems += $row['quantity'];
        $subtotal += $row['totalPrice'];
      }
    } 
  }

$vatable = $subtotal / 1.12;
$vat = $vatable * 0.12;
$grandTotal = $vatable + $vat;

$pdf->Ln();
$pdf->Ln();
$pdf->SetFont('Arial','',11); 
$pdf->Cell(50,5,'___________________________________________________________________________________',0,0,'L');
$pdf->Ln();
$pdf->Cell(50,5,'',0,0,'L');
$pdf->Cell(50,5,'',0,0,'L');
$pdf->Cell(53,7,'No of Items:',0,0,'R');
$pdf->Cell(28,7,$totalitems,0,0,'R');
$pdf->Ln();$pdf->Cell(50,5,'',0,0,'L');
$pdf->Cell(50,5,'',0,0,'L');
$pdf->Cell(53,7,'Vatable:',0,0,'R');
$pdf->Cell(28,7,number_format($vatable,2),0,0,'R');
$pdf->Ln();
$pdf->Cell(50,5,'',0,0,'L');
$pdf->Cell(50,5,'',0,0,'L');
$pdf->Cell(53,7,'VAT:',0,0,'R');
$pdf->Cell(28,7,number_format($vat,2),0,0,'R');
$pdf->Ln();
$pdf->Cell(50,5,'',0,0,'L');
$pdf->Cell(50,5,'',0,0,'L');
$pdf->Cell(53,7,'Subtotal:',0,0,'R');
$pdf->Cell(28,7,number_format($grandTotal,2),0,0,'R');
$pdf->Ln();

$pdf->Output(); // generate pdf on browser
ob_end_flush(); 
?>