<!DOCTYPE html>
<html lang="en">

<?php 
ob_start();
  session_start();
  if (!isset($_SESSION['logged_user_id'])) {
    header('location: ../login/login.php');
    exit;
  }
  
  include_once '../../database/connection.php'; 
  include_once 'pos_orderlist.php';
  include_once '../head.php'; 

 
  $isPOS = true; // FOR navbar 

  // FETCHING and VIEWING SELECTED ORDER, CUSTOMER
  $order_id = '';
  if(isset($_GET['order_id'])) {
    $order_id = htmlspecialchars($_GET['order_id']);
  }

  // FOR CHECKOUT
  if(isset($_POST['checkout'])) {
    processCheckout($dbConn, htmlspecialchars($_POST['order_id']));
  }

  // FOR CANCEL ORDER
  if(isset($_POST['cancel'])) {
    cancelOrder($dbConn, htmlspecialchars($_POST['order_id']));
  }
?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php include '../navbar.php'; ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <?php //include '../sidebar.php'; ?>
      <!-- partial -->
      <div class="main-panel col-md-12 pl-0 pr-0 ">
        <div class="content-wrapper" style="background-color:#E6D5B8;">
          <div class="row">
            <div class="col-md-12 grid-margin">
              <div class="d-flex justify-content-between align-items-center ml-1">
                  <h4>Payment Form</h4>
                  <div class="d-flex justify-content-between align-items-center">
                    <div>
                      <a href="pos_order.php">
                        <button id="payments" type="button" class="btn btn-primary btn-icon-text btn-rounded btn-sm">
                            <i class="ti-list-ol btn-icon-prepend"></i>Process Order
                        </button> 
                      </a>                    
                    </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <div class=" flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                    ORDERS
                  <!-- START Order List-->
                      <div class="row pt-3">                      
                        <div class="col-md-12 grid-margin stretch-card">                          
                            <table class="table table-borderless">
                                <!-- <form action="pos_payment.php" method="POST"> -->
                                    <thead class="border-top border-bottom" style="font-size:10px">
                                        <tr>
                                            <th>Order ID</th>
                                            <th>Date</th>
                                            <th>Customer</th>
                                            <th>Items</th>
                                            <th>Total Price</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                        loadOrders($dbConn);
                                    ?>
                                    </tbody>
                                <!-- </form> -->
                            </table>             
                        </div>   
                      </div>

                    <!-- END Order List-->
                  </div>  
                </div>
              </div> 
            </div>
          </div>
          
          <hr>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <!-- <p class="card-title text-md-center text-xl-left">Users</p> -->
                  <div class=" flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                      <span>CHECKOUT SUMMARY</span>
                      <div class="row pt-3">
                      
                        <div class="col-md-8">
                                <table class="table table-borderless">
                                    <thead class="border-top border-bottom" style="font-size:10px">
                                        <tr>
                                            <th hidden>id</th>
                                            <th>Product</th>
                                            <th>Quantity</th>
                                            <th>Price</th>
                                            <th>Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                        viewOrderSummary($dbConn, $order_id);
                                    ?>
                                    </tbody>
                                </table>
                        </div>
                      <div class="col-md-4">
                        <form action="pos_payment.php" method="POST">
                          <div class="form-group"><input name="order_id" type="text" 
                              value="<?php echo $order_id; ?>" hidden>
                            <label class="col-6" id="customer_name" for="customer_name">Customer Name :</label>
                            <input name="customer_id" type="text" 
                              value="<?php if(isset($_GET['order_id'])) { echo getCustomer($dbConn, $order_id, "id");} else { echo "0";} ?>" hidden>
                            <input name="customer_name" class="col-12 border-0 mb-2" type="text" 
                              value="<?php if(isset($_GET['order_id'])) { echo getCustomer($dbConn, $order_id, "name");} else { echo "------------";} ?>" disabled>
                            
                            <div class="mt-3" style="display: flex;">
                                <div style="flex-grow: 1;">
                                  <label class="pl-4 ml-0 align-center" id="payment_type" for="payment_type">Payment Mode</label>
                                </div>
                                <div class="pl-4 pr-0 col-8">
                                  <select class="form-control" name="payment_type">
                                      <option value='Cash'>Cash</option>
                                      <option value='Credit Card'>Credit Card</option>
                                  </select>
                                </div> 
                              </div>
                          </div>
                          <?php
                            loadTotal($dbConn, $order_id);
                          ?> 
                        </form>
                      </div>   
                    </div>                
                  </div>  
                </div>
              </div>
            </div>
          </div>
        </div>
          <?php include '../modals.php'; ?>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
          <?php include '../footer.php'; ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

<?php include '../scripts.php'; 
     ob_end_flush();

?>
<script>
//   console.log(<?php echo "'".$_SESSION['logged_user']."'"; ?>);
//   setInterval(
//     () => {
//       var label = "DATE TODAY - ";
//       var sys_date = new Date().toLocaleDateString();
//       var sys_time = new Date().toLocaleTimeString();
//       document.getElementById('DateTime').innerHTML = label.concat(sys_date," ", sys_time);     
//     }, 1000);
</script>
</body>

</html>

