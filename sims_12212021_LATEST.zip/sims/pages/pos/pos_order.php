<!DOCTYPE html>
<html lang="en">

<?php 
ob_start();
  session_start();
  if (!isset($_SESSION['logged_user_id'])) {
    header('location: ../login/login.php');
    exit;
  }
  
  include_once '../../database/connection.php'; 
  include_once '../../objects/pos.php';
  include_once '../head.php'; 

 
  $isPOS = true;
  $selectedCategory = "";

  if(isset($_GET['cat'])) {
    $selectedCategory = $_GET['cat'];
  }

?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php include '../navbar.php'; ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <?php //include '../sidebar.php'; ?>
      <!-- partial -->
      <div class="main-panel col-md-12 pl-0 pr-0 ">
        <div class="content-wrapper" style="background-color:#E6D5B8;">
          <div class="row">
            <div class="col-md-12 grid-margin">
              <div class="d-flex justify-content-between align-items-center ml-1">
                  <h4>Product Catalog</h4>
                  <div class="d-flex justify-content-between align-items-center">
                    <div>
                      <a href="pos_payment.php">
                        <button id="payments" type="button" class="btn btn-primary btn-icon-text btn-rounded btn-sm">
                            <i class="ti-receipt btn-icon-prepend"></i>View Orders
                        </button> 
                      </a>                    
                    </div>
                </div>
              </div>
              <div class="ml-1 mt-2">
                <?php
                  if (isset($_SESSION['errormsg'])) {
                    echo $_SESSION['errormsg'];
                    unset($_SESSION['errormsg']);
                  } 
                ?>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <div class=" flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                    <!-- START Category List-->
                    <?php
                      $sql = "SELECT cat_id, cat_name FROM category";

                      if($result = mysqli_query($dbConn, $sql)) {
                        if(mysqli_num_rows($result) > 0) {
                          // load data
                          echo "<ul class='nav nav-tabs mb-4'>";
                            while($row = mysqli_fetch_array($result)) {
                              // echo "<span><a class='btn btn-outline-github' href=''>".$row['cat_name']."</a></span>";
                              if($selectedCategory != "") {
                                if($selectedCategory == $row['cat_name']) {
                                    echo "<li class='nav-item'>
                                    <a class='nav-link active' href='pos_order.php?cat=".$row['cat_name']."'>". $row['cat_name']."</a>
                                  <li>";
                                } else {
                                    echo "<li class='nav-item'>
                                    <a class='nav-link' href='pos_order.php?cat=".$row['cat_name']."'>". $row['cat_name']."</a>
                                  <li>";
                                }
                              } else {
                                echo "<li class='nav-item'>
                                  <a class='nav-link' href='pos_order.php?cat=".$row['cat_name']."'>". $row['cat_name']."</a>
                                <li>";
                              }
                            }
                          echo "</ul>";
                        } else {
                          echo "<tr>";
                            echo "No categories found.";
                          echo "</tr>";
                        }
                      }
                    ?>
                    <!-- END Category List-->
                    <!-- START Product List-->
                    <div id="loadProducts">
                      <div class="row">
                        <div class="flex flex-wrap col-md-12 grid-margin stretch-card">
                          <?php
                            loadProducts($dbConn,$selectedCategory);
                          ?>
                          
                        </div>
                      </div>
                    </div>
                    <!-- END Product List-->
                  </div>  
                </div>
              </div> 
            </div>
          </div>
          
          <hr>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <!-- <p class="card-title text-md-center text-xl-left">Users</p> -->
                  <div class=" flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                      ORDER SUMMARY
                      <hr>
                      <div class="row">
                      
                        <div class="col-md-8">
                            <!-- <form method='GET' action='../../objects/pos.php'> -->
                                <table class="table table-borderless">
                                    <thead class="border-top border-bottom" style="font-size:10px">
                                        <tr>
                                            <th hidden>id</th>
                                            <th>Product</th>
                                            <th>Quantity</th>
                                            <th>Price</th>
                                            <th>Total</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                        loadOrders($dbConn);
                                    ?>
                                    </tbody>
                                </table>
                            <!-- </form> -->
                        </div>
                      <div class="col-md-4">
                      <form action="../../objects/pos.php" method="POST">
                        <div class="form-group mb-2">
                          <label id="DateTime" for="DateTime"></label>
                          <select class="form-control" name="customer_list">
                              <?php
                                loadCustomers($dbConn);
                              ?>
                          </select>
                        </div>
                        <?php
                          loadTotal($dbConn);
                        ?> 
                      </div>
                    </div>
                     
                  </div>  
                </div>
              </div>
            </div>
          </div>
        </div>
          <?php include '../modals.php'; ?>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
          <?php include '../footer.php'; ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

<?php include '../scripts.php'; 
     ob_end_flush();

?>
<script>
  setInterval(
    () => {
      var label = "DATE TODAY - ";
      var sys_date = new Date().toLocaleDateString();
      var sys_time = new Date().toLocaleTimeString();
      document.getElementById('DateTime').innerHTML = label.concat(sys_date," ", sys_time);     
    }, 1000);
</script>
</body>

</html>

