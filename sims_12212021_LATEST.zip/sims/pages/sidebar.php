      <!-- partial:../../partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar" style="background-color:#E6D5B8;">
          <ul class="nav" >
               <li class="nav-item">
                  <a class="nav-link" href="../dashboard/dashboard.php" >
                      <i class="ti-shield menu-icon"></i>
                      <span class="menu-title" >Dashboard</span>
                  </a>
              </li>
            <?php
                if ($_SESSION['access_level'] == 1) {
                    echo '<li class="nav-item">
                        <a class="nav-link" href="../customer/customer.php">
                            <i class="ti-user menu-icon"></i>
                            <span class="menu-title">Customers</span>
                        </a>
                    </li>';
                }
            ?>

            <?php
                if ($_SESSION['access_level'] == 1) { 
                    echo '<li class="nav-item">
                        <a class="nav-link" href="../employee/employee.php">
                            <i class="ti-user menu-icon"></i>
                            <span class="menu-title">Employees</span>
                        </a>
                    </li>';
                }
            ?>
             
              <li class="nav-item">
                  <a class="nav-link" href="../category/category.php">
                      <i class="ti-layers-alt menu-icon"></i>
                      <span class="menu-title">Categories</span>
                  </a>
              </li>
              <!-- <li class="nav-item">
                  <a class="nav-link" href="../company/company.php">
                      <i class="ti-flag menu-icon"></i>
                      <span class="menu-title">Company Setup</span>
                  </a>
              </li>
                        -->
              
              <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
                    <i class="ti-palette menu-icon"></i>
                    <span class="menu-title">Attributes</span>
                    <i class="menu-arrow"></i>
                </a>
                <div class="collapse" id="ui-basic">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> <a class="nav-link" href="../attributes/size.php">Size</a></li>
                    <li class="nav-item"> <a class="nav-link" href="../attributes/color.php">Color</a></li>
                    <li class="nav-item"> <a class="nav-link" href="../attributes/fabric.php">Fabric</a></li>
                </ul>
                </div>
              </li>
          
              <li class="nav-item">
                  <a class="nav-link" href="../product/product.php">
                      <i class="ti-shopping-cart menu-icon"></i>
                      <span class="menu-title">Products</span>
                  </a>
              </li>
              <!-- <li class="nav-item">
                  <a class="nav-link" href="../productset/productset.php">
                      <i class="ti-shopping-cart menu-icon"></i>
                      <span class="menu-title">Product Sets</span>
                  </a>
              </li> -->
              
              <li class="nav-item">
                  <a class="nav-link" href="../inventory/inventory.php">
                      <i class="ti-view-list menu-icon"></i>
                      <span class="menu-title">Inventory</span>
                  </a>
              </li>

              <li class="nav-item">
                  <a class="nav-link" href="../supplier/supplier.php">
                      <i class="ti-truck menu-icon"></i>
                      <span class="menu-title">Supplier</span>
                  </a>
              </li>
              
              <!-- <li class="nav-item">
                  <a class="nav-link" href="../invoice/invoice.php">
                      <i class="ti-shopping-cart-full menu-icon"></i>
                      <span class="menu-title">Invoice</span>
                  </a>
              </li> -->
            <?php
                if ($_SESSION['access_level'] == 1) { 
                    echo '<li class="nav-item">
                        <a class="nav-link" href="../sales/sales.php">
                            <i class="ti-bar-chart-alt menu-icon"></i>
                            <span class="menu-title">Sales</span>
                        </a>
                    </li>';
                }
            ?>
              <!-- <li class="nav-item">
                  <a class="nav-link" href="../sales/sales.php">
                      <i class="ti-bar-chart-alt menu-icon"></i>
                      <span class="menu-title">Sales</span>
                  </a>
              </li> -->
              <?php
                if ($_SESSION['access_level'] == 1) {
                    echo '<li class="nav-item">
                        <a class="nav-link" href="../users/users.php">
                            <i class="ti-user menu-icon"></i>
                            <span class="menu-title">Users</span>
                        </a>
                    </li>';
                }
              ?>
              
             <li class="nav-item">
                <a class="nav-link" data-toggle="collapse" href="#rpt" aria-expanded="false" aria-controls="rpt">
                    <i class="ti-palette menu-icon"></i>
                    <span class="menu-title">Reports</span>
                    <i class="menu-arrow"></i>
                </a>
                <div class="collapse" id="rpt">
                    <ul class="nav flex-column sub-menu">
                        <!-- <li class="nav-item"> <a class="nav-link" href="../reports/rpt_3.php" target="_blank">Total Sales</a></li> -->
                        <li class="nav-item"> 
                            <a class="nav-link">
                                <button id="rptDateRange" class="pl-0 border-0" type="button" data-toggle="modal" data-target="#rpt-DateRange">
                                    Total Sales
                                </button>
                            </a>                        
                        </li>
                        <li class="nav-item"> <a class="nav-link" href="../reports/rpt_2.php" target="_blank">Received Items</a></li>
                        <li class="nav-item"> <a class="nav-link" href="../reports/rpt_1.php" target="_blank">Inventory Summary</a></li>
                        <li class="nav-item"> <a class="nav-link" href="../reports/rpt_4.php" target="_blank">Critical Stock Level</a></li>
                    </ul>
                </div>
             </li>

             <li class="nav-item">
                  <a class="nav-link" href="../returns/returns.php">
                      <i class="ti-package menu-icon"></i>
                      <span class="menu-title">Returns</span>
                  </a>
              </li>

              <?php
                if ($_SESSION['access_level'] == 1) { 
                    echo '<li class="nav-item">
                            <a class="nav-link" href="../userlog/userlog.php">
                                <i class="ti-user menu-icon"></i>
                                <span class="menu-title">User Log</span>
                            </a>
                        </li>';
                }
            ?>

            <?php
                if ($_SESSION['access_level'] == 1) { 
                    echo '<li class="nav-item">
                    <a class="nav-link" href="../auditlog/auditlog.php">
                        <i class="ti-time menu-icon"></i>
                        <span class="menu-title">Audit Log</span>
                    </a>
                    </li>';
                }
            ?>
          </ul>
      </nav>
      <!-- partial -->