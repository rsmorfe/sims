
<!DOCTYPE html>
<html lang="en">

<?php 
  session_start();
  if (!isset($_SESSION['logged_user_id'])) {
    header('location: ../login/login.php');
    exit;
  } 
  
  include_once '../../database/connection.php'; 
  include '../../objects/inventory.php'; 
  include '../head.php'; 

  if(isset($_POST['addstock'])) {
    $action = htmlspecialchars('addstock');
    $prod_id = htmlspecialchars($_POST['prod_id']);
    $prod_qty = htmlspecialchars($_POST['prod_qty']);
    $createdby = htmlspecialchars($_SESSION['logged_user_id']);

    $sql = "INSERT INTO inventoryitems(prod_id, inv_action, inv_itemqty, createdby)
            VALUES(?, ?, ?, ?)";

    if($stmt = mysqli_prepare($dbConn, $sql)){
      // Bind variables to the prepared statement as parameters
      mysqli_stmt_bind_param($stmt, "isii", $prod_id, $action, $prod_qty, $createdby);

      // Attempt to execute the prepared statement
      if(mysqli_stmt_execute($stmt)){
        // PREPARES CONFIRMATION MESSAGE
        $error = "<span class='text-success'>Stock Added Successfully</span>";
        $_SESSION['errormsg'] = $error;

        // REDIRECT TO INVENTORY PAGE
        header('location: inventory.php');
        exit;
      } else {
         // echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
         // PREPARES ERROR MESSAGE
         $error = "<span class='text-danger'>Unable to process request</span>";
         $_SESSION['errormsg'] = $error;
      }
    }
  }

  if(isset($_POST['checkout'])) {
    $action = htmlspecialchars('checkout');
    $prod_id = htmlspecialchars($_POST['prod_id']);
    $prod_qty = htmlspecialchars($_POST['prod_qty']);
    $createdby = htmlspecialchars($_SESSION['logged_user_id']);

    $sql = "INSERT INTO inventoryitems(prod_id, inv_action, inv_itemqty, createdby)
            VALUES(?, ?, ?, ?)";

    if($stmt = mysqli_prepare($dbConn, $sql)){
      // Bind variables to the prepared statement as parameters
      mysqli_stmt_bind_param($stmt, "isii", $prod_id, $action, $prod_qty, $createdby);

      // Attempt to execute the prepared statement
      if(mysqli_stmt_execute($stmt)){
        // PREPARES CONFIRMATION MESSAGE
        $error = "<span class='text-success'>Checkout Successful</span>";
        $_SESSION['errormsg'] = $error;

        // REDIRECT TO INVENTORY PAGE
        header('location: inventory.php');
        exit;
      } else {
          // echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
          // PREPARES ERROR MESSAGE
          $error = "<span class='text-danger'>Unable to process request</span>";
          $_SESSION['errormsg'] = $error;
      }
    }
  }
?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php include '../navbar.php'; ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <?php include '../sidebar.php'; ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper" style="background-color:#E6D5B8;">
          <div class="row">
            <div class="col-md-12 grid-margin">
              <!-- FREE SPACE -->
              <?php
                  if (isset($_SESSION['errormsg'])) {
                    echo $_SESSION['errormsg'];
                    unset($_SESSION['errormsg']);
                  } 
              ?>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <p class="card-title text-md-center text-xl-left">Inventory Summary</p>
                  <div class=" flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                      <table id="example1" class="table table-hover" >
                          <thead style="font-size:10px">
                              <tr>
                                  <th>Product Name</th>
                                  <th>Color</th>
                                  <th>Size</th>
                                  <th>On-Hand</th>
                                  <th>Action</th>
                              </tr>
                          </thead>
                          <tbody>
                          <?php
                            $result = loadInventorySummary($dbConn);
                            if(mysqli_num_rows($result) > 0) {
                              // load data
                              while($row = mysqli_fetch_array($result)) {
                                echo "<tr>";
                                echo "<td>" . $row['prod_name'] . "</td>";
                                echo "<td>" . $row['color'] . "</td>";
                                echo "<td>" . $row['size'] . "</td>";
                                echo "<td>" . $row['OnHand'] . "</td>";                             
                                echo '<td>
                                  <a href="inventory-form.php?prod_id='.$row['id'].'&name='.$row['prod_name'].'&action=addstock">
                                    <button type="button" class="btn btn-primary btn-icon-text btn-rounded btn-sm" data-toggle="modal" data-target="#add-InvAddStock">
                                      <i class="ti-plus btn-icon-prepend"></i>Add Stock
                                    </button>
                                  </a>
                                  <a href="inventory-form.php?prod_id='.$row['id'].'&name='.$row['prod_name'].'&action=checkout">
                                    <button type="button" class="btn btn-success btn-icon-text btn-rounded btn-sm" data-toggle="modal" data-target="#add-InvCheckout">
                                      <i class="ti-plus btn-icon-prepend"></i>Checkout
                                    </button>
                                  </a>
                                </td>';
                                echo "</tr>";
                              }
                            } else {
                              echo "<tr>";
                              echo "No record/s found.";
                              echo "</tr>";
                            }

                          ?>
                          </tbody>
                      </table>
                  </div>  
                </div>
              </div>
            </div>
          </div>
        </div>
          <?php include '../modals.php'; ?>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
          <?php include '../footer.php'; ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

<?php include '../scripts.php'; ?>
</body>

</html>

