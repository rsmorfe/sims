
<!DOCTYPE html>
<html lang="en">

<?php 
  session_start();
  if (!isset($_SESSION['logged_user_id'])) {
    header('location: ../login/login.php');
    exit;
  } 

  include_once '../../database/connection.php'; 
  include '../head.php'; 

?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php include '../navbar.php'; ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <?php include '../sidebar.php'; ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper" style="background-color:#E6D5B8;">
          <div class="row">

          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                    <?php
                        $id = htmlspecialchars($_GET['prod_id']);
                        $action = htmlspecialchars($_GET['action']);
                        $product = htmlspecialchars($_GET['name']);

                        $title = "";
                        if($action == 'addstock') {
                            $title = "Inventory - Add Stock";
                        } else {
                            $title = "Inventory - Checkout";
                        }
                        
                    ?>
                  <p class="card-title text-md-center text-xl-left"><?php echo $title; ?></p>
                  <div class=" flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                  <form role="form" class="mt-4" method="POST" action="inventory.php"> 
                        <div class="form-group">
                            <input type="text" id="prod_id" name="prod_id" value="<?php echo $id; ?>" hidden>
                        </div>
                        <div class="form-group">
                        <label for="prod_name">Product Name</label>
                            <input type="text" class="form-control" id="prod_name" name="prod_name" value="<?php echo $product; ?>">
                        </div>
                        <div class="form-group">
                            <label for="prod_qty">Set Quantity</label>
                            <input type="text" class="form-control" id="prod_qty" name="prod_qty">
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded" name="<?php echo $action; ?>">Save</button>
                        <a href="inventory.php">
                            <button type="button" class="btn btn-default btn-rounded">Cancel</button> 
                        </a>
                    </form>
                  </div>  
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
          <?php include '../footer.php'; ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

<?php include '../scripts.php'; ?>
</body>

</html>

