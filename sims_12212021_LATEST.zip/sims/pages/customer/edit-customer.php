
<!DOCTYPE html>
<html lang="en">

<?php 
  session_start();
  if (!isset($_SESSION['logged_user_id'])) {
    header('location: ../login/login.php');
    exit;
  } 

  include_once '../../database/connection.php'; 
  include '../head.php'; 


  if (isset($_POST['edit'])) {
    $customer_id = htmlspecialchars($_POST['customer_id']);
    $fname = htmlspecialchars($_POST['customer_fname']);
    $lname = htmlspecialchars($_POST['customer_lname']);
    $address = htmlspecialchars($_POST['customer_address']);
    $contactno = htmlspecialchars($_POST['customer_contactno']);

    $sql = "UPDATE customer SET firstname = ?, lastname = ?, `address` = ?, contactno = ? WHERE customer_id = ?";

    if($stmt = mysqli_prepare($dbConn, $sql)){
      // Bind variables to the prepared statement as parameters
      mysqli_stmt_bind_param($stmt, "ssssi", $fname, $lname, $address, $contactno, $customer_id);

      // Attempt to execute the prepared statement
      if(mysqli_stmt_execute($stmt)){
        // PREPARES CONFIRMATION MESSAGE
        $error = "<span class='text-success'>Updated Successfully</span>";
        $_SESSION['errormsg'] = $error;

        header('location: customer.php');
        exit;
      } else {
          // echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
          $error = "<span class='text-danger'>Unable to process request</span>";
          $_SESSION['errormsg'] = $error;

          header('location: ../pages/customer/customer.php');
          exit;
      }
    }
    
  }
?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php include '../navbar.php'; ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <?php include '../sidebar.php'; ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper" style="background-color:#E6D5B8;">
          <div class="row">

          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <p class="card-title text-md-center text-xl-left">Edit Customer</p>
                  <div class=" flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                        <form role="form" class="mt-4" method="POST" action="edit-customer.php">  
                        <div class="row">
                            <?php
                                $sql = "SELECT * FROM customer WHERE customer_id = ".htmlspecialchars($_GET['id']);

                                if($result = mysqli_query($dbConn, $sql)) {
                                    if(mysqli_num_rows($result) > 0) {
                                      // load data
                                      while($row = mysqli_fetch_array($result)) {
                            ?>
                                        <div class="form-group col-md-12">
                                            <input type="text" class="form-control" id="customer_id" name="customer_id" value="<?php echo $row['customer_id'];?>" hidden>
                                            <label for="customer_fname">First Name</label>
                                            <input type="text" class="form-control" id="customer_fname" name="customer_fname" value="<?php echo $row['firstname'];?>" placeholder="First Name">
                                            <label for="customer_lname">Last Name</label>
                                            <input type="text" class="form-control" id="customer_lname" name="customer_lname" value="<?php echo $row['lastname'];?>" placeholder="Last Name">
                                            <label for="customer_address">Address</label>
                                            <input type="text" class="form-control" id="customer_address" name="customer_address" value="<?php echo $row['address'];?>" placeholder="Address">
                                            <label for="customer_contactno">Contact Number</label>
                                            <input type="text" class="form-control" id="customer_contactno" name="customer_contactno" value="<?php echo $row['contactno'];?>" placeholder="Contact Number">
                                        </div>

                            <?php
                                      }
                                    }
                                }
                            ?>
                        </div>
                            <button type="submit" class="btn btn-primary btn-rounded" name="edit">Save</button>
                            <a href="customer.php">
                                <button type="button" class="btn btn-default btn-rounded">Cancel</button>
                            </a>
                            
                        </form>
                  </div>  
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
          <?php include '../footer.php'; ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

<?php include '../scripts.php'; ?>
</body>

</html>

