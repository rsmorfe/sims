<?php
session_start();
if (!isset($_SESSION['logged_user_id'])) {
  header('location: ../login/login.php');
  exit;
} 

include_once '../../database/connection.php'; 
ob_start();
require('../../fpdf/fpdf.php');
/*
[During Instantiation of FPDF]
A4 width : 219mm
default margin : 10mm each side
writable horizontal line : 219 - (10*2) = 189mm

[Using the Cell() function]
Cell(width, height, text, border, end line, [align])
border = (0:no border,1:bordered)
end line = (0:continue,1:new line),
align = (L:left align(default),C:Center,R;Right)

*/

$pdf = new FPDF('p','mm','A4'); // instantiate FPDF

//define new alias for total page numbers
$pdf->AliasNbPages('{pages}');

$pdf->AddPage(); // create page


$pdf->SetFont('Arial','B',14); // Header - School Name


//$pdf->Image('../assets/img/logo2.jpg',10,10,30); // School Logo
$pdf->Ln();
$pdf->Cell(32);
$pdf->Cell(32);$pdf->Cell(32,5,'           ');
$pdf->Ln(); 
$pdf->Cell(32);
$pdf->Cell(130,5,'DJ Clothing',0,0,'C');
$pdf->Ln();

$pdf->SetFont('Arial','',11); // Header - School Address
$pdf->Cell(32);
$pdf->Cell(130,5,'#080 Zone 2 Sitio Pagkakaisa Sucat Muntinlupa City',0,0,'C');
$pdf->Ln();

$pdf->SetFont('Arial','',11); // Header - Contact No
$pdf->Cell(32);
$pdf->Cell(130,5,'Contact No: 0915-216-6780',0,0,'C');
$pdf->Ln();

// Add New Line
$pdf->Ln();
$pdf->Ln();
$pdf->Ln();

// Title
$pdf->SetFont('Arial','B',12); // Header - Contact No
$pdf->Cell(189,5,'Received Items',0,0,'C'); // max width
$pdf->Ln();
$pdf->Ln();

// Content
// Content-header
$pdf->SetFont('Arial','B',10);
$pdf->Cell(25,5,'ID',1,0,'C'); 
$pdf->Cell(25,5,'Date',1,0,'C'); 
$pdf->Cell(100,5,'Product Name',1,0,'C'); 
$pdf->Cell(30,5,'Quantity',1,0,'C'); 
// Content-data
$pdf->SetFont('Arial','',9);
$pdf->Ln();
// Query
$sql = "SELECT a.id, a.prod_name, b.inv_itemqty, DATE(b.datacreated) as datecreated
        FROM products a INNER JOIN inventoryitems b ON b.prod_id = a.id
        WHERE b.inv_action ='addstock'";



if($result = mysqli_query($dbConn, $sql)) {
    if(mysqli_num_rows($result) > 0) {
      // load data
      while($row = mysqli_fetch_array($result)) {
        $pdf->Cell(25,7,$row['id'],1,0,'C');
        $pdf->Cell(25,7,$row['datecreated'],1,0,'C'); 
        $pdf->Cell(100,7,$row['prod_name'],1,0,'C'); 
        $pdf->Cell(30,7,$row['inv_itemqty'],1,0,'C');
        $pdf->Ln();

      }
    } 
  }

$pdf->Ln();


$pdf->Output(); // generate pdf on browser
ob_end_flush(); 
?>