<?php
session_start();
if (!isset($_SESSION['logged_user_id'])) {
  header('location: ../login/login.php');
  exit;
} 

include_once '../../database/connection.php'; 
ob_start();
require('../../fpdf/fpdf.php');

// FETCH SELECTED DATE
$from = ''; 
$to = '';
if(isset($_GET['range'])){
  $range = trim($_GET['range']);
  $ex = explode(' - ', $range);
  $from = date('Y-m-d', strtotime(str_replace('-', '/', $ex[0])));
  $to = date('Y-m-d', strtotime(str_replace('-', '/', $ex[1])));
}

/*
[During Instantiation of FPDF]
A4 width : 219mm
default margin : 10mm each side
writable horizontal line : 219 - (10*2) = 189mm

[Using the Cell() function]
Cell(width, height, text, border, end line, [align])
border = (0:no border,1:bordered)
end line = (0:continue,1:new line),
align = (L:left align(default),C:Center,R;Right)

*/

$pdf = new FPDF('p','mm','A4'); // instantiate FPDF

//define new alias for total page numbers
$pdf->AliasNbPages('{pages}');

$pdf->AddPage(); // create page


$pdf->SetFont('Arial','B',14); // Header - School Name


//$pdf->Image('../assets/img/logo2.jpg',10,10,30); // School Logo
$pdf->Ln();
$pdf->Cell(32);
$pdf->Cell(32);$pdf->Cell(32,5,'           ');
$pdf->Ln(); 
$pdf->Cell(32);
$pdf->Cell(130,5,'DJ Clothing',0,0,'C');
$pdf->Ln();

$pdf->SetFont('Arial','',11); // Header - School Address
$pdf->Cell(32);
$pdf->Cell(130,5,'#080 Zone 2 Sitio Pagkakaisa Sucat Muntinlupa City',0,0,'C');
$pdf->Ln();

$pdf->SetFont('Arial','',11); // Header - Contact No
$pdf->Cell(32);
$pdf->Cell(130,5,'Contact No: 0915-216-6780',0,0,'C');
$pdf->Ln();

// Add New Line
$pdf->Ln();
$pdf->Ln();
$pdf->Ln();

// Title
$pdf->SetFont('Arial','B',12); // Header - Contact No
$pdf->Cell(189,5,'Total Sales',0,0,'C'); // max width
$pdf->Ln();
$pdf->Ln();
$pdf->Cell(35,5,'Sales Period :',0,0,'L'); 

$pdf->SetFont('Arial','',12);
$pdf->Cell(0,5,$from . " to " .$to,0,0,'L'); 
$pdf->Ln();
$pdf->Ln();

// Content
// Content-header
$pdf->SetFont('Arial','B',10);
$pdf->Cell(50,5,'Transaction No',1,0,'C'); 
$pdf->Cell(50,5,'Date',1,0,'C'); 
$pdf->Cell(25,5,'Items Sold',1,0,'C'); 
$pdf->Cell(65,5,'Total Price',1,0,'C'); 
// Content-data
$pdf->SetFont('Arial','',9);
$pdf->Ln();

// Query
// $sql = "SELECT transactionNo, DATE(transactionDate) as transactionDate, itemsSold,
//  totalPrice from transactionhistory order by transactionDate DESC";

$sql = "SELECT transactionNo, DATE(transactionDate) as transactionDate, itemsSold, totalPrice 
from transactionhistory where DATE(transactionDate) between '" .$from. "' AND '" .$to. "' 
order by transactionDate DESC";

$totaltransactions = 0;
$totalitems = 0;
$subtotal = 0;

if($result = mysqli_query($dbConn, $sql)) {
    if(mysqli_num_rows($result) > 0) {
      // load data
      while($row = mysqli_fetch_array($result)) {
        $pdf->Cell(50,7,$row['transactionNo'],1,0,'C'); 
        $pdf->Cell(50,7,$row['transactionDate'],1,0,'C');
        $pdf->Cell(25,7,$row['itemsSold'],1,0,'C');
        $pdf->Cell(65,7,$row['totalPrice'],1,0,'C');
        $pdf->Ln();

        $totaltransactions += 1;
        $totalitems += $row['itemsSold'];
        $subtotal += $row['totalPrice'];
      }
    } else {
      $totaltransactions = 0;
      $totalitems = 0;
      $subtotal = 0 ;
    }
  }

$pdf->Ln();
$pdf->Ln();
$pdf->SetFont('Arial','',11); 
$pdf->Cell(50,5,'',0,0,'L');
$pdf->Cell(50,5,'',0,0,'L');
$pdf->Cell(50,7,'Transactions:',0,0,'R');
$pdf->Cell(0,7,$totaltransactions,0,0,'R');
$pdf->Ln();
$pdf->Cell(50,5,'',0,0,'L');
$pdf->Cell(50,5,'',0,0,'L');
$pdf->Cell(50,7,'Items Sold:',0,0,'R');
$pdf->Cell(0,7,$totalitems,0,0,'R');
$pdf->Ln();
$pdf->Cell(50,5,'',0,0,'L');
$pdf->Cell(50,5,'',0,0,'L');
$pdf->Cell(50,7,'Subtotal:',0,0,'R');
$pdf->Cell(0,7,number_format($subtotal,2),0,0,'R');
$pdf->Ln();

$pdf->Output(); // generate pdf on browser
ob_end_flush(); 
?>