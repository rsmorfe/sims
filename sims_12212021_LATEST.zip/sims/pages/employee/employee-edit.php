
<!DOCTYPE html>
<html lang="en">

<?php 
  session_start();
  if (!isset($_SESSION['logged_user_id'])) {
    header('location: ../login/login.php');
    exit;
  } 

  include_once '../../database/connection.php'; 
  include_once '../../objects/employee.php';
  include '../head.php'; 


  if (isset($_POST['edit'])) {
    // SANITIZE
    $customer_id = htmlspecialchars($_POST['emp_id']);
    $fname = htmlspecialchars($_POST['emp_fname']);
    $lname = htmlspecialchars($_POST['emp_lname']);
    $gender = htmlspecialchars($_POST['emp_gender']);
    $contactno = htmlspecialchars($_POST['emp_contactno']);

    updateEmployee($dbConn, $customer_id, $fname, $lname, $gender, $contactno);
    
  }
?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php include '../navbar.php'; ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <?php include '../sidebar.php'; ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper" style="background-color:#E6D5B8;">
          <div class="row">

          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <p class="card-title text-md-center text-xl-left">Edit Employee</p>
                  <div class=" flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                        <form role="form" class="mt-4" method="POST" action="employee-edit.php">  
                        <div class="row">
                            <?php
                                $sql = "SELECT * FROM employee WHERE emp_id = ".htmlspecialchars($_GET['id']);

                                if($result = mysqli_query($dbConn, $sql)) {
                                    if(mysqli_num_rows($result) > 0) {
                                      // load data
                                      while($row = mysqli_fetch_array($result)) {
                            ?>
                                        <div class="form-group col-md-12">
                                            <input type="text" class="form-control" id="emp_id" name="emp_id" value="<?php echo $row['emp_id'];?>" hidden>
                                            <label for="emp_fname">First Name</label>
                                            <input type="text" class="form-control" id="emp_fname" name="emp_fname" value="<?php echo $row['firstname'];?>" placeholder="First Name">
                                            <label for="emp_lname">Last Name</label>
                                            <input type="text" class="form-control" id="emp_lname" name="emp_lname" value="<?php echo $row['lastname'];?>" placeholder="Last Name">
                                            <label for="emp_gender">Gender</label>
                                            <select class="form-control" name="emp_gender">
                            <?php
                                        if($row['gender'] == "M") {
                                            echo '<option selected value="'.$row['gender'].'">'.$row['gender'].'</option>';
                                            echo '<option value="F">F</option>';
                                        } else {
                                            echo '<option selected value="'.$row['gender'].'">'.$row['gender'].'</option>';
                                            echo '<option value="M">M</option>';
                                        }
                            ?>
                                            </select>
                                            <label for="emp_contactno">Contact Number</label>
                                            <input type="text" class="form-control" id="emp_contactno" name="emp_contactno" value="<?php echo $row['contactno'];?>" placeholder="Contact Number">
                                        </div>

                            <?php
                                      }
                                    }
                                }
                            ?>
                        </div>
                            <button type="submit" class="btn btn-primary btn-rounded" name="edit">Save</button>
                            <a href="employee.php">
                                <button type="button" class="btn btn-default btn-rounded">Cancel</button>
                            </a>
                            
                        </form>
                  </div>  
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
          <?php include '../footer.php'; ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

<?php include '../scripts.php'; ?>
</body>

</html>

