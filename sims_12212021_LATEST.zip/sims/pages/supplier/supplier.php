
<!DOCTYPE html>
<html lang="en">

<?php 
  session_start();
  if (!isset($_SESSION['logged_user_id'])) {
    header('location: ../login/login.php');
    exit;
  }
  include_once '../../database/connection.php'; 
  include '../head.php'; 

  if(isset($_GET['del'])) {
    // DELETE SUPPLIER RECORD
    $sql = "DELETE FROM supplier WHERE supplier_id = ?";

    if($stmt = mysqli_prepare($dbConn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "i", $id);
        
        // Set parameters
        $id = htmlentities($_GET['del']);
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
          deleteSupplierItems($dbConn, $id); // DELETE SUPPLIER ITEMS
        } else {
            echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
            // PREPARES ERROR MESSAGE
            $error = "<span class='text-danger'>Unable to process request</span>";
            $_SESSION['errormsg'] = $error;
        }
    } else {
        echo "ERROR: Could not prepare query: $sql. " . mysqli_error($dbConn);
        // PREPARES ERROR MESSAGE
        $error = "<span class='text-danger'>Unable to process request</span>";
        $_SESSION['errormsg'] = $error;
    }        
  }

  function deleteSupplierItems($conn, $supplier_id) {
    // DELETE SUPPLIER ITEMS
    $sql = "DELETE FROM supplier_items WHERE supplier_id = ?";

    if($stmt = mysqli_prepare($conn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "i", $id);
        
        // Set parameters
        $id = htmlentities($_GET['del']);
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            // PREPARES CONFIRMATION MESSAGE
            $error = "<span class='text-success'>Deleted Successfully</span>";
            $_SESSION['errormsg'] = $error;

            header('location: supplier.php');
            exit;
        } else {
            // echo "ERROR: Could not execute query: $sql. " . mysqli_error($conn);
            // PREPARES ERROR MESSAGE
            $error = "<span class='text-danger'>Unable to process request</span>";
            $_SESSION['errormsg'] = $error;

            header('location: supplier.php');
            exit;
        }
    } else {
        echo "ERROR: Could not prepare query: $sql. " . mysqli_error($conn);

    }        
  }
?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php include '../navbar.php'; ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <?php include '../sidebar.php'; ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper" style="background-color:#E6D5B8;">
          <div class="row">
            <div class="col-md-12 grid-margin">
              <div class="d-flex justify-content-between align-items-center">
                <div>
                  <button type="button" class="btn btn-primary btn-icon-text btn-rounded btn-sm" data-toggle="modal" data-target="#add-Supplier">
                      <i class="ti-plus btn-icon-prepend"></i>Add Supplier
                  </button> 
                </div>
                <div>
                  <?php
                    if (isset($_SESSION['errormsg'])) {
                      echo $_SESSION['errormsg'];
                      unset($_SESSION['errormsg']);
                    } 
                  ?>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <p class="card-title text-md-center text-xl-left">Supplier</p>
                  <div class="flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                      <table id="example1" class="table table-hover" >
                      <thead style="font-size:10px">
                              <tr>
                                  <th>Company Name</th>
                                  <th>Address</th>
                                  <th>Contact Number</th>
                                  <th></th>
                              </tr>
                          </thead>
                          <tbody>
                              <tr>
                                  <?php
                                      include '../../objects/supplier.php';
                                      loadSuppliers($dbConn);
                                  ?>
                              </tr>
                         </tbody>
                      </table>
                  </div>  
                </div>
              </div>
            </div>
          </div>
        </div>
          <?php include '../modals.php'; ?>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
          <?php include '../footer.php'; ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

<?php include '../scripts.php'; ?>
</body>

</html>

