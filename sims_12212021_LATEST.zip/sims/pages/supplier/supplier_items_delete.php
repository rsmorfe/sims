<?php
    include_once '../../database/connection.php'; 


    if(isset($_GET['id'])) {
        $id = htmlspecialchars($_GET['id']);
        $supplier_id = htmlspecialchars($_GET['sid']);

        $sql = "DELETE FROM supplier_items WHERE supplier_id = {$supplier_id} AND prod_id = {$id}";
    
        if($stmt = mysqli_prepare($dbConn, $sql)){
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                exit(header('location: supplier_items.php?id='.$supplier_id));
            } else {
                echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
            }
        }
    }
 
?>