
<!DOCTYPE html>
<html lang="en">

<?php 
  session_start();
  if (!isset($_SESSION['logged_user_id'])) {
    header('location: ../login/login.php');
    exit;
  }
  include_once '../../database/connection.php'; 
  include '../head.php';


  if(isset($_POST['create_supplieritem'])) {
    addSupplierItem($dbConn, $_POST['supplier_id'], $_POST['prod_id']);
  }

  function addSupplierItem($conn, $supplier_id, $prod_id) {
      // Sanitize and Set parameters
      $supplier_id = htmlspecialchars($supplier_id);
      $prod_id = htmlspecialchars($prod_id);


      $sql = "INSERT INTO supplier_items(supplier_id, prod_id)
              VALUES(?, ?)";

      if($stmt = mysqli_prepare($conn, $sql)){
          // Bind variables to the prepared statement as parameters
          mysqli_stmt_bind_param($stmt, "ii", $supplier_id, $prod_id);
      
          // Attempt to execute the prepared statement
          if(mysqli_stmt_execute($stmt)){
              header('location: supplier_items.php?id='.$supplier_id);
              exit;
          } else {
              echo "ERROR: Could not execute query: $sql. " . mysqli_error($conn);
          }
      }
  }



  function loadSupplier($conn, $supplier_id) {
    $supplier_id = htmlspecialchars($supplier_id);

    $sql = "SELECT company_name FROM supplier WHERE supplier_id = {$supplier_id}";

    if($result = mysqli_query($conn, $sql)) {
        if(mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_array($result);

            return $row['company_name'];
        } else {
            echo "<tr> No record/s found.</tr>";
        }
    }
  }

  function loadSupplierItems($conn, $supplier_id) {
    $supplier_id = htmlspecialchars($supplier_id);

    $sql = "SELECT a.supplier_id, b.id, b.prod_name,
            (SELECT color from color WHERE color_id = b.prod_color) as color,
            (SELECT fabric from fabric WHERE fabric_id = b.prod_fabric) as fabric,
            (SELECT size from size WHERE size_id = b.prod_size) as size 
            FROM supplier_items a INNER JOIN products b ON b.id = a.prod_id
            WHERE a.supplier_id = {$supplier_id}";

    if($result = mysqli_query($conn, $sql)) {
        if(mysqli_num_rows($result) > 0) {
            // load data
            while($row = mysqli_fetch_array($result)) {
                echo "<tr>";
                    echo "<td>" . $row['prod_name'] . "</td>";
                    echo "<td>" . $row['color'] . "</td>";
                    echo "<td>" . $row['fabric'] . "</td>";    
                    echo "<td>" . $row['size'] . "</td>";                    
                    echo "<td>
                        <a href='supplier_items_delete.php?sid=".$supplier_id."&id=".$row['id']."' data-toggle='tooltip' title='Delete'>
                            <button type='button' class='btn btn-danger btn-sm btn-rounded'><i class='ti-trash btn-icon-prepend'></i></button>
                        </a>
                    </td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td>No record/s found.</td></tr>";
        }
    }
  }

?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php include '../navbar.php'; ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <?php include '../sidebar.php'; ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper" style="background-color:#E6D5B8;">
          <div class="row">
            <div class="col-md-12 grid-margin">
              <div class="d-flex justify-content-between align-items-center">
                  <div>
                      <button type="button" class="btn btn-primary btn-icon-text btn-rounded btn-sm" data-toggle="modal" data-target="#add-SupplierItem">
                          <i class="ti-plus btn-icon-prepend"></i>Add Item
                      </button> 
                  </div>
                <div>
                    
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <p class="card-title text-md-center text-xl-left">Supplier Items</p>
                  <p class="card-description ml-4">SUPPLIER : <span class="ml-4"><?php echo " ". loadSupplier($dbConn, $_GET['id']);?></span></p>
                  <div class=" flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                      <table id="example1" class="table table-hover" >
                          <thead style="font-size:10px">
                              <tr>
                                  <th>Product</th>
                                  <th>Color</th>
                                  <th>Fabric</th>
                                  <th>Size</th>
                                  <th></th>
                              </tr>
                          </thead>
                          <tbody>
                              <tr>
                                  <?php
                                      loadSupplierItems($dbConn, $_GET['id']);
                                  ?>
                              </tr>
                          </tbody>
                      </table>
                  </div>  
                  <div class="col-md-12 text-md-right mt-4">
                    <a href="supplier.php">
                        <button type="button" class="btn btn-success btn-sm btn-rounded">Return</i></button>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
          <?php include '../modals.php'; ?>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
          <?php include '../footer.php'; ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

<?php include '../scripts.php'; ?>
</body>

</html>

