
<!DOCTYPE html>
<html lang="en">

<?php 
  session_start();
  if (!isset($_SESSION['logged_user_id'])) {
    header('location: ../login/login.php');
    exit;
  } 

  include_once '../../database/connection.php'; 
  include '../head.php'; 


  if (isset($_POST['edit'])) {
    $supplier_id = htmlspecialchars($_POST['supplier_id']);
    $supplier = htmlspecialchars($_POST['supplier_name']);
    $address = htmlspecialchars($_POST['supplier_address']);
    $contactno = htmlspecialchars($_POST['supplier_contactno']);

    $sql = "UPDATE supplier SET company_name = ?, `address` = ?, contactno = ? WHERE supplier_id = ?";

    if($stmt = mysqli_prepare($dbConn, $sql)){
      // Bind variables to the prepared statement as parameters
      mysqli_stmt_bind_param($stmt, "sssi", $supplier, $address, $contactno, $supplier_id);

      // Attempt to execute the prepared statement
      if(mysqli_stmt_execute($stmt)){
          header('location: supplier.php');
          exit;
      } else {
          echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
      }
    }
    
  }
?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php include '../navbar.php'; ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <?php include '../sidebar.php'; ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper" style="background-color:#E6D5B8;">
          <div class="row">

          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <p class="card-title text-md-center text-xl-left">Edit Supplier Info</p>
                  <div class=" flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                        <form role="form" class="mt-4" method="POST" action="supplier-edit.php">  
                        <div class="row">
                            <?php
                                $sql = "SELECT * FROM supplier WHERE supplier_id = ".htmlspecialchars($_GET['id']);

                                if($result = mysqli_query($dbConn, $sql)) {
                                    if(mysqli_num_rows($result) > 0) {
                                      // load data
                                      while($row = mysqli_fetch_array($result)) {
                            ?>
                                        <div class="form-group col-md-12">
                                            <input type="text" class="form-control" id="supplier_id" name="supplier_id" value="<?php echo $row['supplier_id'];?>" hidden>
                                            <label for="supplier_name">Company Name</label>
                                            <input type="text" class="form-control" id="supplier_name" name="supplier_name" value="<?php echo $row['company_name'];?>" placeholder="Company Name">
                                            <label for="supplier_address">Address</label>
                                            <input type="text" class="form-control" id="supplier_address" name="supplier_address" value="<?php echo $row['address'];?>" placeholder="Address">
                                            <label for="supplier_contactno">Contact Number</label>
                                            <input type="text" class="form-control" id="supplier_contactno" name="supplier_contactno" value="<?php echo $row['contactno'];?>" placeholder="Contact Number">
                                        </div>

                            <?php
                                      }
                                    }
                                }
                            ?>
                        </div>
                            <button type="submit" class="btn btn-primary btn-rounded" name="edit">Save</button>
                            <a href="supplier.php">
                                <button type="button" class="btn btn-default btn-rounded">Cancel</button>
                            </a>
                            
                        </form>
                  </div>  
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
          <?php include '../footer.php'; ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

<?php include '../scripts.php'; ?>
</body>

</html>

