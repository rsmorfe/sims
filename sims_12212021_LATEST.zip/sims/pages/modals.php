<div class="modal fade" id="add-Product">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Product</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form" method="POST" action="product.php" enctype="multipart/form-data">
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-4">
                                <label for="Item Code">Item Code</label>
                                <input type="text" class="form-control" id="Item Code" name="itemcode" placeholder="Item Code">
                            </div>
                            <div class="form-group col-md-8">
                                <label for="Name">Name</label>
                                <input type="text" class="form-control" id="Name" name="prod_name" placeholder="Name">
                            </div>
                            <div class="form-group col-md-4">
                                <label for="Category">Category</label>
                                <select class="form-control" name="prod_category">
                                    <?php
                                    include_once '../../objects/loaditems.php'; 
                                        $result = loadItems($dbConn, "category");
                                        if(mysqli_num_rows($result) > 0) {
                                            // load data
                                            while($row = mysqli_fetch_array($result)) {
                                                echo '<option value="'.$row['cat_id'].'">'.$row['cat_name'].'</option>';
                                            }
                                        }
                                    ?>  
                                </select>
                            </div>
                            <div class="form-group col-md-4">
                                <label for="Size">Size</label>
                                <select class="form-control" name="prod_size"> 
                                <?php
                                        $result = loadItems($dbConn, "size");
                                        if(mysqli_num_rows($result) > 0) {
                                            // load data
                                            while($row = mysqli_fetch_array($result)) {
                                                echo '<option value="'.$row['size_id'].'">'.$row['size'].'</option>';
                                            }
                                        }
                                ?>  
                                </select>
                            </div>
                            <div class="form-group col-md-4">
                                <label for="Color">Color</label>
                                <select class="form-control" name="prod_color">
                                <?php
                                        $result = loadItems($dbConn, "color");
                                        if(mysqli_num_rows($result) > 0) {
                                            // load data
                                            while($row = mysqli_fetch_array($result)) {
                                                echo '<option value="'.$row['color_id'].'">'.$row['color'].'</option>';
                                            }
                                        }
                                ?>     
                                </select>
                            </div>
                            <div class="form-group col-md-4">
                                <label for="Fabric">Fabric</label>
                                <select class="form-control" name="prod_fabric">
                                <?php
                                        $result = loadItems($dbConn, "fabric");
                                        if(mysqli_num_rows($result) > 0) {
                                            // load data
                                            while($row = mysqli_fetch_array($result)) {
                                                echo '<option value="'.$row['fabric_id'].'">'.$row['fabric'].'</option>';
                                            }
                                        }
                                ?>     
                                </select>
                            </div>
                            <div class="form-group col-md-4">
                                <label for="Product Price">Product Price</label>
                                <input class="form-control" type="text" name="prod_price" id="currency-field" pattern="^\P\d{1,3}(,\d{3})*(\.\d+)?P" value="" data-type="currency" placeholder="P 0.00">
                            </div>
                            <div class="form-group col-md-4">
                                <label for="Selling Price">Selling Price</label>
                                <input class="form-control" type="text" name="prod_sellingprice" id="currency-field" pattern="^\P\d{1,3}(,\d{3})*(\.\d+)?P" value="" data-type="currency" placeholder="P 0.00">
                            </div>
                            <div class="form-group col-md-4">
                            <label for="image">Image</label>
                                <input class="form-control" type="file" name="image"> 
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded" name="create_product">Save</button>
                        <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                </form>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-Product -->
<div class="modal fade" id="edit-Product">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Edit Product</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-4">
                            <label for="Item Code">Item Code</label>
                            <input type="text" class="form-control" id="Item Code" placeholder="Item Code">
                        </div>
                        <div class="form-group col-md-8">
                            <label for="Name">Name</label>
                            <input type="text" class="form-control" id="Name" placeholder="Name">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="Variant">Variant</label>
                            <input type="text" class="form-control" id="Variant" placeholder="Variant">
                        </div>
                            <div class="form-group col-md-4">
                            <label for="Unit Value">Unit Value</label>
                            <input type="text" class="form-control" id="Unit Value" placeholder="Unit Value">
                        </div>
                            <div class="form-group col-md-4">
                            <label for="Unit Name">Unit Name</label>
                            <select class="form-control">
                                <option>Category 1</option>    
                                <option>Category 2</option>    
                            </select>
                        </div>
                            <div class="form-group col-md-4">
                            <label for="Category">Category</label>
                            <select class="form-control">
                                <option>Category 1</option>    
                                <option>Category 2</option>    
                            </select>
                        </div>
                            <div class="form-group col-md-4">
                            <label for="Net Price">Net Price</label>
                            <input class="form-control"type="text" name="currency-field" id="currency-field" pattern="^\P\d{1,3}(,\d{3})*(\.\d+)?P" value="" data-type="currency" placeholder="P 0.00">
                        </div>
                            <div class="form-group col-md-4">
                            <label for="Production Cost">Production Cost</label>
                            <input class="form-control"type="text" name="currency-field" id="currency-field" pattern="^\P\d{1,3}(,\d{3})*(\.\d+)?P" value="" data-type="currency" placeholder="P 0.00">
                        </div>
                            <div class="form-group col-md-4">
                            <label for="Markup %">Markup %</label>
                            <input type="text" class="form-control" id="Markup %" placeholder="%">
                        </div>
                            <div class="form-group col-md-4">
                            <label for="Markup Price">Markup Price</label>
                            <input class="form-control"type="text" name="currency-field" id="currency-field" pattern="^\P\d{1,3}(,\d{3})*(\.\d+)?P" value="" data-type="currency" placeholder="P 0.00">
                        </div>
                            <div class="form-group col-md-4">
                            <label for="Discount">Discount</label>
                            <input type="number" class="form-control" id="Discount" placeholder="%">
                        </div>
                            <div class="form-group col-md-4">
                            <label for="Discount Price">Discount Price</label>
                            <input class="form-control"type="text" name="currency-field" id="currency-field" pattern="^\P\d{1,3}(,\d{3})*(\.\d+)?P" value="" data-type="currency" placeholder="P 0.00">
                        </div>
                            <div class="form-group col-md-4">
                            <label for="Sales Price">Sales Price</label>
                            <input class="form-control"type="text" name="currency-field" id="currency-field" pattern="^\P\d{1,3}(,\d{3})*(\.\d+)?P" value="" data-type="currency" placeholder="P 0.00">
                        </div>
                            <div class="form-group col-md-4">
                            <label for="Reorder Level">Reorder Level</label>
                            <input type="text" class="form-control" id="Reorder Level" placeholder="Reorder Level">
                        </div>
                            <div class="form-group col-md-4">
                            <label for="Stock Quantity">Stock Quantity</label>
                            <input type="text" class="form-control" id="Stock Quantity" placeholder="Stock Quantity">
                        </div>
                            <div class="form-group col-md-4">
                            <label for="Expiry Date">Expiry Date</label>
                            <input type="text" class="form-control" id="Expiry Date" placeholder="Expiry Date">
                        </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded">Save</button>
                        <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
            </div>
        </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal edit-Product -->
<div class="modal fade" id="add-Unit">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Unit</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-12">
                            <label for="Name">Name</label>
                            <input type="text" class="form-control" id="Name" placeholder="Name">
                        </div>
                        <div class="form-group col-md-12">
                            <label for="Description">Description</label>
                            <textarea type="text" class="form-control" id="Description" placeholder="Description"></textarea>
                        </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded">Save</button>
                        <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
            </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-Unit -->
<div class="modal fade" id="edit-Unit">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Edit Unit</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-12">
                            <label for="Name">Name</label>
                            <input type="text" class="form-control" id="Name" placeholder="Name">
                        </div>
                        <div class="form-group col-md-12">
                            <label for="Description">Description</label>
                            <textarea type="text" class="form-control" id="Description" placeholder="Description"></textarea>
                        </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded">Save</button>
                        <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
            </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal edit-Unit -->
<div class="modal fade" id="add-Category">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Category</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form" method="POST" action="category.php">
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="Name">Name</label>
                                <input type="text" class="form-control" id="Name" name="cat_name" placeholder="Name">
                            </div>
                            <div class="form-group col-md-12">
                            <select class="form-control" id="CategoryStatus" name="cat_status">
                                <option disabled value="">~~SELECT~~</option>
                                <option value="1">ACTIVE</option>
                                <option value="0">INACTIVE</option>
                            </select>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded" name="create_category">Save</button>
                        <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                </form>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-Category -->
<div class="modal fade" id="edit-Category">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Edit Category</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-12">
                            <label for="Name">Name</label>
                            <input type="text" class="form-control" id="cat_id" name="cat_id"  hidden>
                            <input type="text" class="form-control" id="cat_name" name="cat_name" placeholder="Name">
                        </div>
                        <div class="form-group col-md-12">
                        <select class="form-control" id="cat_status" name="cat_status">
                                <option disabled value="">~~SELECT~~</option>
                                <option value="1">ACTIVE</option>
                                <option value="0">INACTIVE</option>
                            </select>
                        </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded">Save</button>
                        <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal edit-Category -->
<div class="modal fade" id="add-InvAddStock">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Inventory - Add Stock</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form" method="POST" action="inventory.php">
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="Material Name">Material Name</label>
                                <input type="text" class="form-control" name="dataid" id="dataid" value="" hidden>
                                <input type="text" class="form-control" id="Material Name" placeholder="Material Name">
                            </div>
                                <div class="form-group col-md-12">
                                <label for="Amount">Amount</label>
                                <input class="form-control"type="text" name="currency-field" id="currency-field" pattern="^\P\d{1,3}(,\d{3})*(\.\d+)?P" value="" data-type="currency" placeholder="P 0.00">
                            </div>
                            </div>
                            <button type="submit" class="btn btn-primary btn-rounded" name="addstock">Save</button>
                            <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-InvAddStock -->
<div class="modal fade" id="add-InvCheckout">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Inventory - Checkout</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form" method="POST" action="inventory.php">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-12">
                            <label for="Product Name">Product Name</label>
                            <select class="form-control">
                                <option>Category 1</option>
                                <option>Category 2</option>
                            </select>
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Material Name">Material Name</label>
                            <input type="text" class="form-control" id="Material Name" placeholder="Material Name">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Amount">Amount</label>
                            <input class="form-control"type="text" name="currency-field" id="currency-field" pattern="^\P\d{1,3}(,\d{3})*(\.\d+)?P" value="" data-type="currency" placeholder="P 0.00">
                        </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded">Save</button>
                        <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-InvCheckout -->
<div class="modal fade" id="add-Invoice">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Invoice</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-12">
                            <label for="Total Amount">Total Amount</label>
                            <input class="form-control"type="text" name="currency-field" id="currency-field" pattern="^\P\d{1,3}(,\d{3})*(\.\d+)?P" value="" data-type="currency" placeholder="P 0.00">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Discount Price">Discount Price</label>
                            <input class="form-control"type="text" name="currency-field" id="currency-field" pattern="^\P\d{1,3}(,\d{3})*(\.\d+)?P" value="" data-type="currency" placeholder="P 0.00">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Tendered">Tendered</label>
                            <input class="form-control"type="text" name="currency-field" id="currency-field" pattern="^\P\d{1,3}(,\d{3})*(\.\d+)?P" value="" data-type="currency" placeholder="P 0.00">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Change">Change</label>
                            <input class="form-control"type="text" name="currency-field" id="currency-field" pattern="^\P\d{1,3}(,\d{3})*(\.\d+)?P" value="" data-type="currency" placeholder="P 0.00">
                        </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded">Save</button>
                        <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-Invoice -->
<div class="modal fade" id="edit-Invoice">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Edit Invoice</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-12">
                            <label for="Total Amount">Total Amount</label>
                            <input class="form-control"type="text" name="currency-field" id="currency-field" pattern="^\P\d{1,3}(,\d{3})*(\.\d+)?P" value="" data-type="currency" placeholder="P 0.00">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Discount Price">Discount Price</label>
                            <input class="form-control"type="text" name="currency-field" id="currency-field" pattern="^\P\d{1,3}(,\d{3})*(\.\d+)?P" value="" data-type="currency" placeholder="P 0.00">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Tendered">Tendered</label>
                            <input class="form-control"type="text" name="currency-field" id="currency-field" pattern="^\P\d{1,3}(,\d{3})*(\.\d+)?P" value="" data-type="currency" placeholder="P 0.00">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Change">Change</label>
                            <input class="form-control"type="text" name="currency-field" id="currency-field" pattern="^\P\d{1,3}(,\d{3})*(\.\d+)?P" value="" data-type="currency" placeholder="P 0.00">
                        </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded">Save</button>
                        <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal edit-Invoice -->
<div class="modal fade" id="add-Color">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Color</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form" method="POST" action="color.php">
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="Color">Color</label>
                                <input type="text" class="form-control" id="Color" name="color" placeholder="Color">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded" name="create_color">Save</button>
                        <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
            </div>
        </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-Color -->
<div class="modal fade" id="add-Size">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Size</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form" method="POST" action="size.php">
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="Size">Size</label>
                                <input type="text" class="form-control" id="Size" name="size" placeholder="Size">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded" name="create_size">Save</button>
                        <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
            </div>
        </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-Size -->
<div class="modal fade" id="add-Fabric">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Fabric</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form" method="POST" action="fabric.php">
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="Fabric">Fabric</label>
                                <input type="text" class="form-control" id="Fabric" name="fabric" placeholder="Fabric">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded" name="create_fabric">Save</button>
                        <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
            </div>
        </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-Fabric -->
<div class="modal fade" id="add-Sales">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Sales</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-12">
                            <label for="Item">Item</label>
                            <select class="form-control">
                                <option>Category 1</option>
                                <option>Category 2</option>
                            </select>
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Sale Quantity">Sale Quantity</label>
                            <input type="number" class="form-control" id="Sale Quantity" placeholder="Sale Quantity">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Total">Total</label>
                            <input class="form-control"type="text" name="currency-field" id="currency-field" pattern="^\P\d{1,3}(,\d{3})*(\.\d+)?P" value="" data-type="currency" placeholder="P 0.00">
                        </div>                      
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded">Save</button>
                        <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-Sales -->
<div class="modal fade" id="edit-Sales">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Edit Sales</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-12">
                            <label for="Item">Item</label>
                            <select class="form-control">
                                <option>Category 1</option>
                                <option>Category 2</option>
                            </select>
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Sale Quantity">Sale Quantity</label>
                            <input type="number" class="form-control" id="Sale Quantity" placeholder="Sale Quantity">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Total">Total</label>
                            <input class="form-control"type="text" name="currency-field" id="currency-field" pattern="^\P\d{1,3}(,\d{3})*(\.\d+)?P" value="" data-type="currency" placeholder="P 0.00">
                        </div>                      
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded">Save</button>
                        <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal edit-Sales -->
<div class="modal fade" id="add-Users">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Users</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form" action="../../objects/accounts.php" method="POST">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-12">
                            <label for="First Name">First Name</label>
                            <input type="text" class="form-control" id="First Name" name="user_fname" placeholder="First Name">
                        </div>
                        <div class="form-group col-md-12">
                            <label for="Last Name">Last Name</label>
                            <input type="text" class="form-control" id="Last Name" name="user_lname" placeholder="Username">
                        </div>
                        <div class="form-group col-md-12">
                            <label for="Position">Position</label>
                            <select class="form-control" name="user_position">
                                <option value="Administrator">Administrator</option> 
                                <option value="Manager">Manager</option>    
                                <option value="Supervisor">Supervisor</option>    
                                <option value="Staff">Staff</option>     
                            </select>
                        </div>
                        <div class="form-group col-md-12">
                            <label for="User Level">User Level</label>
                            <select class="form-control" name="user_level">
                                <option value="1">1</option>    
                                <option value="2">2</option>    
                                <option value="3">3</option>     
                            </select>
                        </div>
                        <div class="form-group col-md-12">
                            <label for="User Name">User Name</label>
                            <input type="text" class="form-control" id="User Name" name="user_acctname" placeholder="User Name">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Contact Number">Contact Number</label>
                            <input type="text" class="form-control" id="Contact Number" name="user_contactno" placeholder="Contact Number">
                        </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded" name="user_create">Save</button>
                        <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-Users -->
<div class="modal fade" id="edit-Users">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Edit Users</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form" method="POST" action="../../objects/accounts.php">
                    <div class="card-body">
                    <div class="row">
                        <input type="text" id="User ID" name="user_id" value="1" hidden>
                        <div class="form-group col-md-12">
                            <label for="First Name">First Name</label>
                            <input type="text" class="form-control" id="First Name" name="user_fname" placeholder="First Name">
                        </div>
                        <div class="form-group col-md-12">
                            <label for="Last Name">Last Name</label>
                            <input type="text" class="form-control" id="Last Name" name="user_lname" placeholder="Username">
                        </div>
                        <div class="form-group col-md-12">
                            <label for="Position">Position</label>
                            <select class="form-control" name="user_position">
                                <option value="Manager">Manager</option>    
                                <option value="Supervisor">Supervisor</option>    
                                <option value="Staff">Staff</option>     
                            </select>
                        </div>
                        <div class="form-group col-md-12">
                            <label for="User Level">User Level</label>
                            <select class="form-control" name="user_level">
                                <option value="1">1</option>    
                                <option value="2">2</option>    
                                <option value="3">3</option>     
                            </select>
                        </div>
                        <div class="form-group col-md-12">
                            <label for="User Name">User Name</label>
                            <input type="text" class="form-control" id="User Name" name="user_acctname" placeholder="User Name">
                        </div>
                        <div class="form-group col-md-12">
                            <label for="Contact Number">Contact Number</label>
                            <input type="text" class="form-control" id="Contact Number" name="user_contactno" placeholder="Contact Number">
                        </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded" name="user_create">Save</button>
                        <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal edit-Users -->
<div class="modal fade" id="add-ProductSet">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Product Set</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-12">
                            <label for="Set Code">Set Code</label>
                            <input type="text" class="form-control" id="Set Code" placeholder="Set Code">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Set Name">Set Name</label>
                            <input type="text" class="form-control" id="Set Name" placeholder="Set Name">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Total Amount">Total Amount</label>
                            <input class="form-control"type="text" name="currency-field" id="currency-field" pattern="^\P\d{1,3}(,\d{3})*(\.\d+)?P" value="" data-type="currency" placeholder="P 0.00">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Set on Hand">Set on Hand</label>
                            <input type="text" class="form-control" id="Set on Hand" placeholder="Set on Hand">
                        </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded">Save</button>
                        <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-ProductSet -->
<div class="modal fade" id="edit-ProductSet">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Edit Product Set</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-12">
                            <label for="Set Code">Set Code</label>
                            <input type="text" class="form-control" id="Set Code" placeholder="Set Code">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Set Name">Set Name</label>
                            <input type="text" class="form-control" id="Set Name" placeholder="Set Name">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Total Amount">Total Amount</label>
                            <input class="form-control"type="text" name="currency-field" id="currency-field" pattern="^\P\d{1,3}(,\d{3})*(\.\d+)?P" value="" data-type="currency" placeholder="P 0.00">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Set on Hand">Set on Hand</label>
                            <input type="text" class="form-control" id="Set on Hand" placeholder="Set on Hand">
                        </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded">Save</button>
                        <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal edit-ProductSet -->
<div class="modal fade" id="add-CompanySetup">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Company Setup</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-12">
                            <label for="Company Name">Company Name</label>
                            <input type="text" class="form-control" id="Company Name" placeholder="Company Name">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Address">Address</label>
                            <input type="text" class="form-control" id="Address" placeholder="Address">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Contact No.">Contact No.</label>
                            <input type="text" class="form-control" id="Contact No." placeholder="Contact No.">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="TIN No.">TIN No.</label>
                            <input type="text" class="form-control" id="TIN No." placeholder="TIN No.">
                        </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded">Save</button>
                        <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-CompanySetup -->
<div class="modal fade" id="edit-CompanySetup">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Edit Company Setup</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-12">
                            <label for="Company Name">Company Name</label>
                            <input type="text" class="form-control" id="Company Name" placeholder="Company Name">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Address">Address</label>
                            <input type="text" class="form-control" id="Address" placeholder="Address">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Contact No.">Contact No.</label>
                            <input type="text" class="form-control" id="Contact No." placeholder="Contact No.">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="TIN No.">TIN No.</label>
                            <input type="text" class="form-control" id="TIN No." placeholder="TIN No.">
                        </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded">Save</button>
                        <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal edit-CompanySetup -->
<div class="modal fade" id="set-days">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Set Predictive Days</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-12">
                            <label for="Days">Days</label>
                            <input type="number" class="form-control" id="Days" placeholder="Days">
                        </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded">Save</button>
                        <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal set-days -->
<div class="modal fade" id="add-Customer">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Customer</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="modal_AddCustomer" role="form" action="../../objects/customers.php" method="POST">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-12">
                            <label for="First Name">First Name</label>
                            <input type="text" class="form-control" id="First Name" name="customer_fname" placeholder="First Name">
                        </div>
                        <div class="form-group col-md-12">
                            <label for="Last Name">Last Name</label>
                            <input type="text" class="form-control" id="Last Name" name="customer_lname" placeholder="Last Name">
                        </div>
                        <div class="form-group col-md-12">
                            <label for="Address">Address</label>
                            <input type="text" class="form-control" id="Address" name="customer_address" placeholder="Address">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Contact Number">Contact Number</label>
                            <input type="text" class="form-control" id="Contact Number" name="customer_contactno" placeholder="Contact Number" maxlength="11">
                        </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded" name="customer_create">Save</button>
                        <button id="close_AddCustomer" type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-Customer -->
<div class="modal fade" id="add-Supplier">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Supplier</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form" action="../../objects/supplier.php" method="POST">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-12">
                            <label for="Company Name">Company Name</label>
                            <input type="text" class="form-control" id="Company Name" name="supplier_name" placeholder="Company Name">
                        </div>
                        <div class="form-group col-md-12">
                            <label for="Address">Address</label>
                            <input type="text" class="form-control" id="Address" name="supplier_address" placeholder="Address">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Contact Number">Contact Number</label>
                            <input type="text" class="form-control" id="Contact Number" name="supplier_contactno" placeholder="Contact Number">
                        </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded" name="supplier_create">Save</button>
                        <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-Supplier -->
<div class="modal fade" id="add-Employee">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Employee</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form" action="../../objects/employee.php" method="POST">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-12">
                            <label for="First Name">First Name</label>
                            <input type="text" class="form-control" id="First Name" name="emp_fname" placeholder="First Name">
                        </div>
                        <div class="form-group col-md-12">
                            <label for="Last Name">Last Name</label>
                            <input type="text" class="form-control" id="Last Name" name="emp_lname" placeholder="Last Name">
                        </div>
                        <div class="form-group col-md-12">
                            <label for="Gender">Gender</label>
                            <select class="form-control" name="emp_gender">
                                <option value="M">Male</option>    
                                <option value="F">Female</option>    
                            </select>
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Contact Number">Contact Number</label>
                            <input type="text" class="form-control" id="Contact Number" name="emp_contactno" placeholder="Contact Number">
                        </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded" name="emp_create">Save</button>
                        <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-Employee -->
<div class="modal fade" id="add-SupplierItem">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Supplier Item</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form" method="POST" action="supplier_items.php" enctype="multipart/form-data">
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="Product">Product</label>
                                <input type="text" name="supplier_id" value="<?php echo htmlspecialchars($_GET['id']); ?>" hidden>
                                <select class="form-control" name="prod_id">
                                    <?php
                                        include_once "../../objects/supplier_loadproducts.php";
                                        load_Products($dbConn);
                                    ?>  
                                </select>
                            </div>
                            
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded" name="create_supplieritem">Save</button>
                        <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                </form>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-SupplierItem -->
<div class="modal fade" id="add-Returns">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Returned Item</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form" method="POST" action="returns_query.php" enctype="multipart/form-data">
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="transactionNo">Transaction No:</label>
                                <select class="form-control" name="transactionNo">
                                    <?php
                                        include_once "../returns/returns_query.php";
                                        returns_loadTransactions($dbConn);
                                    ?>  
                                </select>
                            </div>
                            <div class="form-group col-md-8">
                                <label for="Product">Product</label>
                                <select class="form-control" name="prod_id">
                                    <?php
                                        include_once "../returns/returns_query.php";
                                        returns_loadProducts($dbConn);
                                    ?>  
                                </select>
                            </div>  
                            <div class="form-group col-md-4">
                                <label for="quantity">Quantity</label>
                                <input type="text" class="form-control" id="quantity" name="quantity" placeholder="Quantity">
                            </div>  
                            <div class="form-group col-md-12">
                            <label for="Remarks">Remarks</label>
                                <input type="text" class="form-control" id="remarks" name="remarks" placeholder="Remarks">
                            </div>  
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded" name="returns_create">Save</button>
                        <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                </form>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-Returns -->
<div class="modal fade" id="rpt-DateRange">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Set Date Range</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                
                <div class="card-body">
                    <div class="row">
                        <div class="form-group col-md-12">
                            <label for="dateRange">Range :</label>
                            <input type="text" class="form-control" id="dateRange" name="dateRange" placeholder="Date Range">
                        </div>
                        <div class="form-group col-md-12">
                            <button type="button" class="pull-right btn btn-primary btn-rounded" id="generate_rpt">Generate</button>
                        </div>
                        
                    </div>
                </div>
                <!-- /.card-body -->

            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal rpt-DateRange -->