
<!DOCTYPE html>
<html lang="en">

<?php 
  session_start();
  if (!isset($_SESSION['logged_user_id'])) {
    header('location: ../login/login.php');
    exit;
  } 

  include_once '../../database/connection.php'; 
  include_once '../../objects/loaditems.php'; 
  include '../head.php'; 


  if (isset($_POST['update_product'])) {
    $itemCode = htmlspecialchars($_POST['itemcode']);
    $productName = htmlspecialchars($_POST['prod_name']);
    $productCategory = htmlspecialchars($_POST['prod_category']);
    $productSize = htmlspecialchars($_POST['prod_size']);
    $productColor = htmlspecialchars($_POST['prod_color']);
    $productFabric = htmlspecialchars($_POST['prod_fabric']);
    $productPrice = htmlspecialchars($_POST['prod_price']);
    $productPrice = str_replace('P','',$_POST['prod_price']);
    $productSellingPrice = htmlspecialchars($_POST['prod_sellingprice']);
    $productSellingPrice = str_replace('P','',$_POST['prod_sellingprice']);
    // $productImage = htmlspecialchars($_POST['prod_image']);
    $prod_id = htmlspecialchars($_POST['prod_id']);

    $sql = "UPDATE products SET itemcode = ?, prod_name = ?, prod_cat = ?, 
            prod_size = ?, prod_color = ?, prod_fabric = ?, prod_price = ?, 
            prod_sellingprice = ? WHERE id = ?";

    if($stmt = mysqli_prepare($dbConn, $sql)){
      // Bind variables to the prepared statement as parameters
      mysqli_stmt_bind_param($stmt, "ssiiiissi", $itemCode, $productName, $productCategory, 
                              $productSize, $productColor, $productFabric,
                              $productPrice, $productSellingPrice, $prod_id);

      // Attempt to execute the prepared statement
      if(mysqli_stmt_execute($stmt)){
        // SET AUDIT LOGS
        $sql = "INSERT INTO auditlogs(user_id, user_action, actiondescription)
        VALUES(?, ?, ?)";

          if($stmt = mysqli_prepare($dbConn, $sql)){
              // Set parameters
              $log_userid = $_SESSION['logged_user_id'];
              $log_action = "UPDATE PRODUCT";
              $log_desc = "updated item " .$productName;

              // Bind variables to the prepared statement as parameters
              mysqli_stmt_bind_param($stmt, "iss", $log_userid, $log_action, $log_desc);
              
              // Attempt to execute the prepared statement
              if(mysqli_stmt_execute($stmt)){
                // PREPARES CONFIRMATION MESSAGE
                $error = "<span class='text-success'>Created Successfully</span>";
                $_SESSION['errormsg'] = $error;

                // REDIRECT TO PRODUCT PAGE
                header('location: product.php');
                exit;
              } else {
                  echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
              }
          } else{
              echo "ERROR: Could not prepare query: $sql. " . mysqli_error($dbConn);
          }
      } else {
          // echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
           // PREPARES ERROR MESSAGE
           $error = "<span class='text-danger'>Unable to process request</span>";
           $_SESSION['errormsg'] = $error;
 
           header('location: product.php');
           exit;
      }
    }
  }
?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php include '../navbar.php'; ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <?php include '../sidebar.php'; ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper" style="background-color:#E6D5B8;">
          <div class="row">

          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <p class="card-title text-md-center text-xl-left">Edit Product Information</p>
                  <div class=" flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                        <form role="form" class="mt-4" method="POST" action="product-edit.php">  
                            <div class="row">
                                <?php
                                    $data = loadProductInfo($dbConn, htmlspecialchars($_GET['id']));
                                    $prodInfo = mysqli_fetch_array($data);

                                ?>
                                <div class="form-group col-md-4">
                                    <label for="Item Code">Item Code</label>
                                    <input type="text" name="prod_id" value="<?php echo htmlspecialchars($_GET['id']);?>" hidden>
                                    <input type="text" class="form-control" id="Item Code" name="itemcode" value="<?php echo $prodInfo['itemcode'];?>" placeholder="Item Code">
                                </div>
                                <div class="form-group col-md-8">
                                    <label for="Name">Name</label>
                                    <input type="text" class="form-control" id="Name" name="prod_name" value="<?php echo $prodInfo['prod_name'];?>" placeholder="Name">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="Category">Category</label>
                                    <select class="form-control" name="prod_category">
                                        <?php
                                            $result = loadItems($dbConn, "category");
                                            if(mysqli_num_rows($result) > 0) {
                                                // load data
                                                while($row = mysqli_fetch_array($result)) {
                                                    if ($prodInfo['prod_cat'] == $row['cat_id']) {
                                                        echo '<option selected value="'.$row['cat_id'].'">'.$row['cat_name'].'</option>';
                                                    } else {
                                                        echo '<option value="'.$row['cat_id'].'">'.$row['cat_name'].'</option>';
                                                    } 
                                                }
                                            }
                                        ?>  
                                    </select>
                                </div>
                                    <div class="form-group col-md-4">
                                    <label for="Size">Size</label>
                                    <select class="form-control" name="prod_size"> 
                                    <?php
                                            $result = loadItems($dbConn, "size");
                                            if(mysqli_num_rows($result) > 0) {
                                                // load data
                                                while($row = mysqli_fetch_array($result)) {
                                                    if ($prodInfo['prod_size'] == $row['size_id']) {
                                                        echo '<option selected value="'.$row['size_id'].'">'.$row['size'].'</option>';
                                                    } else {
                                                        echo '<option value="'.$row['size_id'].'">'.$row['size'].'</option>';
                                                    }
                                                    
                                                }
                                            }
                                    ?>  
                                    </select>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="Color">Color</label>
                                    <select class="form-control" name="prod_color">
                                    <?php
                                            $result = loadItems($dbConn, "color");
                                            if(mysqli_num_rows($result) > 0) {
                                                // load data
                                                while($row = mysqli_fetch_array($result)) {
                                                    if ($prodInfo['prod_color'] == $row['color_id']) {
                                                        echo '<option selected value="'.$row['color_id'].'">'.$row['color'].'</option>';
                                                    } else {
                                                        echo '<option value="'.$row['color_id'].'">'.$row['color'].'</option>';
                                                    }
                                                    
                                                }
                                            }
                                    ?>     
                                    </select>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="Fabric">Fabric</label>
                                    <select class="form-control" name="prod_fabric">
                                    <?php
                                            $result = loadItems($dbConn, "fabric");
                                            if(mysqli_num_rows($result) > 0) {
                                                // load data
                                                while($row = mysqli_fetch_array($result)) {
                                                    if ($prodInfo['prod_color'] == $row['color_id']) {
                                                        echo '<option selected value="'.$row['fabric_id'].'">'.$row['fabric'].'</option>';
                                                    } else {
                                                        echo '<option value="'.$row['fabric_id'].'">'.$row['fabric'].'</option>';
                                                    }
                                                    
                                                }
                                            }
                                    ?>     
                                    </select>
                                </div>
                                    <div class="form-group col-md-4">
                                    <label for="Product Price">Product Price</label>
                                    <input class="form-control" type="text" name="prod_price" id="currency-field" pattern="^\P\d{1,3}(,\d{3})*(\.\d+)?P" value="<?php echo $prodInfo['prod_price'];?>" data-type="currency" placeholder="P 0.00">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="Selling Price">Selling Price</label>
                                    <input class="form-control" type="text" name="prod_sellingprice" id="currency-field" pattern="^\P\d{1,3}(,\d{3})*(\.\d+)?P" value="<?php echo $prodInfo['prod_sellingprice'];?>" data-type="currency" placeholder="P 0.00">
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary btn-rounded" name="update_product">Save</button>
                            <a href="product.php">
                                <button type="button" class="btn btn-default btn-rounded" data-dismiss="modal">Cancel</button>      
                            </a>
                            
                        </form>
                  </div>  
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
          <?php include '../footer.php'; ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

<?php include '../scripts.php'; ?>
</body>

</html>

