
<!DOCTYPE html>
<html lang="en">

<?php 
  session_start();
  if (!isset($_SESSION['logged_user_id'])) {
    header('location: ../login/login.php');
    exit;
  } 

  include_once '../../database/connection.php'; 
  include '../../objects/loaditems.php'; 
  include '../head.php'; 

  if (isset($_POST['create_product'])) {
    $itemCode = htmlspecialchars($_POST['itemcode']);
    $productName = htmlspecialchars($_POST['prod_name']);
    $productCategory = htmlspecialchars($_POST['prod_category']);
    $productSize = htmlspecialchars($_POST['prod_size']);
    $productColor = htmlspecialchars($_POST['prod_color']);
    $productFabric = htmlspecialchars($_POST['prod_fabric']);
    $productPrice = htmlspecialchars($_POST['prod_price']);
    $productPrice = trim(str_replace('P','',$_POST['prod_price']));
    $productSellingPrice = htmlspecialchars($_POST['prod_sellingprice']);
    $productSellingPrice = trim(str_replace('P','',$_POST['prod_sellingprice']));
    $productImage = htmlspecialchars(basename($_FILES["image"]["name"]));
    $createdby = htmlspecialchars($_SESSION['logged_user_id']);

    $sql = "INSERT INTO products(itemcode, prod_name, prod_cat, prod_size, prod_color, 
            prod_fabric, prod_price, prod_sellingprice, prod_image, createdby)
            VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    if($stmt = mysqli_prepare($dbConn, $sql)){
      // Bind variables to the prepared statement as parameters
      mysqli_stmt_bind_param($stmt, "ssiiiisssi", $itemCode, $productName, $productCategory, 
                              $productSize, $productColor, $productFabric,
                              $productPrice, $productSellingPrice, $productImage ,$createdby);

      // Attempt to execute the prepared statement
      if(mysqli_stmt_execute($stmt)){
        uploadImage($productImage); // upload image of product

        // SET AUDIT LOGS
        $sql = "INSERT INTO auditlogs(user_id, user_action, actiondescription)
        VALUES(?, ?, ?)";

          if($stmt = mysqli_prepare($dbConn, $sql)){
              // Set parameters
              $log_userid = $_SESSION['logged_user_id'];
              $log_action = "CREATE PRODUCT";
              $log_desc = "Added new item " .$productName;

              // Bind variables to the prepared statement as parameters
              mysqli_stmt_bind_param($stmt, "iss", $log_userid, $log_action, $log_desc);
              
              // Attempt to execute the prepared statement
              if(mysqli_stmt_execute($stmt)){
                 // PREPARES CONFIRMATION MESSAGE
                 $error = "<span class='text-success'>Created Successfully</span>";
                 $_SESSION['errormsg'] = $error;

                // REDIRECT TO PRODUCT PAGE
                header('location: product.php');
                exit;
              } else {
                  echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
              }
          } else{
              echo "ERROR: Could not prepare query: $sql. " . mysqli_error($dbConn);
          }
 
      } else {
          // echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
          // PREPARES ERROR MESSAGE
          $error = "<span class='text-danger'>Unable to process request</span>";
          $_SESSION['errormsg'] = $error;

          header('location: product.php');
          exit;
      }
    }
  }
?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php include '../navbar.php'; ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <?php include '../sidebar.php'; ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper" style="background-color:#E6D5B8;">
          <div class="row">
            <div class="col-md-12 grid-margin">
              <div class="d-flex justify-content-between align-items-center">
                <div>
                  <button type="button" class="btn btn-primary btn-icon-text btn-rounded btn-sm" data-toggle="modal" data-target="#add-Product">
                      <i class="ti-plus btn-icon-prepend"></i>Add Product
                  </button> 
                </div>
                <div>
                  <?php
                    if (isset($_SESSION['errormsg'])) {
                      echo $_SESSION['errormsg'];
                      unset($_SESSION['errormsg']);
                    } 
                  ?>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <p class="card-title text-md-center text-xl-left">Product</p>
                  <div class="flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                      <table id="example1" class="table table-hover" >
                          <thead style="font-size:10px">
                              <tr>
                                  <th>Item Code</th>
                                  <th>Category</th>
                                  <th>Product Name</th>
                                  <th>Size</th>
                                  <th>Color</th>
                                  <th>Fabric</th>
                                  <th>Price</th>
                                  <th>Selling Price</th>
                                  <th></th>
                              </tr>
                          </thead>
                          <tbody>
                            <?php
                              $result = loadItems($dbConn, "products");
                              if(mysqli_num_rows($result) > 0) {
                                // load data
                                while($row = mysqli_fetch_array($result)) {
                                  echo "<tr>";
                                  echo "<td>" . $row['itemcode'] . "</td>";
                                  echo "<td>" . $row['cat_name'] . "</td>";
                                  echo "<td>" . $row['prod_name'] . "</td>";
                                  echo "<td>" . $row['size'] . "</td>";
                                  echo "<td>" . $row['color'] . "</td>";
                                  echo "<td>" . $row['fabric'] . "</td>";
                                  echo "<td>" . $row['prod_price'] . "</td>";     
                                  echo "<td>" . $row['prod_sellingprice'] . "</td>";                               
                                  echo "<td>
                                      <a href='product-edit.php?id=".$row['id']."' data-toggle='tooltip' title='Edit'>
                                        <button type='button' class='btn btn-primary btn-sm btn-rounded' data-toggle='modal' data-target='#edit-Users'><i class='ti-pencil-alt btn-icon-prepend'></i></button>
                                      </a>
                                  </td>";
                                  echo "</tr>";
                                }
                              } else {
                                echo "<tr>";
                                echo "No record/s found.";
                                echo "</tr>";
                              }
                            ?>
                              <!-- <tr>
                                  <td>
                                    <a href="#" data-toggle="tooltip" title="Edit">
                                      <button type="button" class="btn btn-primary btn-sm btn-rounded" data-toggle="modal" data-target="#edit-Product"><i class="ti-pencil-alt btn-icon-prepend"></i></button>
                                    </a>
                                  </td>
                              </tr> -->
                          </tbody>
                      </table>
                  </div>  
                </div>
              </div>
            </div>
          </div>
        </div>
          <?php include '../modals.php'; ?>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
          <?php include '../footer.php'; ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

<?php include '../scripts.php'; ?>
</body>

</html>

