<?php


function getTotalSales($conn, $request_type) {
    $totalSale = 0;
    $sql = '';

    if($request_type == 'DAILY') {
        $sql = "SELECT SUM(totalPrice) as totalSales FROM transactionhistory 
        WHERE Date(transactionDate) = CURDATE()";
    } elseif($request_type == 'MONTHLY') {
        $sql = "SELECT SUM(totalPrice) as totalSales FROM transactionhistory 
        WHERE MONTH(Date(transactionDate)) = MONTH(CURDATE())";
    } elseif($request_type == 'YEARLY') {
        $sql = "SELECT SUM(totalPrice) as totalSales FROM transactionhistory 
        WHERE YEAR(Date(transactionDate)) = YEAR(CURDATE())";
    }

    if($result = mysqli_query($conn, $sql)) {
        if(mysqli_num_rows($result) > 0) {
            // load data
            $row = mysqli_fetch_array($result);
            $totalSale = number_format($row['totalSales'],2);
            return $totalSale;
        }
    }
}

function getOrders($conn) {
    $totalOrders = 0;

    $sql = "SELECT COUNT(order_id) as totalOrders FROM orderHistory 
        WHERE order_status = 'FOR PAYMENT'";

    if($result = mysqli_query($conn, $sql)) {
        if(mysqli_num_rows($result) > 0) {
            // load data
            $row = mysqli_fetch_array($result);
            $totalOrders = $row['totalOrders'];
            return $totalOrders;
        }
    }
}

function getCriticalStocks($conn) {
    $sql = "SELECT a.itemcode, a.prod_name,
    ((COALESCE(
            (SELECT SUM(inv_itemqty) FROM inventoryitems d WHERE d.prod_id = a.id AND
            d.inv_action = 'addstock' GROUP BY a.id),0) - 
        COALESCE(
            (SELECT SUM(inv_itemqty) FROM inventoryitems d WHERE d.prod_id = a.id AND
                d.inv_action = 'checkout' GROUP BY a.id),0)) - 
        (COALESCE(
            (SELECT SUM(quantity) FROM transactiondetails d WHERE d.prod_id = a.id 
                GROUP BY a.id),0) + 
        COALESCE(
            (SELECT SUM(quantity) FROM for_purchase e WHERE e.prod_id = a.id 
            GROUP BY a.id),0) + 
        COALESCE(
            (SELECT SUM(quantity) FROM orderDetails f WHERE f.prod_id = a.id AND
            (SELECT order_status FROM orderhistory WHERE order_id = f.order_id) = 'FOR PAYMENT' 
            GROUP BY a.id),0)
            )) AS OnHand 
        FROM products a WHERE 
        ((COALESCE(
            (SELECT SUM(inv_itemqty) FROM inventoryitems d WHERE d.prod_id = a.id AND
            d.inv_action = 'addstock' GROUP BY a.id),0) - 
        COALESCE(
            (SELECT SUM(inv_itemqty) FROM inventoryitems d WHERE d.prod_id = a.id AND
                d.inv_action = 'checkout' GROUP BY a.id),0)) - 
        (COALESCE(
            (SELECT SUM(quantity) FROM transactiondetails d WHERE d.prod_id = a.id 
                GROUP BY a.id),0) + 
        COALESCE(
            (SELECT SUM(quantity) FROM for_purchase e WHERE e.prod_id = a.id 
            GROUP BY a.id),0) + 
        COALESCE(
            (SELECT SUM(quantity) FROM orderDetails f WHERE f.prod_id = a.id AND
            (SELECT order_status FROM orderhistory WHERE order_id = f.order_id) = 'FOR PAYMENT' 
            GROUP BY a.id),0)
            )) < 50 ORDER BY OnHand DESC";

    if($result = mysqli_query($conn, $sql)) {
        if(mysqli_num_rows($result) > 0) {
            // load data
            while($row = mysqli_fetch_array($result)) {
                echo "<tr>
                    <td>{$row['itemcode']}</td>
                    <td>{$row['prod_name']}</td>
                    <td>{$row['OnHand']}</td>
                </tr>";
            }
        } 
    }
}
?>