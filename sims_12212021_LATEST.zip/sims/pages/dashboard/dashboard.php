
<!DOCTYPE html>
<html lang="en">

<?php 
  session_start();
  if (!isset($_SESSION['logged_user_id'])) {
    header('location: ../login/login.php');
    exit;
  }

  include_once '../../database/connection.php'; 
  include_once 'dashboard_getdata.php'; 
  include_once 'dashboard_chartdata.php'; 
  include_once '../head.php'; 


?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php include '../navbar.php'; ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <?php include '../sidebar.php'; ?>
      <!-- partial -->
      <div class="main-panel" >
        <div class="content-wrapper" style="background-color:#E6D5B8;">
          <div class="row">
            <div class="col-md-12 grid-margin">
            </div>
          </div>
          <div class="row">
              <div class="col-md-4 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <p class="card-title text-md-center text-xl-left pb-3">Sales Today</p>
                  <div class="d-flex flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                    <h3 class="mb-0 mb-md-2 mb-xl-0 order-md-1 order-xl-0 pl-2">P <?php echo getTotalSales($dbConn,"DAILY"); ?></h3>
                    <i class="ti-calendar icon-md text-muted mb-0 mb-md-3 mb-xl-0"></i>
                  </div>  
                  <!-- <p class="mb-0 mt-2 text-danger"><span class="text-black ml-1"><small><?php echo date("M d, Y"); ?></small></span></p> -->
                </div>
              </div>
            </div>
              <div class="col-md-4 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <p class="card-title text-md-center text-xl-left pb-3">Sales This Month</p>
                  <div class="d-flex flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                    <h3 class="mb-0 mb-md-2 mb-xl-0 order-md-1 order-xl-0 pl-2">P <?php echo getTotalSales($dbConn,"MONTHLY"); ?></h3>
                    <i class="ti-calendar icon-md text-muted mb-0 mb-md-3 mb-xl-0"></i>
                  </div>  
                  <!-- <p class="mb-0 mt-2 text-danger"><span class="text-black ml-1"><small>Last Month</small></span></p> -->
                </div>
              </div>
            </div>
              <div class="col-md-4 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <p class="card-title text-md-center text-xl-left pb-3">Sales This Year</p>
                  <div class="d-flex flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                    <h3 class="mb-0 mb-md-2 mb-xl-0 order-md-1 order-xl-0 pl-2">P <?php echo getTotalSales($dbConn,"YEARLY"); ?></h3>
                    <i class="ti-calendar icon-md text-muted mb-0 mb-md-3 mb-xl-0"></i>
                  </div>  
                  <!-- <p class="mb-0 mt-2 text-danger"><span class="text-black ml-1"><small>This Year</small></span></p> -->
                </div>
              </div>
            </div>
            <div class="col-md-6 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Items Sold</h4>
                    <canvas id="SoldItemsChart"></canvas>
                  </div>
                </div>
            </div>
            <div class="col-md-6 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Most Purchased Products</h4>
                    <canvas id="MostPurchasedChart"></canvas>
                  </div>
                </div>
            </div>
              <div class="col-md-3 grid-margin">
              <div class="card">
                <div class="card-body text-center">
                  <p class="card-title text-md-center text-xl-left">ONGOING Orders</p>
                  <div class="d-flex flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                    <h3 class="mb-0 mb-md-2 mb-xl-0 order-md-1 order-xl-0 pl-2"><?php echo getOrders($dbConn); ?></h3>
                    <!-- <i class="ti-agenda icon-md text-muted mb-0 mb-md-3 mb-xl-0"></i> -->
                  </div>  
                  <br>
                  <a href="../pos/pos_payment.php">
                  <button type="button" class="btn btn-primary btn-icon-text btn-flat btn-sm" data-toggle='tooltip' title='View Orders'>
                          Show Orders
                      </button>
                  </a>      
                </div>
              </div>
            </div>
              <div class="col-md-9 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <p class="card-title text-md-center text-xl-left">Low Stock Items</p>
                  <div class=" flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                      <table id="example1" class="table table-hover" >
                          <thead style="font-size:10px">
                              <tr>
                                  <th>Product Code</th>
                                  <th>Product Name</th>
                                  <th>Inventory Count</th>
                              </tr>
                          </thead>
                          <tbody>
                              <?php
                                getCriticalStocks($dbConn);
                              ?>
                          </tbody>
                      </table>
                  </div>  
                </div>
              </div>
            </div>
              <!-- <div class="col-md-8 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <p class="card-title text-md-center text-xl-left">Expiring Items</p>
                  <div class=" flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                      <table class="table table-hover" >
                          <thead style="font-size:10px">
                              <tr>
                                  <th>Product Code</th>
                                  <th>Product Name</th>
                                  <th>Inventory Count</th>
                              </tr>
                          </thead>
                          <tbody>
                              <tr>      
                                  <td>Data</td>
                                  <td>Data</td>
                                  <td>Data</td>
                              </tr>
                          </tbody>
                      </table>
                  </div>  
                </div>
              </div>
            </div> -->
          </div>
        </div>
          <?php include '../modals.php'; ?>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
          <?php include '../footer.php'; ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

<?php include '../scripts.php'; ?>
<script>
$(function () {
 // // SAMPLE CHART DATA
      // var data = {
      //   labels: ["2013", "2014", "2014", "2015", "2016", "2017"],
      //   datasets: [{
      //     label: '# of Votes',
      //     data: [10, 19, 3, 5, 2, 3],
      //     backgroundColor: [
      //       'rgba(255, 99, 132, 0.2)',
      //       'rgba(54, 162, 235, 0.2)',
      //       'rgba(255, 206, 86, 0.2)',
      //       'rgba(75, 192, 192, 0.2)',
      //       'rgba(153, 102, 255, 0.2)',
      //       'rgba(255, 159, 64, 0.2)'
      //     ],
      //     borderColor: [
      //       'rgba(255,99,132,1)',
      //       'rgba(54, 162, 235, 1)',
      //       'rgba(255, 206, 86, 1)',
      //       'rgba(75, 192, 192, 1)',
      //       'rgba(153, 102, 255, 1)',
      //       'rgba(255, 159, 64, 1)'
      //     ],
      //     borderWidth: 1,
      //     fill: false
      //   }]
      // };

      // CHART - TOTAL ITEMS SOLD
      var ctx = document.getElementById("SoldItemsChart").getContext("2d");
      var result = "";
      
      var chart_labels = <?php echo json_encode($chart_labels1) ?>;
      var chart_data = <?php echo json_encode($chart_data1); ?>;
      var mychart = new Chart(ctx, {
          type: 'line',
          data: {
            labels: chart_labels,
            datasets: [{
              label: "No of items",
              data: chart_data,
              backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(150, 150, 100, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
              ],
              borderColor: [
                'rgba(255,99,132,1)',
                'rgba(255,99,132,1)',
                'rgba(54, 162, 235, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
              ],
              borderWidth: 1,
              fill: false
            }]
          },
          //data: data,
          options: {
            scales: {
              yAxes: [{
                ticks: {
                    beginAtZero: true
                }
              }]
            }
          }
        }
      );

       // CHART - MOST PURCHASED PRODUCTS
       var ctx = document.getElementById("MostPurchasedChart").getContext("2d");
      var result = "";
      
      var chart_labels = <?php echo json_encode($chart_labels2) ?>;
      var chart_data = <?php echo json_encode($chart_data2); ?>;
      var mychart = new Chart(ctx, {
          type: 'bar',
          data: {
            labels: chart_labels,
            datasets: [{
              label: "# of items",
              data: chart_data,
              backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(150, 150, 100, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
              ],
              borderColor: [
                'rgba(255,99,132,1)',
                'rgba(255,99,132,1)',
                'rgba(54, 162, 235, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
              ],
              borderWidth: 1,
              fill: false
            }]
          },
          //data: data,
          options: {
            scales: {
              yAxes: [{
                ticks: {
                    beginAtZero: true
                }
              }]
            }
          }
        }
      );
});
</script>
</body>

</html>

