<?php

    // CHART DATA - TOTAL ITEMS SOLD
    $query1 = "SELECT MONTHNAME(Date(transactionDate)) as transMonth, 
                CAST(SUM(itemsSold) as CHAR) AS totalitems  
                FROM transactionhistory 
                WHERE YEAR(Date(transactionDate)) = YEAR(CURDATE()) 
                GROUP BY MONTH(Date(transactionDate)) ORDER BY MONTH(Date(transactionDate))";


    $chart_labels1 = array();
    $chart_data1 = array();

    if($result = mysqli_query($dbConn, $query1)) {
        if(mysqli_num_rows($result) > 0) {
            // load data
            // $i = 0;
            while($row = mysqli_fetch_array($result)) {
                $chart_labels1[] = $row['transMonth'];
                $chart_data1[] = $row['totalitems'];
                // if($i == 0) {
                //     $chart_labels = $row['transMonth'];
                //     $chart_data = $row['totalitems'];
                // } else {
                //     $chart_labels .= ", ". $row['transMonth'];
                //     $chart_data .= ", ".$row['totalitems'];
                // }           
                // $i += 1;
            }               
        }
    }

    // CHART DATA - MOST PURCHASED PRODUCTS
    $query2 = "SELECT (SELECT prod_name FROM products WHERE id = b.prod_id) AS prod_name, 
                SUM(a.itemsSold) AS totalitems  
                FROM transactionhistory a
                INNER JOIN transactiondetails b ON b.transactionNo = a.transactionNo
                WHERE YEAR(DATE(a.transactionDate)) = YEAR(CURDATE()) 
                AND MONTH(DATE(a.transactionDate)) = MONTH(CURDATE())
                GROUP BY b.prod_id";


    $chart_labels2 = array();
    $chart_data2 = array();

    if($result = mysqli_query($dbConn, $query2)) {
        if(mysqli_num_rows($result) > 0) {
            // load data
            // $i = 0;
            while($row = mysqli_fetch_array($result)) {
                if($row['totalitems'] >= 5) {
                    $chart_labels2[] = $row['prod_name'];
                    $chart_data2[] = $row['totalitems'];
                    // if($i == 0) {
                    //     $chart_labels = $row['transMonth'];
                    //     $chart_data = $row['totalitems'];
                    // } else {
                    //     $chart_labels .= ", ". $row['transMonth'];
                    //     $chart_data .= ", ".$row['totalitems'];
                    // }           
                    // $i += 1;
                }  
            }               
        }
    }

   // echo "<script>console.log(".json_encode($chart_labels).")</script>";

?>