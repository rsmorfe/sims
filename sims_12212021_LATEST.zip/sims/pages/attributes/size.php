
<!DOCTYPE html>
<html lang="en">

<?php 
  session_start();
  if (!isset($_SESSION['logged_user_id'])) {
    header('location: ../login/login.php');
    exit;
  } 
  
  include_once '../../database/connection.php'; 
  include '../head.php'; 

  if(isset($_GET['del'])) {
    // DELETE SIZE
    $sql = "DELETE FROM size WHERE size_id = ?";

    if($stmt = mysqli_prepare($dbConn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "i", $id);
        
        // Set parameters
        $id = htmlentities($_GET['del']);
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            // PREPARES CONFIRMATION MESSAGE
            $error = "<span class='text-success'>Deleted Successfully</span>";
            $_SESSION['errormsg'] = $error;

            header('location: size.php');
            exit;
        } else {
            // echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
            // PREPARES ERROR MESSAGE
            $error = "<span class='text-danger'>Unable to process request</span>";
            $_SESSION['errormsg'] = $error;

            header('location: size.php');
            exit;
        }
    } else {
        echo "ERROR: Could not prepare query: $sql. " . mysqli_error($dbConn);
    }        
  }

  if (isset($_POST['create_size'])) {
    $size = htmlspecialchars($_POST['size']);
    $encodedby = htmlspecialchars($_SESSION['logged_user_id']);

    $sql = "INSERT INTO size(size, encodedby)
    VALUES(?, ?)";

    if($stmt = mysqli_prepare($dbConn, $sql)){
      // Bind variables to the prepared statement as parameters
      mysqli_stmt_bind_param($stmt, "si", $size, $encodedby);

      // Attempt to execute the prepared statement
      if(mysqli_stmt_execute($stmt)){
          // PREPARES CONFIRMATION MESSAGE
          $error = "<span class='text-success'>Created Successfully</span>";
          $_SESSION['errormsg'] = $error;

          header('location: size.php');
          exit;
      } else {
          // echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
          // PREPARES ERROR MESSAGE
          $error = "<span class='text-danger'>Unable to process request</span>";
          $_SESSION['errormsg'] = $error;

          header('location: size.php');
          exit;
      }
    }
  }
?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php include '../navbar.php'; ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <?php include '../sidebar.php'; ?>
      <!-- partial -->
      <div class="main-panel" >
        <div class="content-wrapper" style="background-color:#E6D5B8;">
        <div class="row">
            <div class="col-md-12 grid-margin">
              <div class="d-flex justify-content-center align-items-center">
                  <div>
                    <button type="button" class="btn btn-primary btn-icon-text btn-rounded btn-sm" data-toggle="modal" data-target="#add-Size">
                        <i class="ti-plus btn-icon-prepend"></i>Add Size
                    </button> 
                    <p class="mt-4 mb-0 pb-0">
                      <?php
                        if (isset($_SESSION['errormsg'])) {
                          echo $_SESSION['errormsg'];
                          unset($_SESSION['errormsg']);
                        } 
                      ?>
                    </p>
                  </div>
              </div>
            </div>
          </div>
          <div class="row justify-content-md-center">
            <div class="col-md-6 grid-margin stretch-card justify-content-md-center">
              <div class="card">
                <div class="card-body">
                  <p class="card-title text-md-center text-xl-center">Size</p>
                  <div class=" flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                      <table id="example5" class="table table-hover" >
                          <thead style="font-size:10px">
                              <tr>
                                  <th>Size Name</th>
                                  <th hidden>Date Created</th>
                                  <th hidden></th>
                              </tr>
                          </thead>
                          <tbody>
                          <?php
                                  $sql = "SELECT * FROM size";

                                  if($result = mysqli_query($dbConn, $sql)) {
                                    if(mysqli_num_rows($result) > 0) {
                                      // load data
                                      while($row = mysqli_fetch_array($result)) {
                                        echo "<tr>";
                                        echo "<td>" . $row['size'] . "</td>";
                                        echo "<td hidden>" . $row['datecreated'] . "</td>";
                                          echo '<td class="text-right">
                                            <a href="attribute-edit.php?attribute=size&id='.$row['size_id'].'" data-toggle="tooltip" title="Edit">
                                              <button type="button" class="btn btn-primary btn-sm btn-rounded" data-toggle="modal" data-target="#edit-Category"><i class="ti-pencil-alt btn-icon-prepend"></i></button>
                                            </a>'; ?>
                                            <a href="size.php?del=<?php echo htmlentities($row['size_id']);?>" onclick="return confirm('Are you sure you want to delete?');"" data-toggle="tooltip" title="Delete">
                                              <button type="button" class="btn btn-danger btn-sm btn-rounded" data-toggle="modal" data-target="#delete-Category"><i class="ti-trash btn-icon-prepend"></i></button>
                                            </a>
                                        <?php echo '</td>';
                                        echo "</tr>";
                                      }
                                    } else {
                                      echo "<tr>";
                                        echo "No Record/s found.";
                                      echo "</tr>";
                                    }
                                  }
                                ?>
                          </tbody>
                      </table>
                  </div>  
                </div>
              </div>
            </div>
          </div>
        </div>
          <?php include '../modals.php'; ?>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
          <?php include '../footer.php'; ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

<?php include '../scripts.php'; ?>
</body>

</html>

