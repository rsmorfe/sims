<?php
    session_start();
    if (!isset($_SESSION['logged_user_id'])) {
        header('location: ../login/login.php');
        exit;
    } 

    include_once '../../database/connection.php'; 
    include '../head.php'; 

    if (isset($_POST['edit'])) {   
        updateAttribute($dbConn, $_POST['attribute'], $_POST['id'], $_POST['val1']);     
      }
  
    // FETCH SELECTED ATTRIBUTE AND RECORD
    function loadRecord($conn, $attribute, $id) {
        // SANITIZE
        $id = htmlspecialchars($id);
        $attribute = htmlspecialchars($attribute);

        // VALIDATE WHAT ATTRIBUTE TO UPDATE
        $sql = "";
        if($attribute == 'color') {
            $sql = "SELECT color as attributeValue FROM color WHERE color_id = {$id}";
        } elseif($attribute == 'fabric') {
            $sql = "SELECT fabric as attributeValue FROM fabric WHERE fabric_id = {$id}";
        } elseif($attribute == 'size') {
            $sql = "SELECT size as attributeValue FROM size WHERE size_id = {$id}";
        }

        if($result = mysqli_query($conn, $sql)) {
            if(mysqli_num_rows($result) > 0) {
                return mysqli_fetch_array($result);
            }
        }
    }

    // UPDATING ATTRIBUTE
    function updateAttribute($conn, $attribute, $id, $val1) {
        //include_once '../database/connection.php'; 

        // SANITIZE
        $id = htmlspecialchars($id);
        $val1 = htmlspecialchars($val1);
        $attribute = htmlspecialchars($attribute);

        // VALIDATE WHAT ATTRIBUTE TO UPDATE
        if($attribute == 'color') {
            $sql = "UPDATE color SET 
            color = ? WHERE color_id = ?";
        } elseif($attribute == 'fabric') {
            $sql = "UPDATE fabric SET 
            fabric = ? WHERE fabric_id = ?";
        } elseif($attribute == 'size') {
            $sql = "UPDATE size SET 
            size = ? WHERE size_id = ?";
        }

        if($stmt = mysqli_prepare($conn, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "si", $val1, $id);
        
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                $path = "";
                if($attribute == 'color') {
                    $path = "color.php";
                } elseif($attribute == 'fabric') {
                    $path = "fabric.php";
                } elseif($attribute == 'size') {
                    $path = "size.php";
                }
                // PREPARES CONFIRMATION MESSAGE
                $error = "<span class='text-success'>Updated Successfully</span>";
                $_SESSION['errormsg'] = $error;

                header('location: ' .$path);
                exit;
            } else {
                // echo "ERROR: Could not execute query: $sql. " . mysqli_error($conn);
                $path = "";
                if($attribute == 'color') {
                    $path = "color.php";
                } elseif($attribute == 'fabric') {
                    $path = "fabric.php";
                } elseif($attribute == 'size') {
                    $path = "size.php";
                }

                // PREPARES ERROR MESSAGE
                $error = "<span class='text-danger'>Unable to process request</span>";
                $_SESSION['errormsg'] = $error;

                header('location: ' .$path);
                exit;
            }
        }
    }

    // SET ATTRIBUTE LABEL
    function setLabel($attribute) {
        // SANITIZE
        $attribute = htmlspecialchars($attribute);

        // VALIDATE WHAT ATTRIBUTE TO UPDATE
        if($attribute == 'color') {
            return "COLOR";
        } elseif($attribute == 'fabric') {
            return "FABRIC";
        } elseif($attribute == 'size') {
            return "SIZE";
        }
    }

    // SET CANCEL URL PATH
    function setURL($attribute) {
        // SANITIZE
        $attribute = htmlspecialchars($attribute);

        // VALIDATE WHAT ATTRIBUTE TO UPDATE
        if($attribute == 'color') {
            return "color.php";
        } elseif($attribute == 'fabric') {
            return "fabric.php";
        } elseif($attribute == 'size') {
            return "size.php";
        }
    }
?>

<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php include '../navbar.php'; ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <?php include '../sidebar.php'; ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper" style="background-color:#E6D5B8;">
          <div class="row">

          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <p class="card-title text-md-center text-xl-left">Edit <?php echo setLabel($_GET['attribute']); ?></p>
                  <div class=" flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                        <form role="form" class="mt-4" method="POST" action="attribute-edit.php">  
                        <div class="row">
                            <div class="form-group col-md-12">
                                <?php
                                    $row = loadRecord($dbConn, $_GET['attribute'], $_GET['id']); 
                                ?>
                                <input type="text" class="form-control" id="id" name="id" value="<?php echo htmlspecialchars($_GET['id']);?>" hidden>
                                <input type="text" class="form-control" id="attribute" name="attribute" value="<?php echo htmlspecialchars($_GET['attribute']);?>" hidden>
                                <label for="val1"><?php echo setLabel($_GET['attribute']); ?></label>
                                <input type="text" class="form-control" id="val1" name="val1" value="<?php echo $row['attributeValue'];?>">
                            </div>
                        </div>
                            <button type="submit" class="btn btn-primary btn-rounded" name="edit">Save</button>
                            <a href="<?php echo setURL($_GET['attribute']); ?>">
                                <button type="button" class="btn btn-default btn-rounded">Cancel</button>
                            </a>
                            
                        </form>
                  </div>  
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
          <?php include '../footer.php'; ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

<?php include '../scripts.php'; ?>
</body>

</html>