
<!DOCTYPE html>
<html lang="en">

<?php 
  session_start();
  if (!isset($_SESSION['logged_user_id'])) {
    header('location: ../login/login.php');
    exit;
  } 

  include '../../database/connection.php'; 
  include '../head.php'; 

  if(isset($_POST['profile_update'])) {
    $user_id = htmlspecialchars($_POST['user_id']);
    $user_fname = htmlspecialchars($_POST['user_fname']);
    $user_lname = htmlspecialchars($_POST['user_lname']);
    $user_contactno = htmlspecialchars($_POST['user_contactno']);

    $sql = "UPDATE users SET LastName = ?, FirstName = ?, contactno = ? WHERE user_id = ?";

    if($stmt = mysqli_prepare($dbConn, $sql)){
      // Bind variables to the prepared statement as parameters
      mysqli_stmt_bind_param($stmt, "sssi", $user_fname, $user_lname, $user_contactno, $user_id);

      // Attempt to execute the prepared statement
      if(mysqli_stmt_execute($stmt)){
          // PREPARES CONFIRMATION MESSAGE
          $error = "<span class='text-success'>Updated Successfully</span>";
          $_SESSION['errormsg'] = $error;

          header('location: profile.php');
          exit;
      } else {
          // echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
          // PREPARES ERROR MESSAGE
          $error = "<span class='text-danger'>Unable to process request</span>";
          $_SESSION['errormsg'] = $error;

          header('location: profile.php');
          exit;
      }
    }
    
  }

?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php include '../navbar.php'; ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <?php include '../sidebar.php'; ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper" style="background-color:#E6D5B8;">
          <div class="row">
            <?php
              if (isset($_SESSION['errormsg'])) {
                echo $_SESSION['errormsg'];
                unset($_SESSION['errormsg']);
              } 
            ?>
          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <p class="card-title text-md-center text-xl-left">User Profile</p>
                  <div class=" flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                    <form role="form" method="POST" action="profile.php">  
                        <div class="row">
                            <?php 
                                $id = htmlspecialchars($_SESSION['logged_user_id']);
                                $sql = "SELECT * FROM users where User_id = " .$id;

                                if($result = mysqli_query($dbConn, $sql)) {
                                    if(mysqli_num_rows($result) > 0) {
                                        // load data
                                        while($row = mysqli_fetch_array($result)) {
                                            echo '<div class="form-group col-md-12">
                                                    <label for="First Name">First Name</label>
                                                    <input type="text" class="form-control" name="user_id" value="'.$row['User_id'].'" hidden>
                                                    <input type="text" class="form-control" id="First Name" name="user_fname" value="'.$row['FirstName'].'" placeholder="First Name">
                                                </div>
                                                <div class="form-group col-md-12">
                                                    <label for="Last Name">Last Name</label>
                                                    <input type="text" class="form-control" id="Last Name" name="user_lname"  value="'.$row['LastName'].'" placeholder="Username">
                                                </div>
                                                <div class="form-group col-md-12">
                                                    <label for="Contact Number">Contact Number</label>
                                                    <input type="text" class="form-control" id="Contact Number" name="user_contactno"  value="'.$row['contactno'].'" placeholder="Contact Number">
                                                </div>';
                                        }
                                    }
                                }
                                
                            ?>
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded" name="profile_update">Update Profile</button>
                        <a href="../inventory/inventory.php">
                          <button type="button" class="btn btn-default btn-rounded">Cancel</button> 
                        </a>
                    </form>
                  </div>  
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
          <?php include '../footer.php'; ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

<?php include '../scripts.php'; ?>
</body>

</html>

