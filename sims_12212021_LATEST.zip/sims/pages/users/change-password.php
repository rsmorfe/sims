
<!DOCTYPE html>
<html lang="en">

<?php 
  session_start();
  if (!isset($_SESSION['logged_user_id'])) {
    header('location: ../login/login.php');
    exit;
  } 

  include_once '../../database/connection.php'; 
  include '../head.php'; 


  if (isset($_POST['change_pass'])) {
    $user_id = htmlspecialchars($_SESSION['logged_user_id']);
    $oldpass = htmlspecialchars($_POST['old_pass']);
    $newpass = htmlspecialchars($_POST['new_pass']);
    $confirmpass = htmlspecialchars($_POST['confirm_pass']);
    $current_pass = "";

    $sql = "SELECT User_Pass FROM users WHERE User_id ='" . $user_id . "'";

    if ($result = mysqli_query($dbConn, $sql)) {
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_array($result);
            $current_pass = $row['User_Pass'];
        }
    }

    if ($oldpass != $current_pass) {
        $error = "Entered old password is incorrect.";
        $_SESSION['errormsg'] = $error;
    } else {
        if($newpass != $confirmpass) {
            $error = "Password doesn't match.";
            $_SESSION['errormsg'] = $error;
        } else {
            $sql = "UPDATE users SET User_Pass = ? WHERE User_id = ?";
    
            if($stmt = mysqli_prepare($dbConn, $sql)){
                // Bind variables to the prepared statement as parameters
                mysqli_stmt_bind_param($stmt, "si", $newpass, $user_id);
            
                // Attempt to execute the prepared statement
                if(mysqli_stmt_execute($stmt)){
                    $_SESSION['confirm_msg'] = 'Password Updated Successfully';
                    header('location: change-password.php');
                    exit;
                } else {
                    // echo "ERROR: Could not execute query: $sql. " . mysqli_error($dbConn);
                    $_SESSION['errormsg'] = 'Unable to process request';
                    header('location: change-password.php');
                    exit;
                }
            }
        }
    } 
    
  }
?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php include '../navbar.php'; ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <?php include '../sidebar.php'; ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper" style="background-color:#E6D5B8;">
          <div class="row">

          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <p class="card-title text-md-center text-xl-left">Change Password</p>
                  <div class=" flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                    <?php
                        if (isset($_SESSION['errormsg'])) {
                            echo "<span class='text text-danger'>".$_SESSION['errormsg']."</span>";
                            unset($_SESSION['errormsg']);
                        } else if (isset($_SESSION['confirm_msg'])) {
                            echo "<span class='text text-success'>".$_SESSION['confirm_msg']."</span>";
                            unset($_SESSION['confirm_msg']);
                        } 
                    ?>  
                  <form role="form" class="mt-4" method="POST" action="change-password.php">  
                        <div class="form-group">
                            <input type="password" class="form-control form-control-lg" id="old_pass" name="old_pass" placeholder="Enter Old Password" required>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control form-control-lg" id="new_pass" name="new_pass" placeholder="Enter New Password" required>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control form-control-lg" id="confirm_pass" name="confirm_pass" placeholder="Confirm New Password" required>
                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded" name="change_pass">Save</button>
                        <a href="../inventory/inventory.php">
                            <button type="button" class="btn btn-default btn-rounded">Cancel</button> 
                        </a>
                    </form>
                  </div>  
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
          <?php include '../footer.php'; ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

<?php include '../scripts.php'; ?>
</body>

</html>

