
<!DOCTYPE html>
<html lang="en">

<?php 
  session_start();
  if (!isset($_SESSION['logged_user_id'])) {
    header('location: ../login/login.php');
    exit;
  } 

  include_once '../../database/connection.php'; 
  include '../head.php'; 
?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php include '../navbar.php'; ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <?php include '../sidebar.php'; ?>
      <!-- partial -->
      <div class="main-panel" >
        <div class="content-wrapper" style="background-color:#E6D5B8;">
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <p class="card-title text-md-center text-xl-left">Audit Log</p>
                  <div class=" flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                      <table id='example1' class="table table-hover" >
                          <thead style="font-size:10px">
                              <tr>
                                  <th>Action</th>
                                  <th>Description</th>
                                  <th>Date Recorded</th>
                              </tr>
                          </thead>
                          <tbody>
                            <?php
                              $sql = "SELECT * FROM auditlogs 
                                      WHERE user_id = " .htmlspecialchars($_SESSION['logged_user_id'])." 
                                      ORDER BY datecreated DESC";

                              if($result = mysqli_query($dbConn, $sql)) {
                                if(mysqli_num_rows($result) > 0) {
                                  // load data
                                  while($row = mysqli_fetch_array($result)) {
                                    echo "<tr>";
                                      echo "<td>" . $row['user_action'] . "</td>";
                                      echo "<td>" . $row['actiondescription'] . "</td>";
                                      echo "<td>" . $row['datecreated'] . "</td>";
                                    echo "</tr>";
                                  }
                                } else {
                                  echo "<tr>";
                                    echo "No Record/s found.";
                                  echo "</tr>";
                                }
                              }
                            ?>   
                          </tbody>
                      </table>
                  </div>  
                </div>
              </div>
            </div>
          </div>
        </div>
          <?php include '../modals.php'; ?>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
          <?php include '../footer.php'; ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

<?php include '../scripts.php'; ?>
</body>

</html>

