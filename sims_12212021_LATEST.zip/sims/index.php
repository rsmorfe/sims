<?php

    header('location:pages/login/login.php');
    exit;
?>