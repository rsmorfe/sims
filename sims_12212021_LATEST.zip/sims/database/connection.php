<?php
    /* Database credentials. Assuming you are running MySQL
    server with default setting (user 'root' with no password) */
    define('DB_SERVER', 'localhost');
    define('DB_USERNAME', 'root');
    define('DB_PASSWORD', '');
    define('DB_NAME', 'db_sims');
    
    /* Attempt to connect to MySQL database */
    $dbConn = setDBConnection(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

    // Check connection
    checkConnection($dbConn);


    // FUNCTIONS
    function setDBConnection($server, $user, $pass, $db_name) {
        return mysqli_connect($server, $user, $pass, $db_name);
    }
    
    function checkConnection($dbConnection) {
        // Checks connection
        if($dbConnection === false){
            die("ERROR: Could not connect. " . mysqli_connect_error());
        } else {
            echo "<script> console.log('Connected'); </script>"; // for debugging only
        }
    }


?>