-- MariaDB dump 10.19  Distrib 10.4.19-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: db_sims
-- ------------------------------------------------------
-- Server version	10.4.19-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auditlogs`
--

DROP TABLE IF EXISTS `auditlogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auditlogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_action` varchar(15) DEFAULT NULL,
  `actiondescription` varchar(100) NOT NULL DEFAULT '',
  `datecreated` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditlogs`
--

LOCK TABLES `auditlogs` WRITE;
/*!40000 ALTER TABLE `auditlogs` DISABLE KEYS */;
INSERT INTO `auditlogs` VALUES (1,1,'CREATE PRODUCT','Added new item Levis Jagged Pants','2021-07-15 09:59:51'),(2,1,'UPDATE PRODUCT','updated item Levis Jagged Pants','2021-07-15 10:00:17'),(3,1,'CREATE PRODUCT','Added new item Stacey','2021-07-15 13:22:59'),(4,1,'UPDATE PRODUCT','updated item Levis Jagged Pants','2021-07-15 13:28:56'),(5,1,'UPDATE PRODUCT','updated item Levis T-Shirt Red','2021-07-15 13:29:32'),(8,1,'CREATE PRODUCT','Added new item Levis Sando for Men','2021-10-29 19:19:33'),(9,1,'UPDATE PRODUCT','updated item Levis Sando for Men','2021-10-29 19:22:34'),(10,1,'CHECKOUT','Performed checkout. Transaction number: 38','2021-10-29 19:29:49');
/*!40000 ALTER TABLE `auditlogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(30) NOT NULL,
  `cat_status` int(11) DEFAULT NULL,
  `encodedby` int(11) DEFAULT NULL,
  `dateencoded` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Dress',1,1,'2021-07-14 20:34:38'),(3,'Rommper',1,1,'2021-07-14 20:54:45'),(4,'Maxi Dress',1,1,'2021-07-14 20:55:08'),(5,'Midi Dress',1,1,'2021-07-14 20:55:16'),(6,'Jumpsuit',1,1,'2021-07-14 20:55:29'),(7,'Mini Dress',1,1,'2021-07-15 10:57:07'),(8,'Nitted',1,1,'2021-07-15 10:57:17'),(9,'Traditional',0,1,'2021-07-15 10:59:22');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `color`
--

DROP TABLE IF EXISTS `color`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `color` (
  `color_id` int(11) NOT NULL AUTO_INCREMENT,
  `color` varchar(15) NOT NULL,
  `encodedby` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`color_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `color`
--

LOCK TABLES `color` WRITE;
/*!40000 ALTER TABLE `color` DISABLE KEYS */;
INSERT INTO `color` VALUES (1,'red',1,'2021-07-14 23:19:10'),(2,'green',1,'2021-07-14 23:20:16'),(3,'blue',1,'2021-07-14 23:20:21'),(4,'black',1,'2021-07-15 11:33:24'),(5,'white',1,'2021-07-15 11:33:30');
/*!40000 ALTER TABLE `color` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(20) DEFAULT NULL,
  `lastname` varchar(20) DEFAULT NULL,
  `contactno` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'Dondie','Dela Cruz','0987654321');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee` (
  `emp_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(20) DEFAULT NULL,
  `lastname` varchar(20) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `contactno` varchar(20) DEFAULT NULL,
  `position_id` int(11) DEFAULT NULL,
  `datehired` datetime DEFAULT NULL,
  PRIMARY KEY (`emp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (1,'Dondie','Dela Cruz','M',NULL,'0987654321',NULL,NULL);
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fabric`
--

DROP TABLE IF EXISTS `fabric`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fabric` (
  `fabric_id` int(11) NOT NULL AUTO_INCREMENT,
  `fabric` varchar(15) NOT NULL,
  `encodedby` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`fabric_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fabric`
--

LOCK TABLES `fabric` WRITE;
/*!40000 ALTER TABLE `fabric` DISABLE KEYS */;
INSERT INTO `fabric` VALUES (1,'Cotton',1,'2021-07-15 11:27:46'),(2,'Polyster',1,'2021-07-15 11:31:31'),(3,'Chiffon',1,'2021-07-15 11:31:36'),(4,'Lace',1,'2021-07-15 11:31:45'),(5,'Linen',1,'2021-07-15 11:31:50'),(6,'Creep',1,'2021-07-15 11:32:00'),(7,'Chaliz',1,'2021-07-15 11:32:08');
/*!40000 ALTER TABLE `fabric` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `for_purchase`
--

DROP TABLE IF EXISTS `for_purchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `for_purchase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prod_id` int(11) NOT NULL,
  `prod_name` varchar(50) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `prod_price` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `for_purchase`
--

LOCK TABLES `for_purchase` WRITE;
/*!40000 ALTER TABLE `for_purchase` DISABLE KEYS */;
/*!40000 ALTER TABLE `for_purchase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventoryitems`
--

DROP TABLE IF EXISTS `inventoryitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventoryitems` (
  `prod_id` int(11) DEFAULT NULL,
  `inv_action` varchar(20) DEFAULT NULL,
  `inv_itemqty` int(11) NOT NULL,
  `createdby` int(11) NOT NULL,
  `datacreated` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventoryitems`
--

LOCK TABLES `inventoryitems` WRITE;
/*!40000 ALTER TABLE `inventoryitems` DISABLE KEYS */;
INSERT INTO `inventoryitems` VALUES (2,'addstock',10,1,'2021-07-15 15:20:30'),(2,'checkout',5,1,'2021-07-15 15:20:59');
/*!40000 ALTER TABLE `inventoryitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemcode` varchar(20) DEFAULT NULL,
  `prod_name` varchar(20) NOT NULL,
  `prod_cat` int(11) NOT NULL,
  `prod_size` int(11) DEFAULT NULL,
  `prod_color` int(11) DEFAULT NULL,
  `prod_fabric` int(11) DEFAULT NULL,
  `prod_price` varchar(50) DEFAULT NULL,
  `prod_sellingprice` varchar(50) DEFAULT NULL,
  `prod_image` varchar(100) DEFAULT NULL,
  `createdby` int(11) NOT NULL,
  `datecreated` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `itemcode` (`itemcode`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'T001','Levis T-Shirt Red',1,2,1,5,'200.00','250.00','levis_tshirt_red_men.jpg',1,'2021-07-15 08:57:30'),(2,'P001','Levis Jagged Pants',1,1,3,2,'400.00','450.00','levis_jaggedpants.jpg',1,'2021-07-15 09:59:51'),(3,'ST001','Stacey',3,1,1,1,'180.00','200.00','stacey_romper.jpg',1,'2021-07-15 13:22:59'),(6,'TS002','Levis Sando for Men',1,2,1,1,' 275.00','300.00','levis_sando_red.jpg',1,'2021-10-29 19:19:33');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `size`
--

DROP TABLE IF EXISTS `size`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `size` (
  `size_id` int(11) NOT NULL AUTO_INCREMENT,
  `size` varchar(10) NOT NULL,
  `encodedby` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`size_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `size`
--

LOCK TABLES `size` WRITE;
/*!40000 ALTER TABLE `size` DISABLE KEYS */;
INSERT INTO `size` VALUES (1,'S',1,'2021-07-14 23:29:26'),(2,'M',1,'2021-07-14 23:30:01'),(3,'L',1,'2021-07-14 23:30:06'),(4,'XL',1,'2021-07-15 11:33:05'),(5,'XXL',1,'2021-07-15 11:33:09'),(6,'XXXL',1,'2021-07-15 11:33:12');
/*!40000 ALTER TABLE `size` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier` (
  `supplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(30) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `contactno` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
INSERT INTO `supplier` VALUES (1,'ABC Merchandize','Poblacion, Muntinlupa','8472477');
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactiondetails`
--

DROP TABLE IF EXISTS `transactiondetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactiondetails` (
  `transactionNo` int(11) NOT NULL,
  `transactionDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `prod_id` int(11) DEFAULT NULL,
  `item` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(12,2) DEFAULT NULL,
  `totalPrice` decimal(12,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactiondetails`
--

LOCK TABLES `transactiondetails` WRITE;
/*!40000 ALTER TABLE `transactiondetails` DISABLE KEYS */;
INSERT INTO `transactiondetails` VALUES (28,'2021-10-29 07:44:17',1,'Levis T-Shirt Red',2,250.00,500.00),(28,'2021-10-29 07:44:17',3,'Stacey',1,200.00,200.00),(28,'2021-10-29 07:44:17',2,'Levis Jagged Pants',1,450.00,450.00),(29,'2021-10-29 07:44:55',1,'Levis T-Shirt Red',1,250.00,250.00),(29,'2021-10-29 07:44:55',3,'Stacey',1,200.00,200.00),(30,'2021-10-29 07:46:00',2,'Levis Jagged Pants',1,450.00,450.00),(31,'2021-10-29 09:42:51',1,'Levis T-Shirt Red',1,250.00,250.00),(32,'2021-10-29 09:43:31',3,'Stacey',1,200.00,200.00),(34,'2021-10-29 09:44:55',1,'Levis T-Shirt Red',1,250.00,250.00),(35,'2021-10-29 09:45:05',1,'Levis T-Shirt Red',1,250.00,250.00),(38,'2021-10-29 11:29:48',6,'Levis Sando for Men',1,300.00,300.00),(38,'2021-10-29 11:29:48',2,'Levis Jagged Pants',1,450.00,450.00);
/*!40000 ALTER TABLE `transactiondetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactionhistory`
--

DROP TABLE IF EXISTS `transactionhistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactionhistory` (
  `transactionNo` int(11) NOT NULL AUTO_INCREMENT,
  `transactionDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `itemsSold` int(11) NOT NULL,
  `totalPrice` decimal(12,2) DEFAULT NULL,
  `createdby` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`transactionNo`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactionhistory`
--

LOCK TABLES `transactionhistory` WRITE;
/*!40000 ALTER TABLE `transactionhistory` DISABLE KEYS */;
INSERT INTO `transactionhistory` VALUES (28,'2021-10-29 07:44:17',4,1150.00,'admin'),(29,'2021-10-29 07:44:55',2,450.00,'admin'),(30,'2021-10-29 07:46:00',1,450.00,'admin'),(31,'2021-10-29 09:42:51',1,250.00,'admin'),(32,'2021-10-29 09:43:31',1,200.00,'admin'),(34,'2021-10-29 09:44:55',1,250.00,'admin'),(35,'2021-10-29 09:45:05',1,250.00,'admin'),(38,'2021-10-29 11:29:48',2,750.00,'admin');
/*!40000 ALTER TABLE `transactionhistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userlogs`
--

DROP TABLE IF EXISTS `userlogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userlogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `actionType` varchar(20) DEFAULT NULL,
  `actionDescription` varchar(50) DEFAULT NULL,
  `dateRecorded` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userlogs`
--

LOCK TABLES `userlogs` WRITE;
/*!40000 ALTER TABLE `userlogs` DISABLE KEYS */;
INSERT INTO `userlogs` VALUES (1,1,'SYSTEM ACCESS','Logged in to the system','2021-07-14 19:26:55'),(2,1,'SYSTEM ACCESS','Logged out from the system','2021-07-14 19:27:25'),(3,1,'SYSTEM ACCESS','Logged in to the system','2021-07-14 19:28:00'),(4,1,'SYSTEM ACCESS','Logged out from the system','2021-07-14 19:42:38'),(5,1,'SYSTEM ACCESS','Logged in to the system','2021-07-14 19:51:36'),(6,1,'SYSTEM ACCESS','Logged out from the system','2021-07-14 21:28:46'),(7,1,'SYSTEM ACCESS','Logged in to the system','2021-07-14 21:36:59'),(8,1,'SYSTEM ACCESS','Logged out from the system','2021-07-14 23:33:28'),(9,1,'SYSTEM ACCESS','Logged in to the system','2021-07-15 06:03:24'),(10,1,'SYSTEM ACCESS','Logged out from the system','2021-07-15 07:33:05'),(11,1,'SYSTEM ACCESS','Logged in to the system','2021-07-15 07:33:08'),(12,1,'SYSTEM ACCESS','Logged out from the system','2021-07-15 11:04:45'),(13,5,'SYSTEM ACCESS','Logged in to the system','2021-07-15 11:04:51'),(14,5,'SYSTEM ACCESS','Logged out from the system','2021-07-15 11:05:12'),(15,5,'SYSTEM ACCESS','Logged in to the system','2021-07-15 11:05:18'),(16,5,'SYSTEM ACCESS','Logged out from the system','2021-07-15 11:05:28'),(17,1,'SYSTEM ACCESS','Logged in to the system','2021-07-15 11:05:47'),(18,1,'SYSTEM ACCESS','Logged out from the system','2021-07-15 11:05:57'),(19,1,'SYSTEM ACCESS','Logged in to the system','2021-07-15 11:06:08'),(20,1,'SYSTEM ACCESS','Logged out from the system','2021-07-15 15:23:02'),(21,1,'SYSTEM ACCESS','Logged in to the system','2021-07-15 15:23:06'),(22,1,'SYSTEM ACCESS','Logged out from the system','2021-07-15 15:23:39'),(23,1,'SYSTEM ACCESS','Logged in to the system','2021-07-15 15:23:42'),(24,1,'SYSTEM ACCESS','Logged out from the system','2021-07-15 15:23:47'),(25,1,'SYSTEM ACCESS','Logged in to the system','2021-10-01 07:11:48'),(26,1,'SYSTEM ACCESS','Logged out from the system','2021-10-01 08:02:27'),(27,1,'SYSTEM ACCESS','Logged in to the system','2021-10-01 08:02:30'),(28,1,'SYSTEM ACCESS','Logged out from the system','2021-10-01 10:11:54'),(29,1,'SYSTEM ACCESS','Logged in to the system','2021-10-01 10:12:13'),(30,1,'SYSTEM ACCESS','Logged out from the system','2021-10-01 10:39:37'),(31,1,'SYSTEM ACCESS','Logged in to the system','2021-10-28 06:50:50'),(32,1,'SYSTEM ACCESS','Logged out from the system','2021-10-28 06:51:57'),(33,1,'SYSTEM ACCESS','Logged in to the system','2021-10-28 06:54:18'),(34,1,'SYSTEM ACCESS','Logged out from the system','2021-10-28 06:56:13'),(35,5,'SYSTEM ACCESS','Logged in to the system','2021-10-28 06:56:51'),(36,5,'SYSTEM ACCESS','Logged out from the system','2021-10-28 06:59:04'),(37,5,'SYSTEM ACCESS','Logged in to the system','2021-10-28 06:59:12'),(38,5,'SYSTEM ACCESS','Logged out from the system','2021-10-28 07:00:53'),(39,5,'SYSTEM ACCESS','Logged in to the system','2021-10-28 07:00:58'),(40,5,'SYSTEM ACCESS','Logged out from the system','2021-10-28 07:08:30'),(41,1,'SYSTEM ACCESS','Logged in to the system','2021-10-28 07:08:34'),(42,1,'SYSTEM ACCESS','Logged out from the system','2021-10-28 20:47:11'),(43,1,'SYSTEM ACCESS','Logged in to the system','2021-10-29 07:44:56'),(44,1,'SYSTEM ACCESS','Logged in to the system','2021-10-29 09:28:12'),(45,1,'SYSTEM ACCESS','Logged in to the system','2021-10-29 09:36:24'),(46,1,'SYSTEM ACCESS','Logged out from the system','2021-10-29 19:33:48');
/*!40000 ALTER TABLE `userlogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `User_id` int(11) NOT NULL AUTO_INCREMENT,
  `LastName` varchar(20) NOT NULL,
  `FirstName` varchar(20) NOT NULL,
  `contactno` varchar(15) DEFAULT NULL,
  `position` varchar(25) DEFAULT NULL,
  `User_Name` varchar(15) NOT NULL,
  `User_Pass` varchar(15) NOT NULL,
  `User_Level` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT current_timestamp(),
  `User_Status` int(11) DEFAULT NULL,
  PRIMARY KEY (`User_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Administrator','System','09998765431','Administrator','admin','admin',1,'2021-07-14 09:07:38',1),(2,'Account 1','User','09876543210','Staff','user1','1234',2,'2021-07-14 09:31:53',0),(5,'Dela Cruz','Dondie','9871234567','Manager','ddelacruz','1234',2,'2021-07-14 15:43:58',1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-29 19:35:07
