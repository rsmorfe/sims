-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 21, 2021 at 11:34 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_sims`
--

-- --------------------------------------------------------

--
-- Table structure for table `auditlogs`
--

CREATE TABLE `auditlogs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_action` varchar(15) DEFAULT NULL,
  `actiondescription` varchar(100) NOT NULL DEFAULT '',
  `datecreated` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `auditlogs`
--

INSERT INTO `auditlogs` (`id`, `user_id`, `user_action`, `actiondescription`, `datecreated`) VALUES
(79, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 112', '2021-12-02 17:40:15'),
(80, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 113', '2021-12-02 17:40:42'),
(81, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 114', '2021-12-02 17:42:31'),
(82, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 115', '2021-12-02 17:45:59'),
(83, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 116', '2021-12-02 17:46:34'),
(84, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 117', '2021-12-02 17:46:56'),
(85, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 118', '2021-12-02 17:48:43'),
(86, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 119', '2021-12-02 17:51:54'),
(87, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 120', '2021-12-02 17:53:54'),
(88, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 121', '2021-12-02 17:56:46'),
(89, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 122', '2021-12-02 17:57:57'),
(90, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 123', '2021-12-02 17:59:30'),
(91, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 124', '2021-12-02 18:02:21'),
(92, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 125', '2021-12-02 18:05:08'),
(93, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 126', '2021-12-02 18:05:31'),
(94, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 127', '2021-12-02 18:07:06'),
(95, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 128', '2021-12-02 18:07:43'),
(96, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 129', '2021-12-02 18:19:54'),
(97, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 130', '2021-12-02 18:20:32'),
(98, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 131', '2021-12-02 18:22:59'),
(99, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 132', '2021-12-02 18:23:40'),
(100, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 133', '2021-12-02 18:24:45'),
(101, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 134', '2021-12-02 18:26:33'),
(102, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 135', '2021-12-02 18:27:40'),
(103, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 136', '2021-12-02 18:28:09'),
(104, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 137', '2021-12-02 18:30:40'),
(105, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 138', '2021-12-02 18:31:36'),
(106, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 139', '2021-12-02 18:33:39'),
(107, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 140', '2021-12-02 18:35:16'),
(108, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 141', '2021-12-02 18:35:40'),
(109, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 142', '2021-12-02 18:35:47'),
(110, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 143', '2021-12-02 18:36:14'),
(111, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 144', '2021-12-02 18:37:43'),
(112, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 145', '2021-12-02 18:39:59'),
(113, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 146', '2021-12-02 18:41:37'),
(114, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 147', '2021-12-02 18:42:12'),
(115, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 148', '2021-12-02 18:42:52'),
(116, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 149', '2021-12-02 18:50:23'),
(117, 1, 'CHECKOUT', 'Processed Order. Order number: 1', '2021-12-03 07:26:33'),
(118, 1, 'CHECKOUT', 'Processed Order. Order number: 2', '2021-12-03 07:35:23'),
(119, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 151', '2021-12-03 10:48:21'),
(120, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 152', '2021-12-03 10:49:40'),
(121, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 153', '2021-12-03 10:50:29'),
(122, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 154', '2021-12-03 10:51:47'),
(123, 1, 'CHECKOUT', 'Processed Order. Order number: 3', '2021-12-03 10:59:33'),
(124, 1, 'CHECKOUT', 'Processed Order. Order number: 4', '2021-12-03 10:59:54'),
(125, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 155', '2021-12-03 11:01:22'),
(126, 1, 'CHECKOUT', 'Processed Order. Order number: 5', '2021-12-03 11:47:51'),
(127, 1, 'CHECKOUT', 'Processed Order. Order number: 6', '2021-12-03 11:50:10'),
(128, 1, 'CHECKOUT', 'Processed Order. Order number: 7', '2021-12-03 11:50:29'),
(129, 1, 'CHECKOUT', 'Processed Order. Order number: 8', '2021-12-03 12:00:04'),
(130, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 156', '2021-12-03 12:00:14'),
(131, 5, 'UPDATE PRODUCT', 'updated item Levis Sando for Men', '2021-12-03 14:07:31'),
(132, 5, 'UPDATE PRODUCT', 'updated item Levis Sando for Men', '2021-12-03 14:07:39'),
(133, 1, 'CHECKOUT', 'Processed Order. Order number: 9', '2021-12-03 14:22:02'),
(134, 1, 'CHECKOUT', 'Processed Order. Order number: 10', '2021-11-30 06:30:51'),
(135, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 157', '2021-11-30 06:30:57'),
(136, 1, 'CHECKOUT', 'Processed Order. Order number: 11', '2021-12-04 07:59:43'),
(137, 1, 'CHECKOUT', 'Processed Order. Order number: 12', '2021-12-04 07:59:52'),
(138, 1, 'CHECKOUT', 'Processed Order. Order number: 13', '2021-12-04 07:59:58'),
(139, 1, 'CHECKOUT', 'Processed Order. Order number: 14', '2021-12-04 08:00:04'),
(140, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 158', '2021-12-04 08:00:10'),
(141, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 159', '2021-12-04 08:00:23'),
(142, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 160', '2021-12-04 08:00:30'),
(143, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 161', '2021-12-04 08:00:38'),
(144, 1, 'CHECKOUT', 'Processed Order. Order number: 15', '2021-12-04 08:02:20'),
(145, 1, 'CHECKOUT', 'Processed Order. Order number: 16', '2021-12-06 10:37:25'),
(146, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 162', '2021-12-06 12:22:01'),
(147, 1, 'CHECKOUT', 'Processed Order. Order number: 17', '2021-12-08 19:44:56'),
(148, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 163', '2021-12-08 19:46:19'),
(149, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 164', '2021-12-08 19:47:24'),
(150, 1, 'CHECKOUT', 'Processed Order. Order number: 18', '2021-12-08 19:58:20'),
(151, 1, 'CHECKOUT', 'Processed Order. Order number: 19', '2021-12-08 19:58:46'),
(152, 1, 'CREATE PRODUCT', 'Added new item Black Stripes', '2021-12-09 10:48:30'),
(153, 1, 'CREATE PRODUCT', 'Added new item White Stripes', '2021-12-09 10:54:43'),
(154, 1, 'UPDATE PRODUCT', 'updated item Black Stripes', '2021-12-09 10:56:44'),
(155, 1, 'UPDATE PRODUCT', 'updated item White Stripes', '2021-12-09 10:56:48'),
(156, 1, 'CREATE PRODUCT', 'Added new item Yellow Stripes', '2021-12-09 10:59:00'),
(157, 1, 'UPDATE PRODUCT', 'updated item Yellow Stripes', '2021-12-09 10:59:07'),
(158, 1, 'CREATE PRODUCT', 'Added new item Purple Stripes', '2021-12-09 11:02:22'),
(159, 1, 'UPDATE PRODUCT', 'updated item Purple Stripes', '2021-12-09 11:02:28'),
(160, 1, 'CREATE PRODUCT', 'Added new item Black \'n White Skirt', '2021-12-09 11:07:07'),
(161, 1, 'CREATE PRODUCT', 'Added new item Veina', '2021-12-09 11:11:40'),
(162, 1, 'UPDATE PRODUCT', 'updated item Veina', '2021-12-09 11:11:46'),
(163, 1, 'UPDATE PRODUCT', 'updated item Loius', '2021-12-09 11:11:54'),
(164, 1, 'CREATE PRODUCT', 'Added new item Angel', '2021-12-09 11:13:20'),
(165, 1, 'CREATE PRODUCT', 'Added new item Bien', '2021-12-09 11:16:42'),
(166, 1, 'CHECKOUT', 'Processed Order. Order number: 20', '2021-12-09 11:43:14'),
(167, 1, 'CREATE PRODUCT', 'Added new item Lou', '2021-12-09 11:46:24'),
(168, 1, 'CREATE PRODUCT', 'Added new item Kays', '2021-12-09 11:50:06'),
(169, 1, 'CREATE PRODUCT', 'Added new item Rose', '2021-12-09 11:51:52'),
(170, 1, 'CREATE PRODUCT', 'Added new item Rame', '2021-12-09 11:53:30'),
(171, 1, 'CREATE PRODUCT', 'Added new item Grane', '2021-12-09 11:54:43'),
(172, 1, 'CREATE PRODUCT', 'Added new item Widow', '2021-12-09 11:55:37'),
(173, 1, 'CREATE PRODUCT', 'Added new item Stacey', '2021-12-09 11:59:54'),
(174, 1, 'CREATE PRODUCT', 'Added new item Judy', '2021-12-09 12:08:03'),
(175, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 165', '2021-12-09 12:22:38'),
(176, 1, 'CHECKOUT', 'Processed Order. Order number: 21', '2021-12-09 12:23:57'),
(177, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 166', '2021-12-09 12:24:08'),
(178, 1, 'CREATE PRODUCT', 'Added new item Stella', '2021-12-09 15:25:04'),
(179, 1, 'CHECKOUT', 'Processed Order. Order number: 22', '2021-12-09 15:50:37'),
(180, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 167', '2021-12-09 15:50:47'),
(181, 1, 'CHECKOUT', 'Processed Order. Order number: 23', '2021-12-09 15:51:32'),
(182, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 168', '2021-12-09 15:51:41'),
(183, 1, 'CHECKOUT', 'Processed Order. Order number: 24', '2021-12-09 15:52:56'),
(184, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 169', '2021-12-09 15:53:05'),
(185, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 170', '2021-12-09 15:54:42'),
(186, 1, 'CREATE PRODUCT', 'Added new item Stella', '2021-12-09 16:07:32'),
(187, 1, 'CHECKOUT', 'Processed Order. Order number: 25', '2021-11-09 16:14:26'),
(188, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 171', '2021-11-09 16:14:39'),
(189, 1, 'CHECKOUT', 'Processed Order. Order number: 26', '2021-10-09 16:15:55'),
(190, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 172', '2021-10-09 16:16:06'),
(191, 1, 'CHECKOUT', 'Processed Order. Order number: 27', '2021-10-16 16:17:06'),
(192, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 173', '2021-10-16 16:17:12'),
(193, 1, 'CHECKOUT', 'Processed Order. Order number: 28', '2021-12-09 16:34:54'),
(194, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 174', '2021-12-09 16:35:42'),
(195, 1, 'CREATE PRODUCT', 'Added new item Stella', '2021-12-09 17:48:28'),
(196, 1, 'CHECKOUT', 'Processed Order. Order number: 29', '2021-12-09 17:50:01'),
(197, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 175', '2021-12-09 17:50:31'),
(198, 17, 'CHECKOUT', 'Processed Order. Order number: 30', '2021-12-09 17:56:22'),
(199, 1, 'CHECKOUT', 'Processed Order. Order number: 31', '2021-12-17 22:48:00'),
(200, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 176', '2021-12-17 23:01:29'),
(201, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 177', '2021-12-17 23:02:23'),
(202, 1, 'CHECKOUT', 'Processed Order. Order number: 32', '2021-12-17 23:02:37'),
(203, 1, 'CHECKOUT', 'Performed checkout. Transaction number: 178', '2021-12-17 23:02:50');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_id` int(11) NOT NULL,
  `cat_name` varchar(30) NOT NULL,
  `cat_status` int(11) DEFAULT NULL,
  `encodedby` int(11) DEFAULT NULL,
  `dateencoded` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_name`, `cat_status`, `encodedby`, `dateencoded`) VALUES
(1, 'Dress', 1, 1, '2021-07-14 20:34:38'),
(5, 'Skirt', 1, 1, '2021-07-14 20:55:16'),
(6, 'Jacket', 1, 1, '2021-07-14 20:55:29'),
(7, 'Crop Top', 1, 1, '2021-07-15 10:57:07'),
(8, 'Knitted tops', 1, 1, '2021-07-15 10:57:17');

-- --------------------------------------------------------

--
-- Table structure for table `color`
--

CREATE TABLE `color` (
  `color_id` int(11) NOT NULL,
  `color` varchar(15) NOT NULL,
  `encodedby` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `color`
--

INSERT INTO `color` (`color_id`, `color`, `encodedby`, `datecreated`) VALUES
(1, 'red', 1, '2021-07-14 23:19:10'),
(2, 'green', 1, '2021-07-14 23:20:16'),
(3, 'blue', 1, '2021-07-14 23:20:21'),
(4, 'black', 1, '2021-07-15 11:33:24'),
(5, 'white', 1, '2021-07-15 11:33:30'),
(8, 'Yellow', 1, '2021-12-09 10:58:23'),
(9, 'Purple', 1, '2021-12-09 11:01:26'),
(10, 'pink', 1, '2021-12-09 11:58:55');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `firstname` varchar(20) DEFAULT NULL,
  `lastname` varchar(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `contactno` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `firstname`, `lastname`, `address`, `contactno`) VALUES
(1, 'Marie', ' Jose', 'BLK 1 LOT 2, ABC Village, Brgy. Poblacion, Muntinlupa City', '09876543210'),
(2, 'Park', ' Ydo', 'Dawson St. Villa Carolina 1, Brgy. Tunasan, Muntinlupa City', '09871234569'),
(8, 'Barreto', ' Vico', '231  Langka St. Ayala Alabang Village Alabang  Muntinlupa City 1772 121.046247 14.384636', '09274181345'),
(9, 'Smith', ' Tony', '155  San Enrique Ayala Alabang Village Alabang  Muntinlupa City 1772 121.010059 14.392468', '09175792345'),
(10, 'Uchino', ' Niva', '1105 Sonria Condo   Alabang  Muntinlupa City 1772 121.012673 14.390089', '09178271348'),
(11, 'Styles', ' Sherry', '103  Canlaon Ayala Alabang Village Alabang  Muntinlupa City 1722 121.015764 14.391237', '09988600412'),
(12, 'Kang ', 'Byung Woo', '852  Batangas East Ayala Alabang Village Alabang  Muntinlupa City 1772', '09304721687'),
(13, 'Alberto', ' Pacita', '212  Acacia  Ayala Alabang Village Alabang  Muntinlupa City 1772 121.016057 14.39112', '09654876565'),
(14, 'Pardo', ' Marilyn', '704  Acacia  Ayala Alabang Village Alabang  Muntinlupa City 1772 121.047964 14.417245', '09878565658'),
(15, 'Batongbacal', 'Marietta', '232  Cuenca Ayala Alabang Village Alabang  Muntinlupa City 1772 121.029284 14.401848', '09887845487'),
(16, 'Joyce', 'Berlin', '633  Taysan Ayala Alabang Village Alabang  Muntinlupa City 1772 121.015971 14.390019', '09563548754');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `emp_id` int(11) NOT NULL,
  `firstname` varchar(20) DEFAULT NULL,
  `lastname` varchar(20) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `contactno` varchar(20) DEFAULT NULL,
  `position_id` int(11) DEFAULT NULL,
  `datehired` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`emp_id`, `firstname`, `lastname`, `gender`, `email`, `contactno`, `position_id`, `datehired`) VALUES
(1, 'Dondie', 'Dela Cruz', 'M', NULL, '0987654321', NULL, NULL),
(2, 'Juana', 'Dela Cruz', 'F', NULL, '09871237654', NULL, NULL),
(6, 'Justine', 'Begasa', 'M', NULL, '09356484156', NULL, NULL),
(7, 'John rafael', 'Balolong', 'M', NULL, '09654876254', NULL, NULL),
(8, 'Maria anna', 'Balani', 'M', NULL, '09568743215', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `fabric`
--

CREATE TABLE `fabric` (
  `fabric_id` int(11) NOT NULL,
  `fabric` varchar(15) NOT NULL,
  `encodedby` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fabric`
--

INSERT INTO `fabric` (`fabric_id`, `fabric`, `encodedby`, `datecreated`) VALUES
(1, 'Cotton', 1, '2021-07-15 11:27:46'),
(2, 'Polyster', 1, '2021-07-15 11:31:31'),
(3, 'Chiffon', 1, '2021-07-15 11:31:36'),
(4, 'Lace', 1, '2021-07-15 11:31:45'),
(5, 'Linen', 1, '2021-07-15 11:31:50'),
(6, 'Creep', 1, '2021-07-15 11:32:00'),
(7, 'Chaliz', 1, '2021-07-15 11:32:08');

-- --------------------------------------------------------

--
-- Table structure for table `for_purchase`
--

CREATE TABLE `for_purchase` (
  `id` int(11) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `prod_name` varchar(50) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `prod_price` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `inventoryitems`
--

CREATE TABLE `inventoryitems` (
  `prod_id` int(11) DEFAULT NULL,
  `inv_action` varchar(20) DEFAULT NULL,
  `inv_itemqty` int(11) NOT NULL,
  `createdby` int(11) NOT NULL,
  `datacreated` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `inventoryitems`
--

INSERT INTO `inventoryitems` (`prod_id`, `inv_action`, `inv_itemqty`, `createdby`, `datacreated`) VALUES
(2, 'addstock', 10, 1, '2021-07-15 15:20:30'),
(2, 'checkout', 5, 1, '2021-07-15 15:20:59'),
(6, 'addstock', 20, 1, '2021-11-26 09:07:17'),
(1, 'addstock', 5, 1, '2021-11-26 09:07:21'),
(1, 'addstock', 10, 1, '2021-11-26 09:07:24'),
(3, 'addstock', 5, 1, '2021-11-26 09:07:28'),
(3, 'addstock', 5, 1, '2021-11-26 09:07:31'),
(2, 'checkout', 2, 1, '2021-11-26 14:34:33'),
(2, 'addstock', 2, 1, '2021-11-26 14:43:43'),
(2, 'checkout', 3, 1, '2021-12-02 12:31:07'),
(3, 'addstock', 15, 1, '2021-12-04 08:30:50'),
(6, 'addstock', 3, 1, '2021-12-08 18:03:32'),
(6, 'checkout', 2, 1, '2021-12-08 18:03:42'),
(6, 'checkout', 10, 1, '2021-12-09 10:33:22'),
(1, 'checkout', 11, 1, '2021-12-09 10:33:25'),
(1, 'addstock', 2, 1, '2021-12-09 10:33:29'),
(7, 'addstock', 200, 1, '2021-12-09 10:49:25'),
(8, 'addstock', 300, 1, '2021-12-09 10:55:21'),
(9, 'addstock', 19, 1, '2021-12-09 10:59:20'),
(10, 'addstock', 100, 1, '2021-12-09 11:02:39'),
(11, 'addstock', 200, 1, '2021-12-09 11:07:24'),
(13, 'addstock', 100, 1, '2021-12-09 11:55:51'),
(14, 'addstock', 100, 1, '2021-12-09 11:55:55'),
(20, 'addstock', 136, 1, '2021-12-09 11:55:59'),
(16, 'addstock', 135, 1, '2021-12-09 11:56:04'),
(16, 'addstock', 135, 1, '2021-12-09 11:56:04'),
(15, 'addstock', 138, 1, '2021-12-09 11:56:08'),
(19, 'addstock', 200, 1, '2021-12-09 11:56:11'),
(17, 'addstock', 49, 1, '2021-12-09 11:56:24'),
(19, 'checkout', 166, 1, '2021-12-09 11:56:33'),
(23, 'addstock', 200, 1, '2021-12-09 12:08:15'),
(10, 'checkout', 65, 1, '2021-12-09 12:10:13'),
(20, 'checkout', 60, 1, '2021-12-09 12:10:19'),
(20, 'checkout', 20, 1, '2021-12-09 12:10:23'),
(20, 'checkout', 20, 1, '2021-12-09 12:10:27'),
(23, 'checkout', 168, 1, '2021-12-09 12:10:34'),
(22, 'addstock', 135, 1, '2021-12-09 12:11:03'),
(12, 'addstock', 150, 1, '2021-12-09 12:11:12'),
(21, 'addstock', 200, 1, '2021-12-09 12:11:18'),
(24, 'addstock', 100, 1, '2021-12-09 15:25:36'),
(24, 'checkout', 60, 1, '2021-12-09 15:25:57'),
(25, 'addstock', 20, 1, '2021-12-09 16:07:54'),
(26, 'addstock', 60, 1, '2021-12-09 17:49:06'),
(26, 'checkout', 55, 1, '2021-12-17 22:49:11'),
(26, 'addstock', 50, 1, '2021-12-17 22:49:34');

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

CREATE TABLE `orderdetails` (
  `order_id` int(11) NOT NULL,
  `orderDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `prod_id` int(11) NOT NULL,
  `item` varchar(100) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(13,2) DEFAULT NULL,
  `totalPrice` decimal(13,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orderdetails`
--

INSERT INTO `orderdetails` (`order_id`, `orderDate`, `prod_id`, `item`, `quantity`, `price`, `totalPrice`) VALUES
(4, '2021-12-03 02:59:54', 3, 'Stacey', 2, '200.00', '400.00'),
(8, '2021-12-03 04:00:04', 3, 'Stacey', 2, '200.00', '400.00'),
(9, '2021-12-03 06:22:02', 1, 'Levis T-Shirt Red', 1, '250.00', '250.00'),
(9, '2021-12-03 06:22:02', 2, 'Levis Jagged Pants', 1, '450.00', '450.00'),
(9, '2021-12-03 06:22:02', 6, 'Levis Sando for Men', 1, '300.00', '300.00'),
(10, '2021-11-29 22:30:51', 3, 'Stacey', 5, '200.00', '1000.00'),
(10, '2021-11-29 22:30:51', 6, 'Levis Sando for Men', 5, '300.00', '1500.00'),
(11, '2021-12-03 23:59:43', 6, 'Levis Sando for Men', 1, '300.00', '300.00'),
(12, '2021-12-03 23:59:52', 1, 'Levis T-Shirt Red', 1, '250.00', '250.00'),
(13, '2021-12-03 23:59:58', 6, 'Levis Sando for Men', 2, '300.00', '600.00'),
(14, '2021-12-04 00:00:04', 1, 'Levis T-Shirt Red', 2, '250.00', '500.00'),
(16, '2021-12-06 02:37:24', 6, 'Levis Sando for Men', 1, '300.00', '300.00'),
(17, '2021-12-08 11:44:55', 3, 'Stacey', 15, '200.00', '3000.00'),
(20, '2021-12-09 03:43:14', 11, 'Loius', 10, '300.00', '3000.00'),
(21, '2021-12-09 04:23:57', 15, 'Lou', 1, '450.00', '450.00'),
(21, '2021-12-09 04:23:57', 20, 'Grane', 1, '250.00', '250.00'),
(22, '2021-12-09 07:50:37', 15, 'Lou', 3, '450.00', '1350.00'),
(23, '2021-12-09 07:51:32', 12, 'Veina', 3, '300.00', '900.00'),
(23, '2021-12-09 07:51:32', 19, 'Rame', 4, '250.00', '1000.00'),
(24, '2021-12-09 07:52:55', 12, 'Veina', 2, '300.00', '600.00'),
(24, '2021-12-09 07:52:55', 20, 'Grane', 1, '250.00', '250.00'),
(24, '2021-12-09 07:52:55', 21, 'Widow', 2, '250.00', '500.00'),
(25, '2021-11-09 08:14:26', 15, 'Lou', 2, '450.00', '900.00'),
(25, '2021-11-09 08:14:26', 17, 'Rose', 2, '250.00', '500.00'),
(26, '2021-10-09 08:15:54', 17, 'Rose', 1, '250.00', '250.00'),
(26, '2021-10-09 08:15:54', 19, 'Rame', 1, '250.00', '250.00'),
(27, '2021-10-16 08:17:06', 19, 'Rame', 5, '250.00', '1250.00'),
(27, '2021-10-16 08:17:06', 20, 'Grane', 4, '250.00', '1000.00'),
(28, '2021-12-09 08:34:54', 14, 'Bien', 2, '450.00', '900.00'),
(28, '2021-12-09 08:34:54', 15, 'Lou', 2, '450.00', '900.00'),
(29, '2021-12-09 09:50:01', 22, 'Stacey', 1, '400.00', '400.00'),
(29, '2021-12-09 09:50:01', 15, 'Lou', 1, '450.00', '450.00'),
(29, '2021-12-09 09:50:01', 26, 'Stella', 5, '400.00', '2000.00'),
(31, '2021-12-17 14:48:00', 23, 'Judy', 4, '400.00', '1600.00'),
(32, '2021-12-17 15:02:37', 26, 'Stella', 1, '400.00', '400.00'),
(32, '2021-12-17 15:02:37', 13, 'Angel', 1, '300.00', '300.00');

-- --------------------------------------------------------

--
-- Table structure for table `orderhistory`
--

CREATE TABLE `orderhistory` (
  `order_id` int(11) NOT NULL,
  `orderDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `customer_id` int(11) NOT NULL,
  `totalOrders` int(11) NOT NULL,
  `totalPrice` decimal(13,2) DEFAULT NULL,
  `order_status` varchar(15) DEFAULT NULL,
  `createdby` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orderhistory`
--

INSERT INTO `orderhistory` (`order_id`, `orderDate`, `customer_id`, `totalOrders`, `totalPrice`, `order_status`, `createdby`) VALUES
(4, '2021-12-03 02:59:54', 2, 2, '400.00', 'PAID', 'admin'),
(8, '2021-12-03 04:00:04', 1, 2, '400.00', 'PAID', 'admin'),
(9, '2021-12-03 06:22:02', 2, 3, '1000.00', 'PAID', 'admin'),
(10, '2021-11-29 22:30:51', 2, 10, '2500.00', 'PAID', 'admin'),
(11, '2021-12-03 23:59:43', 1, 1, '300.00', 'PAID', 'admin'),
(12, '2021-12-03 23:59:52', 2, 1, '250.00', 'PAID', 'admin'),
(13, '2021-12-03 23:59:58', 2, 2, '600.00', 'PAID', 'admin'),
(14, '2021-12-04 00:00:04', 1, 2, '500.00', 'PAID', 'admin'),
(16, '2021-12-06 02:37:24', 2, 1, '300.00', 'PAID', 'admin'),
(17, '2021-12-08 11:44:55', 1, 15, '3000.00', 'PAID', 'admin'),
(20, '2021-12-09 03:43:14', 1, 10, '3000.00', 'PAID', 'admin'),
(21, '2021-12-09 04:23:57', 1, 2, '700.00', 'PAID', 'admin'),
(22, '2021-12-09 07:50:37', 1, 3, '1350.00', 'PAID', 'admin'),
(23, '2021-12-09 07:51:32', 2, 7, '1900.00', 'PAID', 'admin'),
(24, '2021-12-09 07:52:55', 16, 5, '1350.00', 'PAID', 'admin'),
(25, '2021-11-09 08:14:26', 1, 4, '1400.00', 'PAID', 'admin'),
(26, '2021-10-09 08:15:54', 12, 2, '500.00', 'PAID', 'admin'),
(27, '2021-10-16 08:17:06', 11, 9, '2250.00', 'PAID', 'admin'),
(28, '2021-12-09 08:34:54', 1, 4, '1800.00', 'PAID', 'admin'),
(29, '2021-12-09 09:50:01', 9, 7, '2850.00', 'PAID', 'admin'),
(31, '2021-12-17 14:48:00', 11, 4, '1600.00', 'PAID', 'admin'),
(32, '2021-12-17 15:02:37', 1, 2, '700.00', 'PAID', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `itemcode` varchar(20) DEFAULT NULL,
  `prod_name` varchar(20) NOT NULL,
  `prod_cat` int(11) NOT NULL,
  `prod_size` int(11) DEFAULT NULL,
  `prod_color` int(11) DEFAULT NULL,
  `prod_fabric` int(11) DEFAULT NULL,
  `prod_price` varchar(50) DEFAULT NULL,
  `prod_sellingprice` varchar(50) DEFAULT NULL,
  `prod_image` varchar(100) DEFAULT NULL,
  `createdby` int(11) NOT NULL,
  `datecreated` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `itemcode`, `prod_name`, `prod_cat`, `prod_size`, `prod_color`, `prod_fabric`, `prod_price`, `prod_sellingprice`, `prod_image`, `createdby`, `datecreated`) VALUES
(7, '4001', 'Black Stripes', 8, 10, 4, 1, '400.00', '500.00', 'black-stripes.jpg', 1, '2021-12-09 10:48:30'),
(8, '4002', 'White Stripes', 8, 10, 5, 1, '400.00', '500.00', 'white-stripes.jpg', 1, '2021-12-09 10:54:43'),
(9, '4003', 'Yellow Stripes', 8, 10, 8, 1, '400.00', '500.00', 'Yellow Stripes.jpg', 1, '2021-12-09 10:59:00'),
(10, '4004', 'Purple Stripes', 8, 10, 9, 1, '400.00', '500.00', 'purple-stripes.jpg', 1, '2021-12-09 11:02:21'),
(11, '9723', 'Loius', 5, 10, 4, 1, '250.00', '300.00', 'Skirt black.jpg', 1, '2021-12-09 11:07:07'),
(12, '9724', 'Veina', 5, 10, 4, 1, '250.00', '300.00', 'Veina.jpg', 1, '2021-12-09 11:11:40'),
(13, '9725', 'Angel', 5, 10, 5, 1, '250.00', '300.00', 'angel.jpg', 1, '2021-12-09 11:13:20'),
(14, 'A403', 'Bien', 6, 10, 4, 1, '350.00', '450.00', 'Bien.jpg', 1, '2021-12-09 11:16:42'),
(15, 'A404', 'Lou', 6, 10, 8, 1, '350.00', '450.00', 'lou.jpg', 1, '2021-12-09 11:46:24'),
(16, 'A405', 'Kays', 6, 10, 5, 1, '350.00', '450.00', 'Kays.jpg', 1, '2021-12-09 11:50:05'),
(17, '138', 'Rose', 7, 10, 5, 1, '200.00', '250.00', 'Rose.jpg', 1, '2021-12-09 11:51:52'),
(19, '139', 'Rame', 7, 10, 9, 1, '200.00', '250.00', 'Rame.jpg', 1, '2021-12-09 11:53:30'),
(20, '137', 'Grane', 7, 10, 2, 1, '200.00', '250.00', 'Grane.jpg', 1, '2021-12-09 11:54:43'),
(21, '136', 'Widow', 7, 10, 4, 1, '200.00', '250.00', 'Widow.jpg', 1, '2021-12-09 11:55:37'),
(22, '3001', 'Stacey', 1, 10, 10, 1, '300.00', '400.00', 'stacey.jpg', 1, '2021-12-09 11:59:54'),
(23, '3002', 'Judy', 1, 10, 5, 1, '300.00', '400.00', 'judy.jpg', 1, '2021-12-09 12:08:03'),
(26, '3939', 'Stella', 1, 10, 2, 1, '350.00', '400.00', 'Stella.jpg', 1, '2021-12-09 17:48:28');

-- --------------------------------------------------------

--
-- Table structure for table `returns_table`
--

CREATE TABLE `returns_table` (
  `returns_id` int(11) NOT NULL,
  `transactionNo` int(11) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `remarks` varchar(50) DEFAULT NULL,
  `return_date` datetime DEFAULT current_timestamp(),
  `created_by` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `returns_table`
--

INSERT INTO `returns_table` (`returns_id`, `transactionNo`, `prod_id`, `quantity`, `remarks`, `return_date`, `created_by`) VALUES
(5, 166, 8, 1, 'Replacement Wrong Color', '2021-12-09 17:54:13', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `size`
--

CREATE TABLE `size` (
  `size_id` int(11) NOT NULL,
  `size` varchar(10) NOT NULL,
  `encodedby` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `size`
--

INSERT INTO `size` (`size_id`, `size`, `encodedby`, `datecreated`) VALUES
(1, 'S', 1, '2021-07-14 23:29:26'),
(2, 'M', 1, '2021-07-14 23:30:01'),
(3, 'L', 1, '2021-07-14 23:30:06'),
(4, 'XL', 1, '2021-07-15 11:33:05'),
(5, 'XXL', 1, '2021-07-15 11:33:09'),
(6, 'XXXL', 1, '2021-07-15 11:33:12'),
(10, 'Free size', 1, '2021-12-09 10:56:19');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `supplier_id` int(11) NOT NULL,
  `company_name` varchar(30) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `contactno` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`supplier_id`, `company_name`, `address`, `contactno`) VALUES
(1, 'ABC Merchandize', 'Poblacion, Muntinlupa', '8472479'),
(2, 'Golden Apparel Inc', 'Southbay, Sucat, Paranaque City', '62840027');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_items`
--

CREATE TABLE `supplier_items` (
  `supplier_id` int(11) NOT NULL,
  `prod_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `supplier_items`
--

INSERT INTO `supplier_items` (`supplier_id`, `prod_id`) VALUES
(1, 1),
(1, 3),
(2, 2),
(2, 6),
(1, 8),
(1, 9),
(1, 10),
(1, 7),
(2, 11),
(2, 12),
(2, 13),
(2, 14),
(2, 15),
(2, 16),
(2, 17),
(2, 19),
(2, 20),
(2, 21),
(1, 20);

-- --------------------------------------------------------

--
-- Table structure for table `transactiondetails`
--

CREATE TABLE `transactiondetails` (
  `transactionNo` int(11) NOT NULL,
  `transactionDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `prod_id` int(11) DEFAULT NULL,
  `item` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(12,2) DEFAULT NULL,
  `totalPrice` decimal(12,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transactiondetails`
--

INSERT INTO `transactiondetails` (`transactionNo`, `transactionDate`, `prod_id`, `item`, `quantity`, `price`, `totalPrice`) VALUES
(154, '2021-12-03 02:51:47', 1, 'Levis T-Shirt Red', 1, '250.00', '250.00'),
(154, '2021-12-03 02:51:47', 3, 'Stacey', 1, '200.00', '200.00'),
(155, '2021-12-03 03:01:22', 3, 'Stacey', 2, '200.00', '400.00'),
(156, '2021-12-03 04:00:14', 3, 'Stacey', 2, '200.00', '400.00'),
(157, '2021-11-29 22:30:57', 3, 'Stacey', 5, '200.00', '1000.00'),
(157, '2021-11-29 22:30:57', 6, 'Levis Sando for Men', 5, '300.00', '1500.00'),
(158, '2021-12-04 00:00:10', 6, 'Levis Sando for Men', 1, '300.00', '300.00'),
(159, '2021-12-04 00:00:23', 1, 'Levis T-Shirt Red', 1, '250.00', '250.00'),
(160, '2021-12-04 00:00:30', 6, 'Levis Sando for Men', 2, '300.00', '600.00'),
(161, '2021-12-04 00:00:38', 1, 'Levis T-Shirt Red', 2, '250.00', '500.00'),
(162, '2021-12-06 04:22:00', 6, 'Levis Sando for Men', 1, '300.00', '300.00'),
(163, '2021-12-08 11:46:18', 3, 'Stacey', 15, '200.00', '3000.00'),
(164, '2021-12-08 11:47:23', 1, 'Levis T-Shirt Red', 1, '250.00', '250.00'),
(164, '2021-12-08 11:47:23', 2, 'Levis Jagged Pants', 1, '450.00', '450.00'),
(164, '2021-12-08 11:47:23', 6, 'Levis Sando for Men', 1, '300.00', '300.00'),
(165, '2021-12-09 04:22:38', 11, 'Loius', 10, '300.00', '3000.00'),
(166, '2021-12-09 04:24:08', 15, 'Lou', 1, '450.00', '450.00'),
(166, '2021-12-09 04:24:08', 20, 'Grane', 1, '250.00', '250.00'),
(167, '2021-12-09 07:50:47', 15, 'Lou', 3, '450.00', '1350.00'),
(168, '2021-12-09 07:51:41', 12, 'Veina', 3, '300.00', '900.00'),
(168, '2021-12-09 07:51:41', 19, 'Rame', 4, '250.00', '1000.00'),
(169, '2021-12-09 07:53:05', 12, 'Veina', 2, '300.00', '600.00'),
(169, '2021-12-09 07:53:05', 20, 'Grane', 1, '250.00', '250.00'),
(169, '2021-12-09 07:53:05', 21, 'Widow', 2, '250.00', '500.00'),
(170, '2021-12-09 07:54:42', 12, 'Veina', 2, '300.00', '600.00'),
(170, '2021-12-09 07:54:42', 20, 'Grane', 1, '250.00', '250.00'),
(170, '2021-12-09 07:54:42', 21, 'Widow', 2, '250.00', '500.00'),
(171, '2021-11-09 08:14:39', 15, 'Lou', 2, '450.00', '900.00'),
(171, '2021-11-09 08:14:39', 17, 'Rose', 2, '250.00', '500.00'),
(172, '2021-10-09 08:16:06', 17, 'Rose', 1, '250.00', '250.00'),
(172, '2021-10-09 08:16:06', 19, 'Rame', 1, '250.00', '250.00'),
(173, '2021-10-16 08:17:12', 19, 'Rame', 5, '250.00', '1250.00'),
(173, '2021-10-16 08:17:12', 20, 'Grane', 4, '250.00', '1000.00'),
(174, '2021-12-09 08:35:42', 14, 'Bien', 2, '450.00', '900.00'),
(174, '2021-12-09 08:35:42', 15, 'Lou', 2, '450.00', '900.00'),
(175, '2021-12-09 09:50:31', 22, 'Stacey', 1, '400.00', '400.00'),
(175, '2021-12-09 09:50:31', 15, 'Lou', 1, '450.00', '450.00'),
(175, '2021-12-09 09:50:31', 26, 'Stella', 5, '400.00', '2000.00'),
(176, '2021-12-17 15:01:29', 23, 'Judy', 4, '400.00', '1600.00'),
(177, '2021-12-17 15:02:23', 23, 'Judy', 4, '400.00', '1600.00'),
(178, '2021-12-17 15:02:50', 26, 'Stella', 1, '400.00', '400.00'),
(178, '2021-12-17 15:02:50', 13, 'Angel', 1, '300.00', '300.00');

-- --------------------------------------------------------

--
-- Table structure for table `transactionhistory`
--

CREATE TABLE `transactionhistory` (
  `transactionNo` int(11) NOT NULL,
  `transactionDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `customer_id` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `itemsSold` int(11) NOT NULL,
  `payment_type` varchar(15) NOT NULL DEFAULT '',
  `totalPrice` decimal(12,2) DEFAULT NULL,
  `createdby` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transactionhistory`
--

INSERT INTO `transactionhistory` (`transactionNo`, `transactionDate`, `customer_id`, `order_id`, `itemsSold`, `payment_type`, `totalPrice`, `createdby`) VALUES
(165, '2021-12-09 04:22:38', 1, 20, 10, 'COD', '3000.00', 'admin'),
(166, '2021-12-09 04:24:08', 1, 21, 2, 'Credit Card', '700.00', 'admin'),
(167, '2021-12-09 07:50:47', 1, 22, 3, 'Credit Card', '1350.00', 'admin'),
(168, '2021-12-09 07:51:41', 2, 23, 7, 'COD', '1900.00', 'admin'),
(169, '2021-12-09 07:53:05', 16, 24, 5, 'Credit Card', '1350.00', 'admin'),
(170, '2021-12-09 07:54:42', 16, 24, 5, 'Credit Card', '1350.00', 'admin'),
(171, '2021-11-09 08:14:39', 1, 25, 4, 'Credit Card', '1400.00', 'admin'),
(172, '2021-10-09 08:16:06', 12, 26, 2, 'Credit Card', '500.00', 'admin'),
(173, '2021-10-16 08:17:12', 11, 27, 9, 'COD', '2250.00', 'admin'),
(174, '2021-12-09 08:35:42', 1, 28, 4, 'Credit Card', '1800.00', 'admin'),
(175, '2021-12-09 09:50:31', 9, 29, 7, 'Cash', '2850.00', 'admin'),
(176, '2021-12-17 15:01:29', 11, 31, 4, 'Cash', '1600.00', 'admin'),
(177, '2021-12-17 15:02:23', 11, 31, 4, 'Cash', '1600.00', 'admin'),
(178, '2021-12-17 15:02:50', 1, 32, 2, 'Cash', '700.00', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `userlogs`
--

CREATE TABLE `userlogs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `actionType` varchar(20) DEFAULT NULL,
  `actionDescription` varchar(50) DEFAULT NULL,
  `dateRecorded` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userlogs`
--

INSERT INTO `userlogs` (`id`, `user_id`, `actionType`, `actionDescription`, `dateRecorded`) VALUES
(1, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-07-14 19:26:55'),
(2, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-07-14 19:27:25'),
(3, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-07-14 19:28:00'),
(4, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-07-14 19:42:38'),
(5, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-07-14 19:51:36'),
(6, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-07-14 21:28:46'),
(7, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-07-14 21:36:59'),
(8, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-07-14 23:33:28'),
(9, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-07-15 06:03:24'),
(10, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-07-15 07:33:05'),
(11, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-07-15 07:33:08'),
(12, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-07-15 11:04:45'),
(13, 5, 'SYSTEM ACCESS', 'Logged in to the system', '2021-07-15 11:04:51'),
(14, 5, 'SYSTEM ACCESS', 'Logged out from the system', '2021-07-15 11:05:12'),
(15, 5, 'SYSTEM ACCESS', 'Logged in to the system', '2021-07-15 11:05:18'),
(16, 5, 'SYSTEM ACCESS', 'Logged out from the system', '2021-07-15 11:05:28'),
(17, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-07-15 11:05:47'),
(18, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-07-15 11:05:57'),
(19, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-07-15 11:06:08'),
(20, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-07-15 15:23:02'),
(21, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-07-15 15:23:06'),
(22, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-07-15 15:23:39'),
(23, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-07-15 15:23:42'),
(24, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-07-15 15:23:47'),
(25, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-10-01 07:11:48'),
(26, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-10-01 08:02:27'),
(27, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-10-01 08:02:30'),
(28, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-10-01 10:11:54'),
(29, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-10-01 10:12:13'),
(30, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-10-01 10:39:37'),
(31, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-10-28 06:50:50'),
(32, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-10-28 06:51:57'),
(33, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-10-28 06:54:18'),
(34, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-10-28 06:56:13'),
(35, 5, 'SYSTEM ACCESS', 'Logged in to the system', '2021-10-28 06:56:51'),
(36, 5, 'SYSTEM ACCESS', 'Logged out from the system', '2021-10-28 06:59:04'),
(37, 5, 'SYSTEM ACCESS', 'Logged in to the system', '2021-10-28 06:59:12'),
(38, 5, 'SYSTEM ACCESS', 'Logged out from the system', '2021-10-28 07:00:53'),
(39, 5, 'SYSTEM ACCESS', 'Logged in to the system', '2021-10-28 07:00:58'),
(40, 5, 'SYSTEM ACCESS', 'Logged out from the system', '2021-10-28 07:08:30'),
(41, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-10-28 07:08:34'),
(42, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-10-28 20:47:11'),
(43, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-10-29 07:44:56'),
(44, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-10-29 09:28:12'),
(45, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-10-29 09:36:24'),
(46, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-10-29 19:33:48'),
(47, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-11-26 04:43:52'),
(48, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-11-26 04:48:34'),
(49, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-11-26 05:45:40'),
(50, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-11-26 07:42:26'),
(51, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-11-26 09:47:07'),
(52, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-11-26 09:47:49'),
(53, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-11-26 09:48:21'),
(54, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-11-26 09:48:28'),
(55, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-11-26 09:48:40'),
(56, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-11-26 09:48:44'),
(57, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-11-26 10:56:13'),
(58, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-11-26 10:56:16'),
(59, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-11-26 14:33:55'),
(60, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-11-26 14:53:35'),
(61, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-11-29 13:54:42'),
(62, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-11-29 13:59:24'),
(63, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-11-29 13:59:27'),
(64, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-11-29 19:18:19'),
(65, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-01 09:16:46'),
(66, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-01 21:57:28'),
(67, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-02 04:57:12'),
(68, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-02 07:00:23'),
(69, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-02 07:00:27'),
(70, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-02 19:26:19'),
(71, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-03 05:09:11'),
(72, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-03 12:02:28'),
(73, 5, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-03 12:02:45'),
(74, 5, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-03 14:07:50'),
(75, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-03 14:07:53'),
(76, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-03 15:44:14'),
(77, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-03 15:44:17'),
(78, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-03 18:44:17'),
(79, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-03 18:44:23'),
(80, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-04 06:19:34'),
(81, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-04 08:35:17'),
(82, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-06 08:35:36'),
(83, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-06 09:18:54'),
(84, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-06 10:35:54'),
(85, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-06 10:58:18'),
(86, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-06 12:21:37'),
(87, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-06 13:00:11'),
(88, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-07 10:58:59'),
(89, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-07 10:59:43'),
(90, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-07 11:01:30'),
(91, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-07 11:01:36'),
(92, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-07 14:35:02'),
(93, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-07 18:45:10'),
(94, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-07 20:47:27'),
(95, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-07 22:52:02'),
(96, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-08 13:11:07'),
(97, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-08 16:44:48'),
(98, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-08 16:48:24'),
(99, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-08 18:34:51'),
(100, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-08 19:38:34'),
(101, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-08 19:46:43'),
(102, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-08 21:58:48'),
(103, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-08 22:14:38'),
(104, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-08 22:20:48'),
(105, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-08 22:20:54'),
(106, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-08 22:48:30'),
(107, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-08 22:50:59'),
(108, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-08 22:51:06'),
(109, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-08 22:51:42'),
(110, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-09 10:10:52'),
(111, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-09 14:27:43'),
(112, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-09 15:16:30'),
(113, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-09 15:22:34'),
(114, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-09 15:35:31'),
(115, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-09 16:11:14'),
(116, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-11-09 16:14:04'),
(117, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-10-09 16:15:39'),
(118, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-10-09 16:15:42'),
(119, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-09 16:18:02'),
(120, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-09 16:18:06'),
(121, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-09 16:19:18'),
(122, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-09 16:19:42'),
(123, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-09 16:26:36'),
(124, 14, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-09 16:26:40'),
(125, 14, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-09 16:34:19'),
(126, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-09 16:34:22'),
(127, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-09 17:36:32'),
(128, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-09 17:38:13'),
(129, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-09 17:44:41'),
(130, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-09 17:45:09'),
(131, 1, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-09 17:54:57'),
(132, 17, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-09 17:55:27'),
(133, 17, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-09 17:57:08'),
(134, 17, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-09 18:04:11'),
(135, 17, 'SYSTEM ACCESS', 'Logged out from the system', '2021-12-09 18:47:35'),
(136, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-09 18:47:38'),
(137, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-12 17:48:02'),
(138, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-13 15:30:06'),
(139, 1, 'SYSTEM ACCESS', 'Logged in to the system', '2021-12-17 22:45:59');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `User_id` int(11) NOT NULL,
  `LastName` varchar(20) NOT NULL,
  `FirstName` varchar(20) NOT NULL,
  `contactno` varchar(15) DEFAULT NULL,
  `position` varchar(25) DEFAULT NULL,
  `User_Name` varchar(15) NOT NULL,
  `User_Pass` varchar(15) NOT NULL,
  `User_Level` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT current_timestamp(),
  `User_Status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`User_id`, `LastName`, `FirstName`, `contactno`, `position`, `User_Name`, `User_Pass`, `User_Level`, `date_created`, `User_Status`) VALUES
(1, 'Administrator', 'System', '09998765431', 'Administrator', 'admin', 'admin', 1, '2021-07-14 09:07:38', 1),
(2, 'Account 1', 'User', '09876543210', 'Staff', 'user1', '1234', 2, '2021-07-14 09:31:53', 0),
(5, 'Dela Cruz', 'Dondie', '9871234567', 'Administrator', 'ddelacruz', '1234', 1, '2021-07-14 15:43:58', 1),
(13, 'Balani', 'Maria Anna', '9654875632', 'Staff', 'maria45', '1234', 2, '2021-12-09 14:01:47', 1),
(14, 'Neypes', 'Ehla', '9654523154', 'Staff', 'ehla23', '1234', 2, '2021-12-09 14:03:10', 1),
(15, 'Begasa', 'Justine', '9547863254', 'Staff', 'justine45', '1234', 2, '2021-12-09 14:03:49', 1),
(16, 'Marcial', 'Rhed', '9654876542', 'Administrator', 'rhedzxc', '1234', 1, '2021-12-09 14:04:53', 1),
(17, 'Del Rosario', 'Leandro', '9845565487', 'Staff', 'leandrobigs', 'bigsbigs', 2, '2021-12-09 17:52:49', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auditlogs`
--
ALTER TABLE `auditlogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `color`
--
ALTER TABLE `color`
  ADD PRIMARY KEY (`color_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `fabric`
--
ALTER TABLE `fabric`
  ADD PRIMARY KEY (`fabric_id`);

--
-- Indexes for table `for_purchase`
--
ALTER TABLE `for_purchase`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderhistory`
--
ALTER TABLE `orderhistory`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `itemcode` (`itemcode`);

--
-- Indexes for table `returns_table`
--
ALTER TABLE `returns_table`
  ADD PRIMARY KEY (`returns_id`);

--
-- Indexes for table `size`
--
ALTER TABLE `size`
  ADD PRIMARY KEY (`size_id`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`supplier_id`);

--
-- Indexes for table `transactionhistory`
--
ALTER TABLE `transactionhistory`
  ADD PRIMARY KEY (`transactionNo`);

--
-- Indexes for table `userlogs`
--
ALTER TABLE `userlogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`User_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auditlogs`
--
ALTER TABLE `auditlogs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=204;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `color`
--
ALTER TABLE `color`
  MODIFY `color_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `emp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `fabric`
--
ALTER TABLE `fabric`
  MODIFY `fabric_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `for_purchase`
--
ALTER TABLE `for_purchase`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=286;

--
-- AUTO_INCREMENT for table `orderhistory`
--
ALTER TABLE `orderhistory`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `returns_table`
--
ALTER TABLE `returns_table`
  MODIFY `returns_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `size`
--
ALTER TABLE `size`
  MODIFY `size_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `supplier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `transactionhistory`
--
ALTER TABLE `transactionhistory`
  MODIFY `transactionNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=179;

--
-- AUTO_INCREMENT for table `userlogs`
--
ALTER TABLE `userlogs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `User_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
