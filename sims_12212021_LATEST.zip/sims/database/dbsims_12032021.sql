-- MariaDB dump 10.19  Distrib 10.4.19-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: db_sims
-- ------------------------------------------------------
-- Server version	10.4.19-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auditlogs`
--

DROP TABLE IF EXISTS `auditlogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auditlogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_action` varchar(15) DEFAULT NULL,
  `actiondescription` varchar(100) NOT NULL DEFAULT '',
  `datecreated` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditlogs`
--

LOCK TABLES `auditlogs` WRITE;
/*!40000 ALTER TABLE `auditlogs` DISABLE KEYS */;
INSERT INTO `auditlogs` VALUES (1,1,'CREATE PRODUCT','Added new item Levis Jagged Pants','2021-07-15 09:59:51'),(2,1,'UPDATE PRODUCT','updated item Levis Jagged Pants','2021-07-15 10:00:17'),(3,1,'CREATE PRODUCT','Added new item Stacey','2021-07-15 13:22:59'),(4,1,'UPDATE PRODUCT','updated item Levis Jagged Pants','2021-07-15 13:28:56'),(5,1,'UPDATE PRODUCT','updated item Levis T-Shirt Red','2021-07-15 13:29:32'),(8,1,'CREATE PRODUCT','Added new item Levis Sando for Men','2021-10-29 19:19:33'),(9,1,'UPDATE PRODUCT','updated item Levis Sando for Men','2021-10-29 19:22:34'),(10,1,'CHECKOUT','Performed checkout. Transaction number: 38','2021-10-29 19:29:49'),(17,1,'CHECKOUT','Performed checkout. Transaction number: 45','2021-11-26 10:53:35'),(18,1,'CHECKOUT','Performed checkout. Transaction number: 46','2021-11-26 10:54:40'),(19,1,'CHECKOUT','Performed checkout. Transaction number: 47','2021-11-26 11:05:46'),(20,1,'CHECKOUT','Performed checkout. Transaction number: 48','2021-11-26 11:14:37'),(21,1,'CHECKOUT','Performed checkout. Transaction number: 49','2021-11-26 14:50:02'),(22,1,'CHECKOUT','Performed checkout. Transaction number: 50','2021-11-29 19:17:27'),(23,1,'CHECKOUT','Performed checkout. Transaction number: 51','2021-12-01 09:26:54'),(24,1,'CHECKOUT','Performed checkout. Transaction number: 52','2021-12-01 09:30:30'),(25,1,'CHECKOUT','Performed checkout. Transaction number: 53','2021-12-01 09:31:17'),(26,1,'CHECKOUT','Performed checkout. Transaction number: 54','2021-12-01 09:32:41'),(27,1,'CHECKOUT','Performed checkout. Transaction number: 55','2021-12-01 09:51:49'),(28,1,'CHECKOUT','Performed checkout. Transaction number: 56','2021-12-01 09:52:27'),(29,1,'CHECKOUT','Performed checkout. Transaction number: 57','2021-12-01 09:58:07'),(30,1,'CHECKOUT','Performed checkout. Transaction number: 58','2021-12-02 05:06:14'),(31,1,'CHECKOUT','Performed checkout. Transaction number: 59','2021-12-02 05:06:43'),(32,1,'CHECKOUT','Performed checkout. Transaction number: 60','2021-12-02 05:12:43'),(33,1,'CHECKOUT','Performed checkout. Transaction number: 61','2021-12-02 05:13:01'),(34,1,'CHECKOUT','Performed checkout. Transaction number: 62','2021-12-02 05:14:19'),(35,1,'CHECKOUT','Performed checkout. Transaction number: 63','2021-12-02 06:43:03'),(36,1,'CHECKOUT','Performed checkout. Transaction number: 69','2021-12-02 07:25:52'),(37,1,'CHECKOUT','Performed checkout. Transaction number: 70','2021-12-02 07:26:38'),(38,1,'CHECKOUT','Performed checkout. Transaction number: 71','2021-12-02 07:27:58'),(39,1,'CHECKOUT','Performed checkout. Transaction number: 72','2021-12-02 07:31:02'),(40,1,'CHECKOUT','Performed checkout. Transaction number: 73','2021-12-02 07:33:41'),(41,1,'CHECKOUT','Performed checkout. Transaction number: 74','2021-12-02 07:34:49'),(42,1,'CHECKOUT','Performed checkout. Transaction number: 75','2021-12-02 07:35:27'),(43,1,'CHECKOUT','Performed checkout. Transaction number: 76','2021-12-02 07:35:59'),(44,1,'CHECKOUT','Performed checkout. Transaction number: 77','2021-12-02 07:37:21'),(45,1,'CHECKOUT','Performed checkout. Transaction number: 78','2021-12-02 07:38:52'),(46,1,'CHECKOUT','Performed checkout. Transaction number: 79','2021-12-02 07:46:05'),(47,1,'CHECKOUT','Performed checkout. Transaction number: 80','2021-12-02 07:48:50'),(48,1,'CHECKOUT','Performed checkout. Transaction number: 81','2021-12-02 07:48:59'),(49,1,'CHECKOUT','Performed checkout. Transaction number: 82','2021-12-02 07:50:12'),(50,1,'CHECKOUT','Performed checkout. Transaction number: 83','2021-12-02 07:50:43'),(51,1,'CHECKOUT','Performed checkout. Transaction number: 84','2021-12-02 07:52:17'),(52,1,'CHECKOUT','Performed checkout. Transaction number: 85','2021-12-02 07:54:54'),(53,1,'CHECKOUT','Performed checkout. Transaction number: 86','2021-12-02 07:56:39'),(54,1,'CHECKOUT','Performed checkout. Transaction number: 87','2021-12-02 07:57:40'),(55,1,'CHECKOUT','Performed checkout. Transaction number: 88','2021-12-02 08:06:17'),(56,1,'CHECKOUT','Performed checkout. Transaction number: 89','2021-12-02 08:07:04'),(57,1,'CHECKOUT','Performed checkout. Transaction number: 90','2021-12-02 08:08:17'),(58,1,'CHECKOUT','Performed checkout. Transaction number: 91','2021-12-02 08:08:42'),(59,1,'CHECKOUT','Performed checkout. Transaction number: 92','2021-12-02 08:09:37'),(60,1,'CHECKOUT','Performed checkout. Transaction number: 93','2021-12-02 08:10:51'),(61,1,'CHECKOUT','Performed checkout. Transaction number: 94','2021-12-02 08:12:12'),(62,1,'CHECKOUT','Performed checkout. Transaction number: 95','2021-12-02 08:13:07'),(63,1,'CHECKOUT','Performed checkout. Transaction number: 96','2021-12-02 08:15:05'),(64,1,'CHECKOUT','Performed checkout. Transaction number: 97','2021-12-02 08:16:14'),(65,1,'CHECKOUT','Performed checkout. Transaction number: 98','2021-12-02 08:17:33'),(66,1,'CHECKOUT','Performed checkout. Transaction number: 99','2021-12-02 08:18:17'),(67,1,'CHECKOUT','Performed checkout. Transaction number: 100','2021-12-02 08:18:34'),(68,1,'CHECKOUT','Performed checkout. Transaction number: 101','2021-12-02 08:20:04'),(69,1,'CHECKOUT','Performed checkout. Transaction number: 102','2021-12-02 09:44:20'),(70,1,'CHECKOUT','Performed checkout. Transaction number: 103','2021-12-02 12:25:37'),(71,1,'CHECKOUT','Performed checkout. Transaction number: 104','2021-12-02 17:25:18'),(72,1,'CHECKOUT','Performed checkout. Transaction number: 105','2021-12-02 17:26:31'),(73,1,'CHECKOUT','Performed checkout. Transaction number: 106','2021-12-02 17:28:21'),(74,1,'CHECKOUT','Performed checkout. Transaction number: 107','2021-12-02 17:31:02'),(75,1,'CHECKOUT','Performed checkout. Transaction number: 108','2021-12-02 17:33:13'),(76,1,'CHECKOUT','Performed checkout. Transaction number: 109','2021-12-02 17:37:38'),(77,1,'CHECKOUT','Performed checkout. Transaction number: 110','2021-12-02 17:38:27'),(78,1,'CHECKOUT','Performed checkout. Transaction number: 111','2021-12-02 17:39:32'),(79,1,'CHECKOUT','Performed checkout. Transaction number: 112','2021-12-02 17:40:15'),(80,1,'CHECKOUT','Performed checkout. Transaction number: 113','2021-12-02 17:40:42'),(81,1,'CHECKOUT','Performed checkout. Transaction number: 114','2021-12-02 17:42:31'),(82,1,'CHECKOUT','Performed checkout. Transaction number: 115','2021-12-02 17:45:59'),(83,1,'CHECKOUT','Performed checkout. Transaction number: 116','2021-12-02 17:46:34'),(84,1,'CHECKOUT','Performed checkout. Transaction number: 117','2021-12-02 17:46:56'),(85,1,'CHECKOUT','Performed checkout. Transaction number: 118','2021-12-02 17:48:43'),(86,1,'CHECKOUT','Performed checkout. Transaction number: 119','2021-12-02 17:51:54'),(87,1,'CHECKOUT','Performed checkout. Transaction number: 120','2021-12-02 17:53:54'),(88,1,'CHECKOUT','Performed checkout. Transaction number: 121','2021-12-02 17:56:46'),(89,1,'CHECKOUT','Performed checkout. Transaction number: 122','2021-12-02 17:57:57'),(90,1,'CHECKOUT','Performed checkout. Transaction number: 123','2021-12-02 17:59:30'),(91,1,'CHECKOUT','Performed checkout. Transaction number: 124','2021-12-02 18:02:21'),(92,1,'CHECKOUT','Performed checkout. Transaction number: 125','2021-12-02 18:05:08'),(93,1,'CHECKOUT','Performed checkout. Transaction number: 126','2021-12-02 18:05:31'),(94,1,'CHECKOUT','Performed checkout. Transaction number: 127','2021-12-02 18:07:06'),(95,1,'CHECKOUT','Performed checkout. Transaction number: 128','2021-12-02 18:07:43'),(96,1,'CHECKOUT','Performed checkout. Transaction number: 129','2021-12-02 18:19:54'),(97,1,'CHECKOUT','Performed checkout. Transaction number: 130','2021-12-02 18:20:32'),(98,1,'CHECKOUT','Performed checkout. Transaction number: 131','2021-12-02 18:22:59'),(99,1,'CHECKOUT','Performed checkout. Transaction number: 132','2021-12-02 18:23:40'),(100,1,'CHECKOUT','Performed checkout. Transaction number: 133','2021-12-02 18:24:45'),(101,1,'CHECKOUT','Performed checkout. Transaction number: 134','2021-12-02 18:26:33'),(102,1,'CHECKOUT','Performed checkout. Transaction number: 135','2021-12-02 18:27:40'),(103,1,'CHECKOUT','Performed checkout. Transaction number: 136','2021-12-02 18:28:09'),(104,1,'CHECKOUT','Performed checkout. Transaction number: 137','2021-12-02 18:30:40'),(105,1,'CHECKOUT','Performed checkout. Transaction number: 138','2021-12-02 18:31:36'),(106,1,'CHECKOUT','Performed checkout. Transaction number: 139','2021-12-02 18:33:39'),(107,1,'CHECKOUT','Performed checkout. Transaction number: 140','2021-12-02 18:35:16'),(108,1,'CHECKOUT','Performed checkout. Transaction number: 141','2021-12-02 18:35:40'),(109,1,'CHECKOUT','Performed checkout. Transaction number: 142','2021-12-02 18:35:47'),(110,1,'CHECKOUT','Performed checkout. Transaction number: 143','2021-12-02 18:36:14'),(111,1,'CHECKOUT','Performed checkout. Transaction number: 144','2021-12-02 18:37:43'),(112,1,'CHECKOUT','Performed checkout. Transaction number: 145','2021-12-02 18:39:59'),(113,1,'CHECKOUT','Performed checkout. Transaction number: 146','2021-12-02 18:41:37'),(114,1,'CHECKOUT','Performed checkout. Transaction number: 147','2021-12-02 18:42:12'),(115,1,'CHECKOUT','Performed checkout. Transaction number: 148','2021-12-02 18:42:52'),(116,1,'CHECKOUT','Performed checkout. Transaction number: 149','2021-12-02 18:50:23'),(117,1,'CHECKOUT','Processed Order. Order number: 1','2021-12-03 07:26:33'),(118,1,'CHECKOUT','Processed Order. Order number: 2','2021-12-03 07:35:23'),(119,1,'CHECKOUT','Performed checkout. Transaction number: 151','2021-12-03 10:48:21'),(120,1,'CHECKOUT','Performed checkout. Transaction number: 152','2021-12-03 10:49:40'),(121,1,'CHECKOUT','Performed checkout. Transaction number: 153','2021-12-03 10:50:29'),(122,1,'CHECKOUT','Performed checkout. Transaction number: 154','2021-12-03 10:51:47'),(123,1,'CHECKOUT','Processed Order. Order number: 3','2021-12-03 10:59:33'),(124,1,'CHECKOUT','Processed Order. Order number: 4','2021-12-03 10:59:54'),(125,1,'CHECKOUT','Performed checkout. Transaction number: 155','2021-12-03 11:01:22'),(126,1,'CHECKOUT','Processed Order. Order number: 5','2021-12-03 11:47:51'),(127,1,'CHECKOUT','Processed Order. Order number: 6','2021-12-03 11:50:10'),(128,1,'CHECKOUT','Processed Order. Order number: 7','2021-12-03 11:50:29'),(129,1,'CHECKOUT','Processed Order. Order number: 8','2021-12-03 12:00:04'),(130,1,'CHECKOUT','Performed checkout. Transaction number: 156','2021-12-03 12:00:14'),(131,5,'UPDATE PRODUCT','updated item Levis Sando for Men','2021-12-03 14:07:31'),(132,5,'UPDATE PRODUCT','updated item Levis Sando for Men','2021-12-03 14:07:39'),(133,1,'CHECKOUT','Processed Order. Order number: 9','2021-12-03 14:22:02');
/*!40000 ALTER TABLE `auditlogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(30) NOT NULL,
  `cat_status` int(11) DEFAULT NULL,
  `encodedby` int(11) DEFAULT NULL,
  `dateencoded` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Dress',1,1,'2021-07-14 20:34:38'),(3,'Rommper',1,1,'2021-07-14 20:54:45'),(4,'Maxi Dress',1,1,'2021-07-14 20:55:08'),(5,'Midi Dress',1,1,'2021-07-14 20:55:16'),(6,'Jumpsuit',1,1,'2021-07-14 20:55:29'),(7,'Mini Dress',1,1,'2021-07-15 10:57:07'),(8,'Nitted',1,1,'2021-07-15 10:57:17'),(9,'Traditional',0,1,'2021-07-15 10:59:22');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `color`
--

DROP TABLE IF EXISTS `color`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `color` (
  `color_id` int(11) NOT NULL AUTO_INCREMENT,
  `color` varchar(15) NOT NULL,
  `encodedby` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`color_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `color`
--

LOCK TABLES `color` WRITE;
/*!40000 ALTER TABLE `color` DISABLE KEYS */;
INSERT INTO `color` VALUES (1,'red',1,'2021-07-14 23:19:10'),(2,'green',1,'2021-07-14 23:20:16'),(3,'blue',1,'2021-07-14 23:20:21'),(4,'black',1,'2021-07-15 11:33:24'),(5,'white',1,'2021-07-15 11:33:30');
/*!40000 ALTER TABLE `color` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(20) DEFAULT NULL,
  `lastname` varchar(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `contactno` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'Dondie','Dela Cruz','BLK 1 LOT 2, ABC Village, Brgy. Poblacion, Muntinlupa City','09876543210'),(2,'John','Doe','Dawson St., Villa Carolina 1, Brgy.Tunasan, Muntinlupa City','09551234567');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee` (
  `emp_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(20) DEFAULT NULL,
  `lastname` varchar(20) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `contactno` varchar(20) DEFAULT NULL,
  `position_id` int(11) DEFAULT NULL,
  `datehired` datetime DEFAULT NULL,
  PRIMARY KEY (`emp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (1,'Dondie','Dela Cruz','M',NULL,'0987654321',NULL,NULL);
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fabric`
--

DROP TABLE IF EXISTS `fabric`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fabric` (
  `fabric_id` int(11) NOT NULL AUTO_INCREMENT,
  `fabric` varchar(15) NOT NULL,
  `encodedby` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`fabric_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fabric`
--

LOCK TABLES `fabric` WRITE;
/*!40000 ALTER TABLE `fabric` DISABLE KEYS */;
INSERT INTO `fabric` VALUES (1,'Cotton',1,'2021-07-15 11:27:46'),(2,'Polyster',1,'2021-07-15 11:31:31'),(3,'Chiffon',1,'2021-07-15 11:31:36'),(4,'Lace',1,'2021-07-15 11:31:45'),(5,'Linen',1,'2021-07-15 11:31:50'),(6,'Creep',1,'2021-07-15 11:32:00'),(7,'Chaliz',1,'2021-07-15 11:32:08');
/*!40000 ALTER TABLE `fabric` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `for_purchase`
--

DROP TABLE IF EXISTS `for_purchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `for_purchase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prod_id` int(11) NOT NULL,
  `prod_name` varchar(50) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `prod_price` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=236 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `for_purchase`
--

LOCK TABLES `for_purchase` WRITE;
/*!40000 ALTER TABLE `for_purchase` DISABLE KEYS */;
/*!40000 ALTER TABLE `for_purchase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventoryitems`
--

DROP TABLE IF EXISTS `inventoryitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventoryitems` (
  `prod_id` int(11) DEFAULT NULL,
  `inv_action` varchar(20) DEFAULT NULL,
  `inv_itemqty` int(11) NOT NULL,
  `createdby` int(11) NOT NULL,
  `datacreated` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventoryitems`
--

LOCK TABLES `inventoryitems` WRITE;
/*!40000 ALTER TABLE `inventoryitems` DISABLE KEYS */;
INSERT INTO `inventoryitems` VALUES (2,'addstock',10,1,'2021-07-15 15:20:30'),(2,'checkout',5,1,'2021-07-15 15:20:59'),(6,'addstock',20,1,'2021-11-26 09:07:17'),(1,'addstock',5,1,'2021-11-26 09:07:21'),(1,'addstock',10,1,'2021-11-26 09:07:24'),(3,'addstock',5,1,'2021-11-26 09:07:28'),(3,'addstock',5,1,'2021-11-26 09:07:31'),(2,'checkout',2,1,'2021-11-26 14:34:33'),(2,'addstock',2,1,'2021-11-26 14:43:43'),(2,'checkout',3,1,'2021-12-02 12:31:07');
/*!40000 ALTER TABLE `inventoryitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orderdetails`
--

DROP TABLE IF EXISTS `orderdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orderdetails` (
  `order_id` int(11) NOT NULL,
  `orderDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `prod_id` int(11) NOT NULL,
  `item` varchar(100) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(13,2) DEFAULT NULL,
  `totalPrice` decimal(13,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderdetails`
--

LOCK TABLES `orderdetails` WRITE;
/*!40000 ALTER TABLE `orderdetails` DISABLE KEYS */;
INSERT INTO `orderdetails` VALUES (4,'2021-12-03 02:59:54',3,'Stacey',2,200.00,400.00),(8,'2021-12-03 04:00:04',3,'Stacey',2,200.00,400.00),(9,'2021-12-03 06:22:02',1,'Levis T-Shirt Red',1,250.00,250.00),(9,'2021-12-03 06:22:02',2,'Levis Jagged Pants',1,450.00,450.00),(9,'2021-12-03 06:22:02',6,'Levis Sando for Men',1,300.00,300.00);
/*!40000 ALTER TABLE `orderdetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orderhistory`
--

DROP TABLE IF EXISTS `orderhistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orderhistory` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `orderDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `customer_id` int(11) NOT NULL,
  `totalOrders` int(11) NOT NULL,
  `totalPrice` decimal(13,2) DEFAULT NULL,
  `order_status` varchar(15) DEFAULT NULL,
  `createdby` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderhistory`
--

LOCK TABLES `orderhistory` WRITE;
/*!40000 ALTER TABLE `orderhistory` DISABLE KEYS */;
INSERT INTO `orderhistory` VALUES (4,'2021-12-03 02:59:54',2,2,400.00,'PAID','admin'),(8,'2021-12-03 04:00:04',1,2,400.00,'PAID','admin'),(9,'2021-12-03 06:22:02',2,3,1000.00,'FOR PAYMENT','admin');
/*!40000 ALTER TABLE `orderhistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemcode` varchar(20) DEFAULT NULL,
  `prod_name` varchar(20) NOT NULL,
  `prod_cat` int(11) NOT NULL,
  `prod_size` int(11) DEFAULT NULL,
  `prod_color` int(11) DEFAULT NULL,
  `prod_fabric` int(11) DEFAULT NULL,
  `prod_price` varchar(50) DEFAULT NULL,
  `prod_sellingprice` varchar(50) DEFAULT NULL,
  `prod_image` varchar(100) DEFAULT NULL,
  `createdby` int(11) NOT NULL,
  `datecreated` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `itemcode` (`itemcode`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'T001','Levis T-Shirt Red',1,2,1,5,'200.00','250.00','levis_tshirt_red_men.jpg',1,'2021-07-15 08:57:30'),(2,'P001','Levis Jagged Pants',1,1,3,2,'400.00','450.00','levis_jaggedpants.jpg',1,'2021-07-15 09:59:51'),(3,'ST001','Stacey',3,1,1,1,'180.00','200.00','stacey_romper.jpg',1,'2021-07-15 13:22:59'),(6,'TS002','Levis Sando for Men',1,2,1,1,' 275.00','300.00','levis_sando_red.jpg',1,'2021-10-29 19:19:33');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `size`
--

DROP TABLE IF EXISTS `size`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `size` (
  `size_id` int(11) NOT NULL AUTO_INCREMENT,
  `size` varchar(10) NOT NULL,
  `encodedby` int(11) DEFAULT NULL,
  `datecreated` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`size_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `size`
--

LOCK TABLES `size` WRITE;
/*!40000 ALTER TABLE `size` DISABLE KEYS */;
INSERT INTO `size` VALUES (1,'S',1,'2021-07-14 23:29:26'),(2,'M',1,'2021-07-14 23:30:01'),(3,'L',1,'2021-07-14 23:30:06'),(4,'XL',1,'2021-07-15 11:33:05'),(5,'XXL',1,'2021-07-15 11:33:09'),(6,'XXXL',1,'2021-07-15 11:33:12');
/*!40000 ALTER TABLE `size` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier` (
  `supplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(30) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `contactno` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
INSERT INTO `supplier` VALUES (1,'ABC Merchandize','Poblacion, Muntinlupa','8472477');
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactiondetails`
--

DROP TABLE IF EXISTS `transactiondetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactiondetails` (
  `transactionNo` int(11) NOT NULL,
  `transactionDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `prod_id` int(11) DEFAULT NULL,
  `item` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(12,2) DEFAULT NULL,
  `totalPrice` decimal(12,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactiondetails`
--

LOCK TABLES `transactiondetails` WRITE;
/*!40000 ALTER TABLE `transactiondetails` DISABLE KEYS */;
INSERT INTO `transactiondetails` VALUES (154,'2021-12-03 02:51:47',1,'Levis T-Shirt Red',1,250.00,250.00),(154,'2021-12-03 02:51:47',3,'Stacey',1,200.00,200.00),(155,'2021-12-03 03:01:22',3,'Stacey',2,200.00,400.00),(156,'2021-12-03 04:00:14',3,'Stacey',2,200.00,400.00);
/*!40000 ALTER TABLE `transactiondetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactionhistory`
--

DROP TABLE IF EXISTS `transactionhistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactionhistory` (
  `transactionNo` int(11) NOT NULL AUTO_INCREMENT,
  `transactionDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `customer_id` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `itemsSold` int(11) NOT NULL,
  `payment_type` varchar(15) NOT NULL DEFAULT '',
  `totalPrice` decimal(12,2) DEFAULT NULL,
  `createdby` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`transactionNo`)
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactionhistory`
--

LOCK TABLES `transactionhistory` WRITE;
/*!40000 ALTER TABLE `transactionhistory` DISABLE KEYS */;
INSERT INTO `transactionhistory` VALUES (154,'2021-12-03 02:51:47',2,2,2,'COD',450.00,'admin'),(155,'2021-12-03 03:01:22',2,4,2,'COD',400.00,'admin'),(156,'2021-12-03 04:00:14',1,8,2,'Credit Card',400.00,'admin');
/*!40000 ALTER TABLE `transactionhistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userlogs`
--

DROP TABLE IF EXISTS `userlogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userlogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `actionType` varchar(20) DEFAULT NULL,
  `actionDescription` varchar(50) DEFAULT NULL,
  `dateRecorded` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userlogs`
--

LOCK TABLES `userlogs` WRITE;
/*!40000 ALTER TABLE `userlogs` DISABLE KEYS */;
INSERT INTO `userlogs` VALUES (1,1,'SYSTEM ACCESS','Logged in to the system','2021-07-14 19:26:55'),(2,1,'SYSTEM ACCESS','Logged out from the system','2021-07-14 19:27:25'),(3,1,'SYSTEM ACCESS','Logged in to the system','2021-07-14 19:28:00'),(4,1,'SYSTEM ACCESS','Logged out from the system','2021-07-14 19:42:38'),(5,1,'SYSTEM ACCESS','Logged in to the system','2021-07-14 19:51:36'),(6,1,'SYSTEM ACCESS','Logged out from the system','2021-07-14 21:28:46'),(7,1,'SYSTEM ACCESS','Logged in to the system','2021-07-14 21:36:59'),(8,1,'SYSTEM ACCESS','Logged out from the system','2021-07-14 23:33:28'),(9,1,'SYSTEM ACCESS','Logged in to the system','2021-07-15 06:03:24'),(10,1,'SYSTEM ACCESS','Logged out from the system','2021-07-15 07:33:05'),(11,1,'SYSTEM ACCESS','Logged in to the system','2021-07-15 07:33:08'),(12,1,'SYSTEM ACCESS','Logged out from the system','2021-07-15 11:04:45'),(13,5,'SYSTEM ACCESS','Logged in to the system','2021-07-15 11:04:51'),(14,5,'SYSTEM ACCESS','Logged out from the system','2021-07-15 11:05:12'),(15,5,'SYSTEM ACCESS','Logged in to the system','2021-07-15 11:05:18'),(16,5,'SYSTEM ACCESS','Logged out from the system','2021-07-15 11:05:28'),(17,1,'SYSTEM ACCESS','Logged in to the system','2021-07-15 11:05:47'),(18,1,'SYSTEM ACCESS','Logged out from the system','2021-07-15 11:05:57'),(19,1,'SYSTEM ACCESS','Logged in to the system','2021-07-15 11:06:08'),(20,1,'SYSTEM ACCESS','Logged out from the system','2021-07-15 15:23:02'),(21,1,'SYSTEM ACCESS','Logged in to the system','2021-07-15 15:23:06'),(22,1,'SYSTEM ACCESS','Logged out from the system','2021-07-15 15:23:39'),(23,1,'SYSTEM ACCESS','Logged in to the system','2021-07-15 15:23:42'),(24,1,'SYSTEM ACCESS','Logged out from the system','2021-07-15 15:23:47'),(25,1,'SYSTEM ACCESS','Logged in to the system','2021-10-01 07:11:48'),(26,1,'SYSTEM ACCESS','Logged out from the system','2021-10-01 08:02:27'),(27,1,'SYSTEM ACCESS','Logged in to the system','2021-10-01 08:02:30'),(28,1,'SYSTEM ACCESS','Logged out from the system','2021-10-01 10:11:54'),(29,1,'SYSTEM ACCESS','Logged in to the system','2021-10-01 10:12:13'),(30,1,'SYSTEM ACCESS','Logged out from the system','2021-10-01 10:39:37'),(31,1,'SYSTEM ACCESS','Logged in to the system','2021-10-28 06:50:50'),(32,1,'SYSTEM ACCESS','Logged out from the system','2021-10-28 06:51:57'),(33,1,'SYSTEM ACCESS','Logged in to the system','2021-10-28 06:54:18'),(34,1,'SYSTEM ACCESS','Logged out from the system','2021-10-28 06:56:13'),(35,5,'SYSTEM ACCESS','Logged in to the system','2021-10-28 06:56:51'),(36,5,'SYSTEM ACCESS','Logged out from the system','2021-10-28 06:59:04'),(37,5,'SYSTEM ACCESS','Logged in to the system','2021-10-28 06:59:12'),(38,5,'SYSTEM ACCESS','Logged out from the system','2021-10-28 07:00:53'),(39,5,'SYSTEM ACCESS','Logged in to the system','2021-10-28 07:00:58'),(40,5,'SYSTEM ACCESS','Logged out from the system','2021-10-28 07:08:30'),(41,1,'SYSTEM ACCESS','Logged in to the system','2021-10-28 07:08:34'),(42,1,'SYSTEM ACCESS','Logged out from the system','2021-10-28 20:47:11'),(43,1,'SYSTEM ACCESS','Logged in to the system','2021-10-29 07:44:56'),(44,1,'SYSTEM ACCESS','Logged in to the system','2021-10-29 09:28:12'),(45,1,'SYSTEM ACCESS','Logged in to the system','2021-10-29 09:36:24'),(46,1,'SYSTEM ACCESS','Logged out from the system','2021-10-29 19:33:48'),(47,1,'SYSTEM ACCESS','Logged in to the system','2021-11-26 04:43:52'),(48,1,'SYSTEM ACCESS','Logged out from the system','2021-11-26 04:48:34'),(49,1,'SYSTEM ACCESS','Logged in to the system','2021-11-26 05:45:40'),(50,1,'SYSTEM ACCESS','Logged in to the system','2021-11-26 07:42:26'),(51,1,'SYSTEM ACCESS','Logged out from the system','2021-11-26 09:47:07'),(52,1,'SYSTEM ACCESS','Logged in to the system','2021-11-26 09:47:49'),(53,1,'SYSTEM ACCESS','Logged out from the system','2021-11-26 09:48:21'),(54,1,'SYSTEM ACCESS','Logged in to the system','2021-11-26 09:48:28'),(55,1,'SYSTEM ACCESS','Logged out from the system','2021-11-26 09:48:40'),(56,1,'SYSTEM ACCESS','Logged in to the system','2021-11-26 09:48:44'),(57,1,'SYSTEM ACCESS','Logged out from the system','2021-11-26 10:56:13'),(58,1,'SYSTEM ACCESS','Logged in to the system','2021-11-26 10:56:16'),(59,1,'SYSTEM ACCESS','Logged in to the system','2021-11-26 14:33:55'),(60,1,'SYSTEM ACCESS','Logged out from the system','2021-11-26 14:53:35'),(61,1,'SYSTEM ACCESS','Logged in to the system','2021-11-29 13:54:42'),(62,1,'SYSTEM ACCESS','Logged out from the system','2021-11-29 13:59:24'),(63,1,'SYSTEM ACCESS','Logged in to the system','2021-11-29 13:59:27'),(64,1,'SYSTEM ACCESS','Logged out from the system','2021-11-29 19:18:19'),(65,1,'SYSTEM ACCESS','Logged in to the system','2021-12-01 09:16:46'),(66,1,'SYSTEM ACCESS','Logged out from the system','2021-12-01 21:57:28'),(67,1,'SYSTEM ACCESS','Logged in to the system','2021-12-02 04:57:12'),(68,1,'SYSTEM ACCESS','Logged out from the system','2021-12-02 07:00:23'),(69,1,'SYSTEM ACCESS','Logged in to the system','2021-12-02 07:00:27'),(70,1,'SYSTEM ACCESS','Logged out from the system','2021-12-02 19:26:19'),(71,1,'SYSTEM ACCESS','Logged in to the system','2021-12-03 05:09:11'),(72,1,'SYSTEM ACCESS','Logged out from the system','2021-12-03 12:02:28'),(73,5,'SYSTEM ACCESS','Logged in to the system','2021-12-03 12:02:45'),(74,5,'SYSTEM ACCESS','Logged out from the system','2021-12-03 14:07:50'),(75,1,'SYSTEM ACCESS','Logged in to the system','2021-12-03 14:07:53'),(76,1,'SYSTEM ACCESS','Logged out from the system','2021-12-03 15:44:14'),(77,1,'SYSTEM ACCESS','Logged in to the system','2021-12-03 15:44:17'),(78,1,'SYSTEM ACCESS','Logged out from the system','2021-12-03 18:44:17'),(79,1,'SYSTEM ACCESS','Logged in to the system','2021-12-03 18:44:23');
/*!40000 ALTER TABLE `userlogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `User_id` int(11) NOT NULL AUTO_INCREMENT,
  `LastName` varchar(20) NOT NULL,
  `FirstName` varchar(20) NOT NULL,
  `contactno` varchar(15) DEFAULT NULL,
  `position` varchar(25) DEFAULT NULL,
  `User_Name` varchar(15) NOT NULL,
  `User_Pass` varchar(15) NOT NULL,
  `User_Level` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT current_timestamp(),
  `User_Status` int(11) DEFAULT NULL,
  PRIMARY KEY (`User_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Administrator','System','09998765431','Administrator','admin','admin',1,'2021-07-14 09:07:38',1),(2,'Account 1','User','09876543210','Staff','user1','1234',2,'2021-07-14 09:31:53',0),(5,'Dela Cruz','Dondie','9871234567','Manager','ddelacruz','1234',2,'2021-07-14 15:43:58',1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-03 22:26:44
