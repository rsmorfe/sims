<?php

    // FOR initial creation of Database
    define('DB_SERVER', 'localhost');
    define('DB_USERNAME', 'root');
    define('DB_PASSWORD', '');
    define('DB_NAME', ''); // this should be blank first



    // Database configuration
    $dbConn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);


    // FUNCTIONS
    function checkConnection($dbConnection) {
        // Check connection
        if($dbConnection === false){
            die("ERROR: Could not connect. " . mysqli_connect_error());
        } else {
            echo "<script> console.log('Connected'); </script>"; // for debugging only
        }
    }



    function executeQuery($type, $db, $query) {
        if($type == "database") { // when creating database
            if(mysqli_query($db, $query)){
                echo "<script> console.log('Database created'); </script>"; // for debugging only
            } else{
                die("ERROR: Could not able to execute $query. " . $db->error);
            }
        } elseif ($type == "table") { // when creating tables
            if(mysqli_query($db, $query)){
                echo "<script> console.log('Table successfully created'); </script>"; // for debugging only
            } else{
                die("ERROR: Could not able to execute $query. " . $db->error);
            }
        }
    }


    // Check if DB has connection
    checkConnection($dbConn);


    // Attempt create database query execution
    // UNCOMMENT THE CODE IF YOU ARE CREATING THE DATABASE
    // $sql = "CREATE DATABASE db_sims";
    // executeQuery("database", $dbConn, $sql);



    /* Connect to the newly created MySQL database */
    $db_name = 'db_sims';
    $dbConn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, $db_name); // re-configure database name


    /* TABLE STRUCTURES */
    // DROP TABLE FIRST IF RE-CREATING THE TABLE
    // THEN UNCOMMENT THE CODES BEFORE OPENING THIS FILE ON BROWSER

    // Create USERS table
    // $sql = "CREATE TABLE USERS(
    //             User_id int auto_increment PRIMARY KEY,
    //             LastName varchar(20) not null,
    //             FirstName varchar(20) not null,
    //             User_Name varchar(15) not null,
    //             User_Pass varchar(15) not null,
    //             User_Level int,
    //             date_created datetime default current_timestamp(),
    //             User_Status int
    //         )";
    // executeQuery("table", $dbConn, $sql);  

    // Create userlog table
    // sql = "CREATE TABLE userLogs(
    //         id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    //         user_id INT NOT NULL,
    //         actionType VARCHAR(20),
    //         actionDescription VARCHAR(50),
    //         dateRecorded DATETIME DEFAULT CURRENT_TIMESTAMP
    // );"
    // executeQuery("table", $dbConn, $sql);  

    // Create table auditlog
    // $sql = "CREATE TABLE auditlogs(
    //         id int not null auto_increment primary key,
    //         user_id INT NOT NULL,
    //         user_action VARCHAR(15),
    //         prod_id INT NOT NULL,
    //         datecreated DATETIME DEFAULT current_timestamp);";
    // executeQuery("table", $dbConn, $sql);  

    // Create CATEGORY table
    // $sql = "CREATE TABLE CATEGORY(
    //         cat_id int auto_increment primary key,
    //         cat_name varchar(30) not null,
    //         cat_status INT,
    //         encodedby INT,
	//         dataencoded DATETIME DEFAULT current_timestamp);";
    // executeQuery("table", $dbConn, $sql);  

    // Create color table
    // $sql = "CREATE TABLE color(
    //         color_id int auto_increment primary key,
    //         color VARCHAR(15) not null,
    //         encodedby INT,
    //         dataencoded DATETIME DEFAULT current_timestamp)";
    // executeQuery("table", $dbConn, $sql);  

    // Create size table
    // $sql = "CREATE TABLE size(
    //         size_id int auto_increment primary key,
    //         size VARCHAR(10) not null,
    //         encodedby INT,
    //         dataencoded DATETIME DEFAULT current_timestamp);";
    // executeQuery("table", $dbConn, $sql);  

    // Create fabric table
    // $sql = "CREATE TABLE `fabric` (
    //         `fabric_id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    //         `fabric` VARCHAR(15) NOT NULL,
    //         `encodedby` INT(11) NULL,
    //         `datecreated` DATETIME NULL DEFAULT CURRENT_TIMESTAMP());
    //     ";s
    // executeQuery("table", $dbConn, $sql);  

    // Create PRODUCTS table
    // $sql = "CREATE TABLE products(
    //         id int auto_increment primary key,
    //         itemcode VARCHAR(20) UNIQUE,
    //         prod_name VARCHAR(20) not null,
    //         prod_cat int NOT null,
    //         prod_size int,
    //         prod_color int,
    //         prod_fabric int,
    //         prod_price VARCHAR(50),
    //         prod_sellingprice VARCHAR(50),
    //         prod_image VARCHAR(100),
    //         createdby INT NOT NULL,
    //         datecreated DATETIME DEFAULT current_timestamp);";
    // executeQuery("table", $dbConn, $sql); 


    // Create InventoryItems table
    // $sql = "CREATE TABLE inventoryitems(
    //         prod_id INT,
    //         inv_action VARCHAR(20),
    //         inv_itemqty INT NOT NULL,
    //         createdby INT NOT NULL,
    //         datacreated DATETIME DEFAULT current_timestamp);";
    // executeQuery("table", $dbConn, $sql); 

    // Create Customers table
    // $sql = "CREATE TABLE customer(
    //         customer_id INT NOT NULL AUTO_INCREMENT,
    //         firstname VARCHAR(20),
    //         lastname VARCHAR(20),
    //         contactno VARCHAR(20),
    //         PRIMARY KEY(customer_id))";
    // executeQuery("table", $dbConn, $sql); 

    // Create Supplier table
    // $sql = "CREATE TABLE supplier(
    //         supplier_id INT NOT NULL AUTO_INCREMENT,
    //         company_name VARCHAR(30),
    //         address VARCHAR(50),
    //         contactno VARCHAR(20),
    //         PRIMARY KEY(supplier_id))";
    // executeQuery("table", $dbConn, $sql); 

    // Create Employee table
    // $sql = "CREATE TABLE employee(
    //         emp_id INT NOT NULL AUTO_INCREMENT,
    //         firstname VARCHAR(20),
    //         lastname VARCHAR(20),
    //         gender CHAR,
    //         email VARCHAR(30),
    //         contactno VARCHAR(20),
    //         position_id INT,
    //         datehired DATETIME,
    //         PRIMARY KEY(emp_id))";
    // executeQuery("table", $dbConn, $sql);

    // Create Purchase table
    // $sql = "CREATE TABLE for_purchase(
	// id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	// prod_id INT NOT NULL,
	// prod_name VARCHAR(50) NOT NULL,
	// quantity int,
	// prod_price VARCHAR(20) NOT NULL)";
    // executeQuery("table", $dbConn, $sql);

    // Create TransactionHistory table
    // $sql = "CREATE TABLE transactionhistory(
	// transactionNo INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	// transactionDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	// itemsSold INT NOT NULL,
	// totalPrice DECIMAL(12,2),
	// createdby VARCHAR(20))";
    // executeQuery("table", $dbConn, $sql);

    // Create TransactionDetails table
    // $sql = "CREATE TABLE transactionDetails(
	// transactionNo INT NOT NULL,
	// transactionDate TIMESTAMP,
	// prod_id int,
	// item VARCHAR(100) NOT NULL,
	// price DECIMAL(12,2),
	// quantity INT NOT NULL,
	// totalPrice DECIMAL(12,2))";
    // executeQuery("table", $dbConn, $sql);

    // CLOSE CONNECTION
    $dbConn->close();

?>